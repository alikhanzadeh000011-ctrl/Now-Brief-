package com.example.nowbrief

import android.graphics.Color
import java.util.Calendar

/** Time-of-day phases. The one clock: change the hours in STARTS_MIN / at(). */
enum class Phase(
    val pageTitle: String,
    val pageSubtitle: String,
    val compactTitle: String,
    val nowBarTitle: String,
    val widgetTitle: String,
    val widgetSubtitle: String,
    val badge: Int,
    val pillBg: Int,
    val cardBg: Int,
    val darkPillBg: Int,
    val darkCardBg: Int,
    val darkText: Boolean,
    val pageTop: Int,
    val pageBottom: Int
) {
    MORNING(
        "Morning panel", "Start your day with this briefing.",
        "Morning Brief", "Morning Brief", "Morning Brief", "Open your latest morning update.",
        R.drawable.badge_blue, R.drawable.bg_pill_morning, R.drawable.bg_card_morning,
        R.drawable.bg_pill_dark_morning, R.drawable.bg_card_dark_morning,
        true, 0xFF92A5AB.toInt(), 0xFF5E7376.toInt()
    ),
    MIDDAY(
        "Midday update", "Enjoy the rest of your day.",
        "Good Afternoon", "Good Afternoon", "Good Afternoon", "Open your afternoon update and keep moving.",
        R.drawable.badge_green, R.drawable.bg_pill_midday, R.drawable.bg_card_midday,
        R.drawable.bg_pill_dark_midday, R.drawable.bg_card_dark_midday,
        true, 0xFF96A79D.toInt(), 0xFF6E8569.toInt()
    ),
    EVENING(
        "Evening overview", "Here's a recap of your day.",
        "Evening Brief", "Evening Brief", "Evening Brief", "Here's a recap of your day.",
        R.drawable.badge_pink, R.drawable.bg_pill_evening, R.drawable.bg_card_evening,
        R.drawable.bg_pill_dark_evening, R.drawable.bg_card_dark_evening,
        true, 0xFF9191AD.toInt(), 0xFF67646F.toInt()
    ),
    LATE_NIGHT(
        "Final update", "Enjoy a peaceful and restful night.",
        "Late Night Recap", "Late Night Recap", "Late Night Recap", "Open the quiet wrap-up for the end of the day.",
        R.drawable.badge_purple, R.drawable.bg_pill_night, R.drawable.bg_card_night,
        R.drawable.bg_pill_dark_night, R.drawable.bg_card_dark_night,
        false, 0xFF2B3E4C.toInt(), 0xFF0F282D.toInt()
    );

    /** Gradient behind a widget: the light one, or the dark version of the same phase colours. */
    fun bgRes(compact: Boolean, dark: Boolean): Int =
        if (dark) (if (compact) darkPillBg else darkCardBg) else (if (compact) pillBg else cardBg)

    companion object {
        /** Phase starts as minutes of the day: 05:00, 11:00, 17:00, 21:00. */
        val STARTS_MIN = intArrayOf(5 * 60, 11 * 60, 17 * 60, 21 * 60)

        // 05-11 Morning Brief, 11-17 Good Afternoon, 17-21 Evening Brief, 21-05 Late Night Recap.
        fun at(hour: Int): Phase = when (hour) {
            in 5..10 -> MORNING
            in 11..16 -> MIDDAY
            in 17..20 -> EVENING
            else -> LATE_NIGHT
        }

        fun current(): Phase = at(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
    }
}

/** Page background / title: follows the same clock as the Now bar and the widgets (see Phase.at). */
enum class PageTheme(val bg: Int, val light: Boolean) {
    MORNING(R.drawable.page_bg_morning, true),
    MIDDAY(R.drawable.page_bg_midday, true),
    AFTERNOON(R.drawable.page_bg_afternoon, true),
    NIGHT(R.drawable.page_bg_night, false);

    companion object {
        fun at(hour: Int): PageTheme = when (Phase.at(hour)) {
            Phase.MORNING -> MORNING
            Phase.MIDDAY -> MIDDAY
            Phase.EVENING -> AFTERNOON
            Phase.LATE_NIGHT -> NIGHT
        }

        fun title(hour: Int): Pair<String, String> = when (Phase.at(hour)) {
            Phase.MORNING -> "Start of morning" to "Start your day with this briefing."
            Phase.MIDDAY -> "Midday update" to "Enjoy the rest of your day."
            Phase.EVENING -> "Evening overview" to "Here's a recap of your day."
            Phase.LATE_NIGHT ->
                if (hour in 21..23) "Final update" to "Enjoy a peaceful and restful night."
                else "Low activity" to "Enjoy a peaceful and restful night."
        }
    }
}

/** How a widget looks for a given blur amount (0..100) and Dark/Light choice. */
class Look(
    val dark: Boolean,
    val gradAlpha: Float,
    val rootColor: Int,
    val titleColor: Int,
    val subColor: Int
)

object Looks {
    /**
     * One UI Home draws its wallpaper blur under the widget root (@android:id/background)
     * only while that root's background alpha is within 1..254. So rootColor always stays in that range.
     * The blur strength itself is fixed by One UI; the slider fades the phase gradient on top of it.
     */
    fun compute(phase: Phase, blur: Int, dark: Boolean): Look {
        val b = blur.coerceIn(0, 100) / 100f
        val gradAlpha = 1f - b
        // 100 = exactly #01 (pure One UI blur); the Dark/Light tint is at most 30% and fades out as blur rises
        val a = (1f + (1f - b) * 0.30f * 254f).toInt().coerceIn(1, 254)
        val rootColor = if (dark) Color.argb(a, 0, 0, 0) else Color.argb(a, 255, 255, 255)
        val onTint = b >= 0.5f
        val title = when {
            // dark = the dark version of the phase colours (like the original), so text is always white
            dark -> Color.WHITE
            onTint -> 0xFF111111.toInt()
            else -> if (phase.darkText) 0xFF111111.toInt() else Color.WHITE
        }
        val sub = (title and 0x00FFFFFF) or ((if (dark) 0xCC else 0xB8) shl 24)
        return Look(dark, gradAlpha, rootColor, title, sub)
    }
}
