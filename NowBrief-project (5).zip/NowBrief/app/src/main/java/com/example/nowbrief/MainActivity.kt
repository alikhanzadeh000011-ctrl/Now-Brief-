package com.example.nowbrief

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** The briefing page: phase background, sparkles, title, cards, small glass buttons. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_FROM_NOW_BAR = "from_now_bar"
    }

    private var stars: LottieAnimationView? = null
    private var weatherView: View? = null
    private var alarmView: View? = null
    private var healthHolder: LinearLayout? = null
    private var sleepHolder: LinearLayout? = null
    private var energyHolder: LinearLayout? = null
    private var wellbeingHolder: LinearLayout? = null
    private var momentsHolder: LinearLayout? = null

    private val speaker: BriefSpeaker by lazy {
        BriefSpeaker(
            this,
            { on -> findViewById<GlassButton>(R.id.btn_audio).setIcon(if (on) R.drawable.ic_stop else R.drawable.ic_audio) },
            { Toast.makeText(this, "Text-to-speech isn't available on this phone", Toast.LENGTH_LONG).show() }
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private val sweepRunnable = Runnable { checkSweeps() }
    private var glassPending = false
    private var glassRunning = false
    private val glassIds = intArrayOf(R.id.btn_audio, R.id.btn_info, R.id.btn_settings)
    private val glassTicker = object : Runnable {
        override fun run() {
            if (!glassRunning) return
            refreshGlass()
            handler.postDelayed(this, 600)
        }
    }

    private fun refreshGlass() {
        for (id in glassIds) findViewById<GlassButton>(id).refresh()
    }
    private var page: PageTheme = PageTheme.MORNING
    private var ink: Int = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        if (intent?.getBooleanExtra(EXTRA_FROM_NOW_BAR, false) == true && Prefs.expandWithoutUnlock(this)) {
            setShowWhenLocked(true)
        }
        setContentView(R.layout.activity_main)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        page = PageTheme.at(hour)
        val titles = PageTheme.title(hour)
        ink = if (page.light) 0xFF161616.toInt() else Color.WHITE

        findViewById<ImageView>(R.id.page_bg).setImageResource(page.bg)
        val scroll = findViewById<FadeScrollView>(R.id.scroll)
        scroll.applySystemBarPadding()
        scroll.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            (v as FadeScrollView).setFade(v.paddingTop + dp(36).toFloat())
        }
        findViewById<View>(R.id.overlay_root).applySystemBarPadding()
        scroll.setOnScrollChangeListener { _, _, _, _, _ ->
            checkSweeps()
            if (!glassPending) {
                glassPending = true
                handler.postDelayed({
                    glassPending = false
                    refreshGlass()
                }, 40)
            }
        }

        val title = findViewById<SweepTextView>(R.id.main_title)
        title.text = titles.first
        title.setTextColor(ink)
        title.setInk(ink)
        val sub = findViewById<SweepTextView>(R.id.main_sub)
        sub.text = titles.second
        sub.setTextColor((ink and 0x00FFFFFF) or (0xE6 shl 24))
        sub.setInk(ink)

        val icons = intArrayOf(R.drawable.ic_audio, R.drawable.ic_info, R.drawable.ic_settings)
        for ((i, id) in glassIds.withIndex()) {
            val gb = findViewById<GlassButton>(id)
            gb.source = findViewById(R.id.backdrop_root)
            gb.setIcon(icons[i])
        }

        val bars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (page.light) bars else 0, bars)

        loadStars()

        findViewById<View>(R.id.btn_audio).setOnClickListener {
            toggleAudio()
        }
        findViewById<View>(R.id.btn_info).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Now Brief")
                .setMessage("This briefing is built on your phone from the weather, your alarms, your calendar and more cards in the next packages.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val need = ArrayList<String>()
        for (p in arrayOf(
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_CALENDAR
        )) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 11)
    }

    private fun buildCards() {
        val cards = findViewById<LinearLayout>(R.id.cards)
        cards.removeAllViews()
        val light = page.light
        val cal = Prefs.category(this, "events") && CalendarRepo.hasPermission(this)

        cards.addView(Cards.label(this, "Here's your weather update.", ink))
        val w = layoutInflater.inflate(R.layout.card_weather, cards, false)
        Cards.styleWeather(this, w, page)
        Cards.bindWeather(this, w, null, true)
        cards.addView(w)
        weatherView = w

        if (Prefs.category(this, "routine")) {
            cards.addView(Cards.label(this, "Here's today's date.", ink))
            cards.addView(RoutineCards.date(this, light))
        }

        if (cal) {
            val special = CalendarRepo.upcomingSpecial(this)
            if (special != null) {
                val custom = Prefs.eventName(this, special.begin)
                val title = if (custom.isEmpty()) special.title else custom
                val art = Arts.of(Prefs.eventArt(this))
                cards.addView(Cards.label(this, "Here's an event worth keeping in mind.", ink))
                cards.addView(
                    MoreCards.event(
                        this, light, title, special, art,
                        { sendGreeting(art) },
                        { shareEvent(title, special) },
                        { Editors.editEvent(this, special, title) { rebuild() } }
                    )
                )
            }
        }

        alarmView = null
        if (Prefs.category(this, "events")) {
            cards.addView(Cards.label(this, "Here's your next alarm.", ink))
            val a = layoutInflater.inflate(R.layout.card_alarm, cards, false)
            Cards.styleAlarm(this, a, page)
            cards.addView(a)
            alarmView = a
        }

        sleepHolder = null
        energyHolder = null
        if (Prefs.category(this, "health")) {
            val sh = LinearLayout(this)
            sh.orientation = LinearLayout.VERTICAL
            cards.addView(sh)
            sleepHolder = sh
            val eh = LinearLayout(this)
            eh.orientation = LinearLayout.VERTICAL
            cards.addView(eh)
            energyHolder = eh
        }

        healthHolder = null
        if (Prefs.category(this, "health")) {
            cards.addView(Cards.label(this, "Here's how you're tracking today.", ink))
            val h = LinearLayout(this)
            h.orientation = LinearLayout.VERTICAL
            cards.addView(h)
            healthHolder = h
        }

        if (Prefs.category(this, "events")) {
            val plans = currentPlans(cal)
            cards.addView(Cards.label(this, "Here are the plans shaping your day.", ink))
            cards.addView(MoreCards.plans(this, light, plans) { Editors.editSchedule(this) { rebuild() } })
        }

        momentsHolder = null
        if (Prefs.category(this, "moments")) {
            val mh = LinearLayout(this)
            mh.orientation = LinearLayout.VERTICAL
            cards.addView(mh)
            momentsHolder = mh
        }

        wellbeingHolder = null
        if (Prefs.category(this, "wellbeing")) {
            val wh = LinearLayout(this)
            wh.orientation = LinearLayout.VERTICAL
            cards.addView(wh)
            wellbeingHolder = wh
        }

        if (Prefs.category(this, "routine")) {
            val bat = RoutineCards.battery(this, light)
            if (bat != null) {
                cards.addView(Cards.label(this, "Here's your battery status.", ink))
                cards.addView(bat)
            }
        }

        if (Prefs.category(this, "travel")) {
            cards.addView(Cards.label(this, "Here's something ready when you're driving.", ink))
            cards.addView(MoreCards.driving(this, light) { tryDriving() })
        }

        if (page == PageTheme.NIGHT) {
            cards.addView(Cards.label(this, "Stay up to date with Now brief.", ink))
            cards.addView(MoreCards.stayUp(this, light))
        }
    }

    private fun loadHealth() {
        val h = healthHolder ?: return
        HealthRepo.load(this) { state, data ->
            if (!isDestroyed) {
                h.removeAllViews()
                h.addView(
                    MoreCards.health(
                        this, page.light, state, data,
                        { requestHealth() },
                        { Editors.editGoals(this) { rebuild() } }
                    )
                )
            }
        }
    }

    private fun fill(holder: LinearLayout, label: String, card: View) {
        holder.removeAllViews()
        holder.addView(Cards.label(this, label, ink))
        holder.addView(card)
        scheduleSweeps()
    }

    private fun loadWellness() {
        val sh = sleepHolder
        val eh = energyHolder
        if (sh == null || eh == null) return
        WellnessRepo.load(this) { state, data ->
            if (!isDestroyed) {
                sh.removeAllViews()
                eh.removeAllViews()
                if (state == HealthRepo.STATE_NEED_PERMISSION) {
                    fill(sh, "Here's a summary of how you slept.", WellnessCards.sleepPrompt(this, page.light) { requestHealth() })
                } else if (state == HealthRepo.STATE_OK && data != null) {
                    val sl = data.sleep
                    val en = data.energy
                    if (sl != null) {
                        fill(sh, "Here's a summary of how you slept.", WellnessCards.sleep(this, page.light, sl))
                    } else if (data.note != null) {
                        fill(sh, "Here's a summary of how you slept.", WellnessCards.note(this, page.light, data.note))
                    }
                    if (en != null) fill(eh, "Here's your energy score for today.", WellnessCards.energy(this, page.light, en))
                }
            }
        }
    }

    private fun loadMoments() {
        val mh = momentsHolder ?: return
        val label = "Here are some memorable moments from today."
        if (!MomentsRepo.hasPermission(this)) {
            fill(mh, label, MomentsCards.prompt(this, page.light) {
                requestPermissions(arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES), 12)
            })
            return
        }
        MomentsRepo.load(this) { d ->
            if (!isDestroyed) {
                mh.removeAllViews()
                if (d != null) fill(mh, label, MomentsCards.card(this, page.light, d))
            }
        }
    }

    private fun collectSweeps(v: View, out: ArrayList<SweepTextView>) {
        if (v is SweepTextView) {
            out.add(v)
        } else if (v is ViewGroup) {
            for (i in 0 until v.childCount) collectSweeps(v.getChildAt(i), out)
        }
    }

    private var nextSweepAt = 0L
    private var introUntil = 0L

    /** Re-hides the title and subtitle and plays the colored reveal again (every time the page opens). */
    private fun playIntro() {
        val title = findViewById<SweepTextView>(R.id.main_title)
        val sub = findViewById<SweepTextView>(R.id.main_sub)
        title.rearm()
        sub.rearm()
        title.play(250)
        sub.play(420)
        val now = android.os.SystemClock.uptimeMillis()
        nextSweepAt = now + 1250
        introUntil = now + 2800
    }

    /**
     * Starts the colored reveal on every sentence that is on screen or about to scroll in.
     * While the page is opening they follow one after another; later (scrolling) they start at once.
     */
    private fun checkSweeps() {
        val sc = findViewById<View>(R.id.scroll)
        val cards = findViewById<LinearLayout>(R.id.cards)
        val list = ArrayList<SweepTextView>()
        collectSweeps(cards, list)
        val area = android.graphics.Rect()
        if (!sc.getGlobalVisibleRect(area)) return
        val loc = IntArray(2)
        val limit = area.bottom + dp(260)
        for (t in list) {
            if (t.played || !t.isLaidOut || t.height == 0) continue
            t.getLocationOnScreen(loc)
            if (loc[1] < limit) {
                val now = android.os.SystemClock.uptimeMillis()
                if (now < introUntil) {
                    val start = Math.max(now, nextSweepAt)
                    t.play(start - now)
                    nextSweepAt = start + 650
                } else {
                    t.play(0)
                }
            }
        }
    }

    private fun scheduleSweeps() {
        handler.removeCallbacks(sweepRunnable)
        handler.postDelayed(sweepRunnable, 60)
    }

    private fun loadWellbeing() {
        val wh = wellbeingHolder ?: return
        val label = "Here's how much you've used your phone."
        if (!WellbeingRepo.hasAccess(this)) {
            fill(wh, label, WellbeingCards.prompt(this, page.light) {
                try {
                    startActivity(WellbeingRepo.accessIntent(this))
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    } catch (e2: Exception) {
                    }
                }
            })
            return
        }
        WellbeingRepo.load(this) { d ->
            if (!isDestroyed) {
                wh.removeAllViews()
                if (d != null) fill(wh, label, WellbeingCards.card(this, page.light, d))
            }
        }
    }

    private fun requestHealth() {
        try {
            startActivityForResult(HealthRepo.requestIntent(this), 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Health Connect isn't available", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            loadHealth()
            loadWellness()
        }
    }

    private fun openCalendar() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis())))
        } catch (e: Exception) {
            Toast.makeText(this, "No calendar app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentPlans(cal: Boolean): List<CalEvent> =
        if (Prefs.schedMode(this) == "saved") {
            CalendarRepo.savedPlans(this)
        } else if (cal) {
            CalendarRepo.todayPlans(this)
        } else {
            emptyList()
        }

    /** The audio brief reads the page title, its subtitle, then the sentences above the cards, in page order. */
    private fun toggleAudio() {
        if (speaker.speaking) {
            speaker.stop()
            return
        }
        val list = ArrayList<SweepTextView>()
        collectSweeps(findViewById<LinearLayout>(R.id.cards), list)
        val lines = ArrayList<String>()
        val head = findViewById<TextView>(R.id.main_title).text.toString().trim()
        val sub = findViewById<TextView>(R.id.main_sub).text.toString().trim()
        if (head.isNotEmpty()) lines.add(if (head.endsWith(".")) head else "$head.")
        if (sub.isNotEmpty()) lines.add(sub)
        for (t in list) {
            val line = t.text.toString().trim()
            if (line.isNotEmpty()) lines.add(line)
        }
        if (lines.isEmpty()) {
            Toast.makeText(this, "Nothing to read yet", Toast.LENGTH_SHORT).show()
            return
        }
        speaker.speak(lines)
    }

    private fun sendGreeting(art: Art) {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, "Happy birthday! " + art.emoji + art.emoji + art.emoji)
        startActivity(Intent.createChooser(send, null))
    }

    private fun shareEvent(title: String, e: CalEvent) {
        val day = java.text.SimpleDateFormat("EEEE, MMM d", java.util.Locale.US).format(java.util.Date(e.begin))
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, title + " - " + day)
        startActivity(Intent.createChooser(send, null))
    }

    /** Rebuilds the cards after an editor saved something. */
    private fun rebuild() {
        buildCards()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(false)
        loadHealth()
        loadWellness()
        loadWellbeing()
        loadMoments()
        scheduleSweeps()
    }

    private fun tryDriving() {
        try {
            val i = packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            startActivity(i)
        } catch (e: Exception) {
        }
        try {
            val am = getSystemService(AudioManager::class.java)
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
        } catch (e: Exception) {
        }
    }

    private fun loadWeather(force: Boolean) {
        WeatherRepo.refresh(this, force) { d ->
            val w = weatherView
            if (!isDestroyed && w != null) Cards.bindWeather(this, w, d, false)
        }
    }

    private fun loadStars() {
        val v = findViewById<LottieAnimationView>(R.id.sparkles)
        v.setAnimation("intelligence_progress_color.json")
        v.repeatCount = LottieDrawable.INFINITE
        stars = v
    }

    override fun onResume() {
        super.onResume()
        if (Schedule.markOpened(this)) NowBarNotifier.post(this)
        Refresher.refreshAll(this)
        stars?.playAnimation()
        for (id in glassIds) findViewById<GlassButton>(id).setTintLevel(Prefs.glass(this))
        findViewById<View>(R.id.btn_audio).visibility = if (Prefs.audioBrief(this)) View.VISIBLE else View.GONE
        glassRunning = true
        handler.post(glassTicker)
        playIntro()
        buildCards()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(false)
        loadHealth()
        loadWellness()
        loadWellbeing()
        loadMoments()
        scheduleSweeps()
    }

    override fun onPause() {
        speaker.stop()
        stars?.pauseAnimation()
        glassRunning = false
        handler.removeCallbacks(glassTicker)
        super.onPause()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Refresher.refreshAll(this)
        rebuild()
        loadWeather(true)
    }
}
