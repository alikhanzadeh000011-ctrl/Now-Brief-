package com.example.nowbrief

import android.content.Context
import java.util.Calendar

/**
 * One clock for everything (Now bar, widgets and the in-app page):
 *   05:00 Morning Brief · 11:00 Good Afternoon · 17:00 Evening Brief · 21:00 Late Night Recap (see Phase.at)
 * plus the "Get today's highlight" windows, shown on the Now bar only:
 *   06:00-06:30 · 12:30-13:00 · 18:00-18:30 · 22:30-23:00
 */
object Schedule {
    private const val PREF = "schedule"

    private fun m(h: Int, min: Int) = h * 60 + min

    /** Highlight windows as (start, end) in minutes of the day. */
    private val WINDOWS = arrayOf(
        m(6, 0) to m(6, 30),
        m(12, 30) to m(13, 0),
        m(18, 0) to m(18, 30),
        m(22, 30) to m(23, 0)
    )

    private fun cal(now: Long): Calendar = Calendar.getInstance().apply { timeInMillis = now }

    private fun dayStart(c: Calendar): Calendar = (c.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    private fun at(day: Calendar, minutes: Int, addDays: Int): Long {
        val c = day.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, addDays)
        c.set(Calendar.HOUR_OF_DAY, minutes / 60)
        c.set(Calendar.MINUTE, minutes % 60)
        return c.timeInMillis
    }

    /** Start (millis) of the highlight window that is open at [now], or null. */
    fun openWindowStart(now: Long = System.currentTimeMillis()): Long? {
        val c = cal(now)
        val min = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val w = WINDOWS.firstOrNull { min >= it.first && min < it.second } ?: return null
        return at(dayStart(c), w.first, 0)
    }

    /** True while a highlight window is open and the user has not opened the app during it. */
    fun highlightActive(ctx: Context, now: Long = System.currentTimeMillis()): Boolean {
        val start = openWindowStart(now) ?: return false
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("opened_window", 0L) != start
    }

    /** The app was opened: an open highlight window ends early (like the original, it stays until tapped). */
    fun markOpened(ctx: Context): Boolean {
        val start = openWindowStart() ?: return false
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (sp.getLong("opened_window", 0L) == start) return false
        sp.edit().putLong("opened_window", start).apply()
        return true
    }

    /** Last state posted to the Now bar, so a change of state can re-pop the chip. */
    fun lastState(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("last_state", "") ?: ""

    fun setLastState(ctx: Context, v: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("last_state", v).apply()

    /** The next moment anything changes: a phase start or the start/end of a highlight window. */
    fun nextEventMillis(now: Long): Long {
        val c = cal(now)
        val day = dayStart(c)
        val points = ArrayList<Int>()
        for (s in Phase.STARTS_MIN) points.add(s)
        for (w in WINDOWS) {
            points.add(w.first)
            points.add(w.second)
        }
        var best = Long.MAX_VALUE
        for (add in 0..1) {
            for (p in points) {
                val t = at(day, p, add)
                if (t > now && t < best) best = t
            }
        }
        return best
    }
}
