package com.example.nowbrief

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon

/**
 * Posts ONE ongoing notification that One UI shows in the Now bar.
 * Built the same way as the old working build: the Samsung extras are written
 * AFTER build(), with android.showSmallIcon = true and the semFlags bit 0x8000.
 * No foreground service on purpose; an alarm refreshes it at each phase change.
 */
object NowBarNotifier {
    private const val CHANNEL_ID = "now_brief_now_bar"
    private const val NOTIF_ID = 7001
    private const val SEM_FLAGS_VALUE = 0x8000

    /** Card/chip colour of the "Now Brief / Get today's highlight" state. */
    private const val HIGHLIGHT_COLOR = 0xFF1FB5C9.toInt()

    /** Each phase card has the colour of its own logo: blue, green, pink and purple. */
    private fun chipColor(phase: Phase): Int = when (phase) {
        Phase.MORNING -> 0xFF35A8F0.toInt()
        Phase.MIDDAY -> 0xFF3DB59A.toInt()
        Phase.EVENING -> 0xFFD35FCB.toInt()
        Phase.LATE_NIGHT -> 0xFF5B3CF0.toInt()
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
    }

    fun post(ctx: Context) {
        if (!Prefs.nowBar(ctx)) {
            cancel(ctx)
            return
        }
        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return

        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Now Brief", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Keeps Now Brief on the Now bar"
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }

        val phase = Phase.current()
        val highlight = Schedule.highlightActive(ctx)

        // Highlight window (30 min): "Now Brief" with the highlight logo on a turquoise card.
        // Any other time: the phase card with its own logo, colour and text.
        val icon = Icon.createWithResource(ctx, if (highlight) R.drawable.badge_highlight else phase.badge)
        val color = if (highlight) HIGHLIGHT_COLOR else chipColor(phase)
        val title = if (highlight) "Now Brief" else phase.nowBarTitle
        val sub = if (highlight) "Get today's highlight" else phase.widgetSubtitle

        val open = PendingIntent.getActivity(
            ctx, 7,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_FROM_NOW_BAR, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(sub)
            .setContentIntent(open)
            .setDeleteIntent(PhaseScheduler.tickIntent(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_ALARM)
            .setColor(color)
            .setColorized(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .build()

        // Samsung Now bar / Live notification keys (copied from the working build)
        val ex = notif.extras
        ex.putInt("android.ongoingActivityNoti.style", 1)
        ex.putString("android.ongoingActivityNoti.primaryInfo", title)
        ex.putString("android.ongoingActivityNoti.secondaryInfo", sub)
        ex.putString("android.ongoingActivityNoti.nowbarPrimaryInfo", title)
        ex.putString("android.ongoingActivityNoti.nowbarSecondaryInfo", sub)
        ex.putString("android.ongoingActivityNoti.chipExpandedText", title)
        ex.putInt("android.ongoingActivityNoti.chipBgColor", color)
        ex.putParcelable("android.ongoingActivityNoti.chipIcon", icon)
        ex.putParcelable("android.ongoingActivityNoti.nowbarIcon", icon)
        ex.putParcelable("android.ongoingActivityNoti.firstIcon", icon)
        ex.putBoolean("android.showSmallIcon", true)
        ex.putBoolean("android.requestPromotedOngoing", true)
        ex.putString("android.shortCriticalText", "Brief")

        // Hidden Samsung flag bit that the working build also set (reflection; ignored if it fails)
        try {
            val f = Notification::class.java.getDeclaredField("semFlags")
            f.isAccessible = true
            f.setInt(notif, f.getInt(notif) or SEM_FLAGS_VALUE)
        } catch (e: Throwable) {
        }

        val state = if (highlight) "highlight" else phase.name
        if (Schedule.lastState(ctx) != state) {
            nm.cancel(NOTIF_ID)
            Schedule.setLastState(ctx, state)
        }
        nm.notify(NOTIF_ID, notif)
    }
}
