package com.example.nowbrief

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/**
 * One UI slider, ported 1:1 from the Edge Glow app (Oui.Slider):
 * 15dp pill track, blue fill and a thumb with a blue ring (lighter and bigger while pressed).
 */
class OuiSlider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val BLUE = 0xFF3879FE.toInt()

        private fun lerp(a: Int, b: Int, t0: Float): Int {
            val t = t0.coerceIn(0f, 1f)
            val r = (((a shr 16) and 255) * (1f - t) + ((b shr 16) and 255) * t).toInt()
            val g = (((a shr 8) and 255) * (1f - t) + ((b shr 8) and 255) * t).toInt()
            val bl = ((a and 255) * (1f - t) + (b and 255) * t).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = context.resources.displayMetrics.density
    private val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private var max = 100
    private var value = 0
    private var press = 0f
    private var pressA: ValueAnimator? = null
    private var lastTick = 0L

    /** (value, fromUser) */
    var onChange: ((Int, Boolean) -> Unit)? = null
    var onStop: (() -> Unit)? = null

    fun setRange(max: Int, value: Int) {
        this.max = maxOf(1, max)
        this.value = value.coerceIn(0, this.max)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (40 * d).toInt())
    }

    private fun x0() = 4 * d + 7 * d
    private fun x1() = width - 4 * d - 7 * d

    private fun animPress(to: Float) {
        pressA?.cancel()
        pressA = ValueAnimator.ofFloat(press, to).apply {
            duration = 140
            addUpdateListener {
                press = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun setFromX(x: Float) {
        val f = (x - x0()) / maxOf(1f, x1() - x0())
        val v = Math.round(f.coerceIn(0f, 1f) * max)
        if (v == value) return
        value = v
        invalidate()
        val now = System.currentTimeMillis()
        if (now - lastTick > 35) {
            lastTick = now
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        onChange?.invoke(value, true)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animPress(1f)
                setFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> setFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animPress(0f)
                onStop?.invoke()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val tl = 4 * d
        val tr = width - 4 * d
        val th = 15 * d
        val tx = x0() + (x1() - x0()) * value / max.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (night) 0xFF444447.toInt() else 0xFFDADADF.toInt()
        r.set(tl, cy - th / 2f, tr, cy + th / 2f)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        p.color = BLUE
        r.set(tl, cy - th / 2f, tx, cy + th / 2f)
        val rad = minOf(th / 2f, maxOf(0f, (tx - tl) / 2f))
        c.drawRoundRect(r, rad, rad, p)
        val outer = (10f + 4.5f * press) * d
        p.style = Paint.Style.FILL
        p.color = if (night) lerp(0xFF000000.toInt(), 0xFFE8E8EC.toInt(), press)
        else lerp(0xFFFFFFFF.toInt(), 0xFFE8E8EC.toInt(), press)
        c.drawCircle(tx, cy, outer, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * d
        p.color = lerp(BLUE, 0xFFB5C6F5.toInt(), press)
        c.drawCircle(tx, cy, outer - 1.25f * d, p)
    }

    override fun onDetachedFromWindow() {
        pressA?.cancel()
        super.onDetachedFromWindow()
    }
}
