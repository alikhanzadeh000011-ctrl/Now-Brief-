package com.example.nowbrief

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * One UI switch, ported 1:1 from the Edge Glow app (Oui.Switch):
 * 44x36dp touch area, 36x21dp track, 17dp thumb that shrinks with a soft halo while pressed.
 */
class OuiSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val BLUE = 0xFF3879FE.toInt()
        private const val TRACK_OFF = 0xFF636368.toInt()
        private const val THUMB = 0xFFFCFCFF.toInt()

        private fun lerp(a: Int, b: Int, t0: Float): Int {
            val t = t0.coerceIn(0f, 1f)
            val r = (((a shr 16) and 255) * (1f - t) + ((b shr 16) and 255) * t).toInt()
            val g = (((a shr 8) and 255) * (1f - t) + ((b shr 8) and 255) * t).toInt()
            val bl = ((a and 255) * (1f - t) + (b and 255) * t).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val d = context.resources.displayMetrics.density
    private var checked = false
    private var pos = 0f
    private var press = 0f
    private var posA: ValueAnimator? = null
    private var pressA: ValueAnimator? = null
    private var listener: ((OuiSwitch, Boolean) -> Unit)? = null

    init {
        isClickable = false
        isFocusable = false
    }

    var isChecked: Boolean
        get() = checked
        set(on) {
            checked = on
            pos = if (on) 1f else 0f
            invalidate()
        }

    fun setOnCheckedChangeListener(l: ((OuiSwitch, Boolean) -> Unit)?) {
        listener = l
    }

    fun toggle() {
        checked = !checked
        animPos(if (checked) 1f else 0f)
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        listener?.invoke(this, checked)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((44 * d).toInt(), (36 * d).toInt())
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        animPress(if (pressed) 1f else 0f)
    }

    private fun animPos(to: Float) {
        posA?.cancel()
        posA = ValueAnimator.ofFloat(pos, to).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                pos = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun animPress(to: Float) {
        pressA?.cancel()
        pressA = ValueAnimator.ofFloat(press, to).apply {
            duration = 130
            addUpdateListener {
                press = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val tw = 36 * d
        val th = 21 * d
        val l = cx - tw / 2f
        val t = cy - th / 2f
        p.style = Paint.Style.FILL
        p.color = lerp(TRACK_OFF, BLUE, pos)
        r.set(l, t, l + tw, t + th)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        val x0 = l + 10.5f * d
        val x1 = l + tw - 10.5f * d
        val tx = x0 + (x1 - x0) * pos
        if (press > 0.01f) {
            p.color = ((0x38 * press).toInt() shl 24) or 0xFFFFFF
            c.drawCircle(tx, cy, 13.5f * d, p)
        }
        p.color = THUMB
        c.drawCircle(tx, cy, (8.5f - 2.2f * press) * d, p)
    }

    override fun onDetachedFromWindow() {
        posA?.cancel()
        pressA?.cancel()
        super.onDetachedFromWindow()
    }
}
