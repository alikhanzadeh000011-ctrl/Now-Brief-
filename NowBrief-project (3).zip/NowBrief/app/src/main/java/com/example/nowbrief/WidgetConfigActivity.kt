package com.example.nowbrief

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import java.util.Calendar

/** "Widget settings": Blur 0-100 and Colors (Match phone setting / Light / Dark), with a live preview. */
class WidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var kind = Kind.LARGE
    private var blur = 0
    private var colorMode = 2
    private lateinit var previewView: View
    private lateinit var colorsValue: TextView

    private fun isNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun isDark() = when (colorMode) {
        0 -> isNight()
        1 -> false
        else -> true
    }

    private fun modeName(mode: Int) = getString(
        when (mode) {
            0 -> R.string.match_phone
            1 -> R.string.light
            else -> R.string.dark
        }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        setResult(RESULT_CANCELED)

        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            kind = Refresher.kindOf(this, widgetId)
            blur = Prefs.blur(this, widgetId)
            colorMode = Prefs.colorMode(this, widgetId)
        }

        setContentView(R.layout.activity_widget_config)
        findViewById<View>(R.id.config_root).applySystemBarPadding()

        // blurred phase wallpaper behind the preview, like the original screen
        val backdrop = findViewById<ImageView>(R.id.preview_backdrop)
        backdrop.setImageResource(PageTheme.at(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)).bg)
        backdrop.setRenderEffect(RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.MIRROR))

        val holder = findViewById<FrameLayout>(R.id.preview_holder)
        val compact = kind == Kind.COMPACT
        previewView = LayoutInflater.from(this)
            .inflate(if (compact) R.layout.widget_compact else R.layout.widget_card, holder, false)
        val size = when (kind) {
            Kind.COMPACT -> 230 to 76
            Kind.LARGE -> 170 to 170
            Kind.WIDE -> 300 to 150
        }
        holder.addView(previewView, FrameLayout.LayoutParams(dp(size.first), dp(size.second), Gravity.CENTER))

        val slider = findViewById<OuiSlider>(R.id.slider_blur)
        val value = findViewById<TextView>(R.id.tv_blur_value)
        slider.setRange(100, blur)
        value.text = "$blur%"
        slider.onChange = { v, _ ->
            blur = v
            value.text = "$v%"
            applyPreview()
        }

        colorsValue = findViewById(R.id.tv_colors_value)
        colorsValue.text = modeName(colorMode)
        val row = findViewById<View>(R.id.row_colors)
        row.setOnClickListener { showColorMenu(row, findViewById(R.id.settings_card)) }

        findViewById<View>(R.id.btn_cancel).setOnClickListener { finish() }
        findViewById<View>(R.id.btn_save).setOnClickListener { save() }

        applyPreview()
    }

    /** Samsung style dropdown that opens over the Colors row. */
    private fun showColorMenu(row: View, card: View) {
        val night = isNight()
        val bg = GradientDrawable().apply {
            cornerRadius = dp(28).toFloat()
            setColor(if (night) 0xFF252528.toInt() else Color.WHITE)
            setStroke(dp(1), if (night) 0x26FFFFFF else 0x1A000000)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(0, dp(10), 0, dp(10))
        }
        val popup = PopupWindow(box, (card.width * 0.845f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        val blue = 0xFF3879FE.toInt()
        val ink = if (night) Color.WHITE else 0xFF111111.toInt()
        for (mode in intArrayOf(0, 1, 2)) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(28), 0, dp(26), 0)
                setBackgroundResource(android.R.drawable.list_selector_background)
            }
            val selected = mode == colorMode
            val tv = TextView(this).apply {
                text = modeName(mode)
                textSize = 18f
                setTextColor(if (selected) blue else ink)
                if (selected) typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            }
            item.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (selected) {
                val check = ImageView(this)
                check.setImageResource(R.drawable.ic_check_blue)
                item.addView(check, LinearLayout.LayoutParams(dp(24), dp(24)))
            }
            item.setOnClickListener {
                colorMode = mode
                colorsValue.text = modeName(mode)
                applyPreview()
                popup.dismiss()
            }
            box.addView(item, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        }
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(16).toFloat()
        box.measure(
            View.MeasureSpec.makeMeasureSpec(popup.width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val cardLoc = IntArray(2)
        val rowLoc = IntArray(2)
        card.getLocationInWindow(cardLoc)
        row.getLocationInWindow(rowLoc)
        // popup sits on the Colors row: its bottom lines up with the bottom of that row
        val y = rowLoc[1] + row.height - box.measuredHeight
        box.alpha = 0f
        popup.showAtLocation(card, Gravity.TOP or Gravity.START, cardLoc[0], y)
        box.animate().alpha(1f).setDuration(140).start()
    }

    private fun applyPreview() {
        val phase = Phase.current()
        val look = Looks.compute(phase, blur, isDark())
        val compact = kind == Kind.COMPACT

        val bg = previewView.findViewById<ImageView>(R.id.bg)
        bg.setImageResource(phase.bgRes(compact, look.dark))
        bg.alpha = look.gradAlpha

        previewView.setBackgroundColor(look.rootColor)

        previewView.findViewById<ImageView>(R.id.badge).setImageResource(phase.badge)

        val title = previewView.findViewById<TextView>(R.id.title)
        title.text = if (compact) phase.compactTitle else phase.widgetTitle
        title.setTextColor(look.titleColor)

        if (!compact) {
            val sub = previewView.findViewById<TextView>(R.id.subtitle)
            sub.text = phase.widgetSubtitle
            sub.setTextColor(look.subColor)
            val wide = kind == Kind.WIDE
            title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, if (wide) 24f else 20f)
            sub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, if (wide) 15f else 13f)
        }
    }

    private fun save() {
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            Prefs.setBlur(this, widgetId, blur)
            Prefs.setColorMode(this, widgetId, colorMode)
            Refresher.updateWidget(this, widgetId)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        finish()
    }
}
