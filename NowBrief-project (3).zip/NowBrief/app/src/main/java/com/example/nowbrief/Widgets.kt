package com.example.nowbrief

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews

enum class Kind { COMPACT, LARGE, WIDE }

object WidgetRenderer {

    /**
     * Scale of the content, from the size the launcher actually gives this widget.
     * One UI Home's "Adjust content size" (and big Display size) change the room a widget has,
     * so the content is sized from that room instead of fixed numbers: it never overflows.
     */
    fun contentScale(ctx: Context, id: Int, kind: Kind): Float {
        val o = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id) ?: return 1f
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).toFloat()
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).toFloat()
        if (w <= 0f || h <= 0f) return 1f
        val (rw, rh) = when (kind) {
            Kind.COMPACT -> 180f to 76f
            Kind.LARGE -> 170f to 170f
            Kind.WIDE -> 320f to 170f
        }
        return minOf(w / rw, h / rh).coerceIn(0.62f, 1f)
    }

    private const val DIP = TypedValue.COMPLEX_UNIT_DIP

    fun build(ctx: Context, id: Int, kind: Kind): RemoteViews {
        val phase = Phase.current()
        val look = Looks.compute(phase, Prefs.blur(ctx, id), Prefs.darkTint(ctx, id))
        val compact = kind == Kind.COMPACT
        val s = contentScale(ctx, id, kind)
        val density = ctx.resources.displayMetrics.density

        val rv = RemoteViews(ctx.packageName, if (compact) R.layout.widget_compact else R.layout.widget_card)

        rv.setImageViewResource(R.id.bg, phase.bgRes(compact, look.dark))
        rv.setFloat(R.id.bg, "setAlpha", look.gradAlpha)

        // Root = One UI blur host. Alpha stays 1..254 so the launcher keeps blurring behind it.
        rv.setInt(android.R.id.background, "setBackgroundColor", look.rootColor)

        rv.setImageViewResource(R.id.badge, phase.badge)

        rv.setTextViewText(R.id.title, if (compact) phase.compactTitle else phase.widgetTitle)
        rv.setTextColor(R.id.title, look.titleColor)

        if (compact) {
            val b = 52f * s
            rv.setViewLayoutWidth(R.id.badge, b, DIP)
            rv.setViewLayoutHeight(R.id.badge, b, DIP)
            rv.setViewLayoutMargin(R.id.title, RemoteViews.MARGIN_START, 10f * s, DIP)
        } else {
            val b = 48f * s
            rv.setViewLayoutWidth(R.id.badge, b, DIP)
            rv.setViewLayoutHeight(R.id.badge, b, DIP)
            rv.setViewLayoutMargin(R.id.badge, RemoteViews.MARGIN_START, 16f * s, DIP)
            rv.setViewLayoutMargin(R.id.badge, RemoteViews.MARGIN_TOP, 16f * s, DIP)
            val pad = (16f * s * density).toInt()
            rv.setViewPadding(R.id.text_block, pad, 0, pad, pad)

            rv.setTextViewText(R.id.subtitle, phase.widgetSubtitle)
            rv.setTextColor(R.id.subtitle, look.subColor)
            val wide = kind == Kind.WIDE
            // dp (not sp): the widget must not grow with the system font size
            rv.setTextViewTextSize(R.id.title, DIP, (if (wide) 24f else 20f) * s)
            rv.setTextViewTextSize(R.id.subtitle, DIP, (if (wide) 15f else 13f) * s)
        }

        val open = PendingIntent.getActivity(
            ctx, 100,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(android.R.id.background, open)
        return rv
    }
}

/** ONE provider for 2x1, 2x2 and 4x2, so the widget picker shows them together in one frame. */
class NowBriefWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Refresher.updateWidget(context, id)
        PhaseScheduler.scheduleNext(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        Refresher.updateWidget(context, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        PhaseScheduler.scheduleNext(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Prefs.clearWidget(context, id)
    }
}
