package com.example.nowbrief

import android.app.Activity
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowInsetsController
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class Category(val key: String, val name: String, val color: Int)

object Categories {
    val ALL = listOf(
        Category("health", "Health and wellness", 0xFF34A853.toInt()),
        Category("travel", "Travel", 0xFF2F80ED.toInt()),
        Category("events", "Events and tasks", 0xFF3B82F6.toInt()),
        Category("wellbeing", "Digital Wellbeing", 0xFFF5821F.toInt()),
        Category("communication", "Communication", 0xFFE5483B.toInt()),
        Category("moments", "Moments", 0xFF14A89B.toInt()),
        Category("gallery", "Gallery stories", 0xFF19B8A6.toInt()),
        Category("parking", "Parking spot reminders", 0xFFE53935.toInt()),
        Category("news", "News", 0xFFD94A3D.toInt()),
        Category("smarthome", "Smart home", 0xFFF4B400.toInt()),
        Category("music", "Music and podcasts", 0xFF8E44AD.toInt())
    )
}

/** "Content to include": which card categories the briefing may show. */
class ContentActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        setContentView(R.layout.activity_content)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        findViewById<View>(R.id.content_root).applySystemBarPadding()
        window.insetsController?.setSystemBarsAppearance(
            if (night) 0 else WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )
        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }

        val list = findViewById<LinearLayout>(R.id.list)
        val inflater = LayoutInflater.from(this)
        for ((i, c) in Categories.ALL.withIndex()) {
            val row = inflater.inflate(R.layout.row_category, list, false)
            val dot = GradientDrawable()
            dot.shape = GradientDrawable.OVAL
            dot.setColor(c.color)
            row.findViewById<View>(R.id.dot).background = dot
            row.findViewById<TextView>(R.id.name).text = c.name
            val sw = row.findViewById<Switch>(R.id.sw)
            sw.isChecked = Prefs.category(this, c.key)
            sw.setOnCheckedChangeListener { _, checked -> Prefs.setCategory(this, c.key, checked) }
            row.setOnClickListener { sw.toggle() }
            list.addView(row)
            if (i < Categories.ALL.size - 1) {
                val div = View(this)
                div.setBackgroundColor(resources.getColor(R.color.divider, theme))
                list.addView(div, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
            }
        }
    }
}
