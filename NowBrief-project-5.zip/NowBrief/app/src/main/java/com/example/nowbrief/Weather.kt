package com.example.nowbrief

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class HourPoint(val label: String, val temp: Int, val code: Int, val isDay: Boolean)

class WeatherData(
    val city: String,
    val temp: Int,
    val code: Int,
    val isDay: Boolean,
    val hi: Int,
    val lo: Int,
    val hours: List<HourPoint>,
    val sunLine: String
)

/** Open-Meteo weather (no API key). Cached for 30 minutes; location is approximate. */
object WeatherRepo {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private const val MAX_AGE_MS = 30 * 60 * 1000L

    fun hasLocationPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun condition(code: Int): String = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Showers"
        85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorms"
        else -> "Cloudy"
    }

    fun iconAsset(code: Int, isDay: Boolean): String {
        val n = when (code) {
            0 -> if (isDay) "sunny" else "clear"
            1 -> if (isDay) "mostly_sunny" else "mostly_clear"
            2 -> if (isDay) "partly_cloud" else "partly_cloud_night"
            3 -> if (isDay) "cloudy" else "mostly_cloudy_night"
            45, 48 -> "fog"
            51, 53, 55, 56, 57, 80, 81 -> "shower"
            61, 63 -> "rain"
            65, 67, 82 -> "heavy_rain"
            66 -> "rain_and_sleet"
            71, 77, 85 -> "light_snow"
            73 -> "snow"
            75, 86 -> "heavy_snow"
            95 -> "thunderstorm"
            96, 99 -> "hail"
            else -> "cloudy"
        }
        return "weather/$n.json"
    }

    private fun sp(c: Context) = c.getSharedPreferences("weather_cache", Context.MODE_PRIVATE)

    private fun hm(t: String): String {
        val h = t.substring(11, 13).toInt()
        val m = t.substring(14, 16)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return h12.toString() + ":" + m + " " + (if (h < 12) "AM" else "PM")
    }

    private fun parse(raw: String, city: String): WeatherData? {
        try {
            val j = JSONObject(raw)
            val cur = j.getJSONObject("current")
            val now = cur.getString("time")
            val hourly = j.getJSONObject("hourly")
            val times = hourly.getJSONArray("time")
            val temps = hourly.getJSONArray("temperature_2m")
            val codes = hourly.getJSONArray("weather_code")
            val days = hourly.getJSONArray("is_day")
            val floor = now.substring(0, 13) + ":00"
            var start = 0
            for (i in 0 until times.length()) {
                if (times.getString(i) >= floor) {
                    start = i
                    break
                }
            }
            val hours = ArrayList<HourPoint>()
            var i = start
            while (i < times.length() && hours.size < 6) {
                hours.add(
                    HourPoint(
                        hm(times.getString(i)),
                        Math.round(temps.getDouble(i)).toInt(),
                        codes.getInt(i),
                        days.getInt(i) == 1
                    )
                )
                i++
            }
            val daily = j.getJSONObject("daily")
            val sunset = daily.getJSONArray("sunset").getString(0)
            val sun = if (now < sunset) {
                "Sunset at " + hm(sunset)
            } else {
                "Sunrise at " + hm(daily.getJSONArray("sunrise").getString(1))
            }
            return WeatherData(
                city,
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.getInt("weather_code"),
                cur.getInt("is_day") == 1,
                Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0)).toInt(),
                Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0)).toInt(),
                hours,
                sun
            )
        } catch (e: Exception) {
            return null
        }
    }

    fun cached(ctx: Context): WeatherData? {
        val raw = sp(ctx).getString("raw", null) ?: return null
        return parse(raw, sp(ctx).getString("city", "") ?: "")
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(ctx: Context): Location? {
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try {
                lm.getLastKnownLocation(p)
            } catch (e: Exception) {
                null
            }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        return best
    }

    private fun saveCoords(ctx: Context, lat: Double, lon: Double) {
        sp(ctx).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    private fun savedCoords(ctx: Context): Pair<Double, Double>? {
        val la = sp(ctx).getString("lat", null)?.toDoubleOrNull() ?: return null
        val lo = sp(ctx).getString("lon", null)?.toDoubleOrNull() ?: return null
        return la to lo
    }

    @SuppressLint("MissingPermission")
    private fun findLocation(ctx: Context): Pair<Double, Double>? {
        if (!hasLocationPermission(ctx)) return savedCoords(ctx)
        val last = lastKnown(ctx)
        if (last != null) {
            saveCoords(ctx, last.latitude, last.longitude)
            return last.latitude to last.longitude
        }
        val saved = savedCoords(ctx)
        if (saved != null) return saved
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val latch = CountDownLatch(1)
        var result: Location? = null
        try {
            lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, ctx.mainExecutor) { loc ->
                result = loc
                latch.countDown()
            }
            latch.await(8, TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        val l = result ?: return null
        saveCoords(ctx, l.latitude, l.longitude)
        return l.latitude to l.longitude
    }

    private fun fetchRaw(lat: Double, lon: Double): String? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
            "&current=temperature_2m,weather_code,is_day" +
            "&hourly=temperature_2m,weather_code,is_day" +
            "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset" +
            "&timezone=auto&forecast_days=2"
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            return if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            return null
        } finally {
            c?.disconnect()
        }
    }

    @Suppress("DEPRECATION")
    private fun cityName(ctx: Context, lat: Double, lon: Double): String {
        try {
            val a = Geocoder(ctx, Locale.ENGLISH).getFromLocation(lat, lon, 1)?.firstOrNull()
            return a?.locality ?: a?.subAdminArea ?: a?.adminArea ?: "Your location"
        } catch (e: Exception) {
            return "Your location"
        }
    }

    /** Calls onResult on the main thread: first with the cache (if any), then with fresh data. */
    fun refresh(ctx: Context, force: Boolean, onResult: (WeatherData?) -> Unit) {
        val app = ctx.applicationContext
        val c = cached(app)
        if (c != null) onResult(c)
        val age = System.currentTimeMillis() - sp(app).getLong("ts", 0L)
        if (c != null && !force && age < MAX_AGE_MS) return
        io.execute {
            val loc = findLocation(app)
            val raw = if (loc != null) fetchRaw(loc.first, loc.second) else null
            if (loc == null || raw == null) {
                ui.post { if (c == null) onResult(null) }
            } else {
                val city = cityName(app, loc.first, loc.second)
                sp(app).edit().putString("raw", raw).putString("city", city)
                    .putLong("ts", System.currentTimeMillis()).apply()
                val d = parse(raw, city)
                ui.post { onResult(d ?: c) }
            }
        }
    }
}
