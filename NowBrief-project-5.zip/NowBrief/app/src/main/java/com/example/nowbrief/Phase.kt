package com.example.nowbrief

import android.graphics.Color
import java.util.Calendar

/** Time-of-day phases. Change the hours in STARTS / at() if you want other boundaries. */
enum class Phase(
    val pageTitle: String,
    val pageSubtitle: String,
    val compactTitle: String,
    val widgetTitle: String,
    val widgetSubtitle: String,
    val badge: Int,
    val pillBg: Int,
    val cardBg: Int,
    val darkText: Boolean,
    val pageTop: Int,
    val pageBottom: Int
) {
    MORNING(
        "Morning panel", "Start your day with this briefing.",
        "Good morning", "Sunny morning", "Open your latest morning update.",
        R.drawable.badge_morning, R.drawable.bg_pill_morning, R.drawable.bg_card_morning,
        true, 0xFF92A5AB.toInt(), 0xFF5E7376.toInt()
    ),
    MIDDAY(
        "Midday update", "Enjoy the rest of your day.",
        "Midday update", "Midday update", "Open the midday briefing for the rest of the day.",
        R.drawable.badge_day, R.drawable.bg_pill_midday, R.drawable.bg_card_midday,
        true, 0xFF96A79D.toInt(), 0xFF6E8569.toInt()
    ),
    AFTERNOON(
        "Afternoon feed", "Enjoy the rest of your day.",
        "Good afternoon", "Good afternoon", "Open the afternoon update and keep moving.",
        R.drawable.badge_day, R.drawable.bg_pill_afternoon, R.drawable.bg_card_afternoon,
        true, 0xFF9191AD.toInt(), 0xFF67646F.toInt()
    ),
    EVENING(
        "Evening overview", "Here's a recap of your day.",
        "Good evening", "Good evening", "Here's a recap of your day.",
        R.drawable.badge_day, R.drawable.bg_pill_evening, R.drawable.bg_card_evening,
        true, 0xFF3A4A5F.toInt(), 0xFF17353A.toInt()
    ),
    LATE_NIGHT(
        "Final update", "Enjoy a peaceful and restful night.",
        "End of the day", "Late night recap", "Open the quiet wrap-up for the end of the day.",
        R.drawable.badge_night, R.drawable.bg_pill_night, R.drawable.bg_card_night,
        false, 0xFF2B3E4C.toInt(), 0xFF0F282D.toInt()
    );

    companion object {
        private val STARTS = intArrayOf(5, 11, 15, 18, 21)

        fun at(hour: Int): Phase = when (hour) {
            in 5..10 -> MORNING
            in 11..14 -> MIDDAY
            in 15..17 -> AFTERNOON
            in 18..20 -> EVENING
            else -> LATE_NIGHT
        }

        fun current(): Phase = at(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))

        private fun atHour(base: Long, hour: Int, addDays: Int): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = base
            c.add(Calendar.DAY_OF_YEAR, addDays)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        /** The next moment the phase changes. */
        fun nextBoundaryMillis(now: Long): Long {
            for (h in STARTS) {
                val t = atHour(now, h, 0)
                if (t > now) return t
            }
            return atHour(now, STARTS[0], 1)
        }
    }
}

/** Page background / title by the clock, from the original app's four screens (07-12, 12-17, 17-18, 18-07). */
enum class PageTheme(val bg: Int, val light: Boolean) {
    MORNING(R.drawable.page_bg_morning, true),
    MIDDAY(R.drawable.page_bg_midday, true),
    AFTERNOON(R.drawable.page_bg_afternoon, true),
    NIGHT(R.drawable.page_bg_night, false);

    companion object {
        fun at(hour: Int): PageTheme = when (hour) {
            in 7..11 -> MORNING
            in 12..16 -> MIDDAY
            17 -> AFTERNOON
            else -> NIGHT
        }

        fun title(hour: Int): Pair<String, String> = when (hour) {
            in 7..11 -> "Start of morning" to "Start your day with this briefing."
            in 12..16 -> "Midday update" to "Enjoy the rest of your day."
            17 -> "Afternoon feed" to "Enjoy the rest of your day."
            in 18..20 -> "Evening overview" to "Here's a recap of your day."
            in 21..23 -> "Final update" to "Enjoy a peaceful and restful night."
            else -> "Low activity" to "Enjoy a peaceful and restful night."
        }
    }
}

/** How a widget looks for a given blur amount (0..100) and Dark/Light choice. */
class Look(
    val gradAlpha: Float,
    val rootColor: Int,
    val titleColor: Int,
    val subColor: Int
)

object Looks {
    /**
     * One UI Home draws its wallpaper blur under the widget root (@android:id/background)
     * only while that root's background alpha is within 1..254. So rootColor always stays in that range.
     * The blur strength itself is fixed by One UI; the slider fades the phase gradient on top of it.
     */
    fun compute(phase: Phase, blur: Int, dark: Boolean): Look {
        val b = blur.coerceIn(0, 100) / 100f
        val gradAlpha = 1f - b
        val a = (1f + b * (if (dark) 0.40f else 0.34f) * 254f).toInt().coerceIn(1, 254)
        val rootColor = if (dark) Color.argb(a, 0, 0, 0) else Color.argb(a, 255, 255, 255)
        val onTint = b >= 0.5f
        val title = if (onTint) {
            if (dark) Color.WHITE else 0xFF111111.toInt()
        } else {
            if (phase.darkText) 0xFF111111.toInt() else Color.WHITE
        }
        val sub = (title and 0x00FFFFFF) or (0xB8 shl 24)
        return Look(gradAlpha, rootColor, title, sub)
    }
}
