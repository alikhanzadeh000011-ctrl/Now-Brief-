package com.example.nowbrief

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews

enum class Kind { COMPACT, LARGE, WIDE }

object WidgetRenderer {

    fun build(ctx: Context, id: Int, kind: Kind): RemoteViews {
        val phase = Phase.current()
        val look = Looks.compute(phase, Prefs.blur(ctx, id), Prefs.darkTint(ctx, id))
        val compact = kind == Kind.COMPACT

        val rv = RemoteViews(ctx.packageName, if (compact) R.layout.widget_compact else R.layout.widget_card)

        rv.setImageViewResource(R.id.bg, if (compact) phase.pillBg else phase.cardBg)
        rv.setFloat(R.id.bg, "setAlpha", look.gradAlpha)

        // Root = One UI blur host. Alpha stays 1..254 so the launcher keeps blurring behind it.
        rv.setInt(android.R.id.background, "setBackgroundColor", look.rootColor)

        rv.setImageViewResource(R.id.badge, phase.badge)

        rv.setTextViewText(R.id.title, if (compact) phase.compactTitle else phase.widgetTitle)
        rv.setTextColor(R.id.title, look.titleColor)

        if (!compact) {
            rv.setTextViewText(R.id.subtitle, phase.widgetSubtitle)
            rv.setTextColor(R.id.subtitle, look.subColor)
            val wide = kind == Kind.WIDE
            rv.setTextViewTextSize(R.id.title, TypedValue.COMPLEX_UNIT_SP, if (wide) 24f else 20f)
            rv.setTextViewTextSize(R.id.subtitle, TypedValue.COMPLEX_UNIT_SP, if (wide) 15f else 13f)
        }

        val open = PendingIntent.getActivity(
            ctx, 100,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(android.R.id.background, open)
        return rv
    }
}

/** ONE provider for 2x1, 2x2 and 4x2, so the widget picker shows them together in one frame. */
class NowBriefWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Refresher.updateWidget(context, id)
        PhaseScheduler.scheduleNext(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        Refresher.updateWidget(context, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        PhaseScheduler.scheduleNext(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Prefs.clearWidget(context, id)
    }
}
