package com.example.nowbrief

import android.content.Context
import android.view.View
import android.view.WindowInsets

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Keeps content clear of the status/navigation bars (edge-to-edge on Android 15+). */
fun View.applySystemBarPadding() {
    val l = paddingLeft
    val t = paddingTop
    val r = paddingRight
    val b = paddingBottom
    setOnApplyWindowInsetsListener { v, insets ->
        val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        v.setPadding(l + bars.left, t + bars.top, r + bars.right, b + bars.bottom)
        insets
    }
    requestApplyInsets()
}
