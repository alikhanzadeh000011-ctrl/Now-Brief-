package com.example.nowbrief

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** The briefing page: phase background, sparkles, title, cards, small glass buttons. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_FROM_NOW_BAR = "from_now_bar"
    }

    private var stars: AnimatedImageDrawable? = null
    private var weatherView: View? = null
    private var alarmView: View? = null
    private var page: PageTheme = PageTheme.MORNING
    private var ink: Int = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        if (intent?.getBooleanExtra(EXTRA_FROM_NOW_BAR, false) == true && Prefs.expandWithoutUnlock(this)) {
            setShowWhenLocked(true)
        }
        setContentView(R.layout.activity_main)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        page = PageTheme.at(hour)
        val titles = PageTheme.title(hour)
        ink = if (page.light) 0xFF161616.toInt() else Color.WHITE

        findViewById<ImageView>(R.id.page_bg).setImageResource(page.bg)
        findViewById<View>(R.id.scroll).applySystemBarPadding()
        findViewById<View>(R.id.overlay_root).applySystemBarPadding()

        val title = findViewById<TextView>(R.id.main_title)
        title.text = titles.first
        title.setTextColor(ink)
        val sub = findViewById<TextView>(R.id.main_sub)
        sub.text = titles.second
        sub.setTextColor((ink and 0x00FFFFFF) or (0xE6 shl 24))

        val glass = if (page.light) R.drawable.glass_circle_light else R.drawable.glass_circle_dark
        for (id in intArrayOf(R.id.btn_audio, R.id.btn_info, R.id.btn_settings)) {
            findViewById<ImageButton>(id).setBackgroundResource(glass)
        }

        val bars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (page.light) bars else 0, bars)

        loadStars()
        buildCards()

        findViewById<View>(R.id.btn_audio).setOnClickListener {
            Toast.makeText(this, "Audio brief comes in a later part", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btn_info).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Now Brief")
                .setMessage("This briefing is built on your phone from the weather, your alarms and more cards in the next packages.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 11)
    }

    private fun buildCards() {
        val cards = findViewById<LinearLayout>(R.id.cards)
        cards.removeAllViews()

        cards.addView(Cards.label(this, "Here's your weather update.", ink))
        val w = layoutInflater.inflate(R.layout.card_weather, cards, false)
        Cards.styleWeather(this, w, page)
        Cards.bindWeather(this, w, null, true)
        cards.addView(w)
        weatherView = w

        alarmView = null
        if (Prefs.category(this, "events")) {
            cards.addView(Cards.label(this, "Here's your next alarm.", ink))
            val a = layoutInflater.inflate(R.layout.card_alarm, cards, false)
            Cards.styleAlarm(this, a, page)
            cards.addView(a)
            alarmView = a
        }
    }

    private fun loadWeather(force: Boolean) {
        WeatherRepo.refresh(this, force) { d ->
            val w = weatherView
            if (!isDestroyed && w != null) Cards.bindWeather(this, w, d, false)
        }
    }

    private fun loadStars() {
        try {
            val src = ImageDecoder.createSource(resources, R.raw.brief_stars)
            val d = ImageDecoder.decodeDrawable(src)
            findViewById<ImageView>(R.id.sparkles).setImageDrawable(d)
            if (d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                stars = d
            }
        } catch (e: Exception) {
            // keeps the static sparkles vector from the layout
        }
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(this)
        stars?.start()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(false)
    }

    override fun onPause() {
        stars?.stop()
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Refresher.refreshAll(this)
        loadWeather(true)
    }
}
