package com.example.nowbrief

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.UnderlineSpan
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsetsController
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView

/** The "Now brief settings" page, laid out like Samsung's. */
class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        setContentView(R.layout.activity_settings)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        findViewById<View>(R.id.settings_root).applySystemBarPadding()
        window.insetsController?.setSystemBarsAppearance(
            if (night) 0 else WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )

        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<View>(R.id.row_content).setOnClickListener {
            startActivity(Intent(this, ContentActivity::class.java))
        }
        loadHero(night)

        val terms = findViewById<TextView>(R.id.tv_terms)
        val full = getString(R.string.settings_terms)
        val sp = SpannableString(full)
        val key = "Terms and Conditions"
        val at = full.indexOf(key)
        if (at >= 0) sp.setSpan(UnderlineSpan(), at, at + key.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        terms.text = sp
        terms.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.samsung.com/global/galaxy/galaxy-ai/")))
            } catch (e: Exception) {
            }
        }

        bind(R.id.sw_audio, Prefs.audioBrief(this)) { Prefs.setAudioBrief(this, it) }
        bind(R.id.sw_expand, Prefs.expandWithoutUnlock(this)) { Prefs.setExpandWithoutUnlock(this, it) }
        bind(R.id.sw_nowbar, Prefs.nowBar(this)) {
            Prefs.setNowBar(this, it)
            Refresher.refreshAll(this)
        }

        findViewById<View>(R.id.row_rows_more).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
            }
        }
        findViewById<View>(R.id.row_live_notif).setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            } catch (e: Exception) {
            }
        }
        // each row also toggles its switch when tapped
        findViewById<View>(R.id.row_audio).setOnClickListener { findViewById<Switch>(R.id.sw_audio).toggle() }
        findViewById<View>(R.id.row_expand).setOnClickListener { findViewById<Switch>(R.id.sw_expand).toggle() }
        findViewById<View>(R.id.row_nowbar).setOnClickListener { findViewById<Switch>(R.id.sw_nowbar).toggle() }
    }

    private fun bind(id: Int, initial: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun loadHero(night: Boolean) {
        val iv = findViewById<ImageView>(R.id.hero)
        val radius = dp(24).toFloat()
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        iv.clipToOutline = true
        try {
            val res = if (night) R.raw.settings_hero_dark else R.raw.settings_hero_light
            val src = ImageDecoder.createSource(resources, res)
            val d = ImageDecoder.decodeDrawable(src) { decoder, _, _ -> decoder.setTargetSampleSize(2) }
            iv.setImageDrawable(d)
            if (d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                d.start()
            }
        } catch (e: Exception) {
        }
    }
}
