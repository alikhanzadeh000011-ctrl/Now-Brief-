package com.example.nowbrief

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

object Refresher {

    /** Which layout a widget should use, from its current size (in dp). */
    fun kindOf(ctx: Context, id: Int): Kind {
        val o = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id)
        val w = o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0) ?: 0
        val h = o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) ?: 0
        return when {
            h in 1..120 -> Kind.COMPACT
            w >= 240 -> Kind.WIDE
            else -> Kind.LARGE
        }
    }

    fun updateWidget(ctx: Context, id: Int) {
        AppWidgetManager.getInstance(ctx).updateAppWidget(id, WidgetRenderer.build(ctx, id, kindOf(ctx, id)))
    }

    /** Redraws every widget, re-posts the Now bar notification and schedules the next phase change. */
    fun refreshAll(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        for (id in mgr.getAppWidgetIds(ComponentName(app, NowBriefWidgetProvider::class.java))) {
            updateWidget(app, id)
        }
        NowBarNotifier.post(app)
        PhaseScheduler.scheduleNext(app)
    }
}

object PhaseScheduler {
    const val ACTION_TICK = "com.example.nowbrief.action.PHASE_TICK"

    fun tickIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, PhaseReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun scheduleNext(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        val at = Phase.nextBoundaryMillis(System.currentTimeMillis()) + 5_000L
        // Inexact alarm: needs no special permission, may fire a little late in Doze.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, tickIntent(app))
    }
}

class PhaseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Refresher.refreshAll(context)
    }
}
