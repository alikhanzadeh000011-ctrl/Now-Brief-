plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.nowbrief"
    compileSdk = 35

    defaultConfig {
        // com.kakao.taxi is on One UI's Live notifications list, so keep this id.
        applicationId = "com.kakao.taxi"
        minSdk = 31
        targetSdk = 35
        versionCode = 7
        versionName = "2.0-cards1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Lottie plays the original app's animated weather icons
    implementation("com.airbnb.android:lottie:6.4.0")
}
