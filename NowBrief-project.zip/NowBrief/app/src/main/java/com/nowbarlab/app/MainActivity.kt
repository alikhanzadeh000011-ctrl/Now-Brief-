package com.nowbarlab.app

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/**
 * Now Bar Lab: one screen, every knob that might change how Samsung's Now bar
 * (Live notifications) draws the capsule. Everything is saved on change; "Post"
 * sends one ongoing notification (id 1) built from the saved values.
 */
class MainActivity : Activity() {

    companion object {
        const val NOTIF_ID = 1
        const val PICK_REQ = 11
        const val P = "android.ongoingActivityNoti."

        val DEF: Map<String, Any> = mapOf(
            // texts
            "contentTitle" to "Good morning",
            "contentText" to "Get today's highlight",
            "subText" to "",
            "primaryInfo" to "Now Bar Lab",
            "secondaryInfo" to "Secondary info",
            "nbPrimary" to "Now Bar Lab",
            "nbSecondary" to "Hello from the Now bar",
            "chipText" to "Lab",
            "critical" to "Lab",
            // colors
            "notifColor" to "#FF7C4DFF",
            "colorized" to true,
            "chipColor" to "#FF3DB59A",
            "iconColor" to "#FFFFFFFF",
            // icons: 0 app icon, 1 circle, 2 star, 3 heart, 4 bolt, 5 gallery image
            "smallIconSrc" to 2,
            "chipIconSrc" to 2,
            "nbIconSrc" to 2,
            "firstIconSrc" to 2,
            "largeIconOn" to false,
            "largeIconSrc" to 1,
            // samsung extras
            "extrasOn" to true,
            "style" to "1",
            "showSmallIcon" to true,
            "promoted" to true,
            "semFlags" to true,
            // notification basics
            "ongoing" to true,
            "onlyAlert" to true,
            "category" to 1,
            "importance" to 0,
            "visibility" to 0,
            // progress / time
            "progressOn" to false,
            "progressVal" to 40,
            "progressIndet" to false,
            "chrono" to false,
            "showWhenOn" to false,
            // look
            "styleKind" to 0,
            "actions" to false,
            "customTextColor" to "#FFFFFFFF",
            // free-form extras
            "custom" to ("# One extra per line, format  type:key=value\n" +
                "# types: s=string i=int l=long f=float b=bool c=color ic=icon(0-5)\n" +
                "# Remove the # to activate a line. These keys are GUESSES, they may do nothing:\n" +
                "# i:android.ongoingActivityNoti.progress=40\n" +
                "# i:android.ongoingActivityNoti.progressMax=100\n" +
                "# c:android.ongoingActivityNoti.nowbarBgColor=#FFFF0000\n" +
                "# c:android.ongoingActivityNoti.nowbarPrimaryInfoColor=#FFFFFFFF\n" +
                "# ic:android.ongoingActivityNoti.secondaryInfoIcon=2\n" +
                "# s:android.ongoingActivityNoti.actionType=1\n")
        )
    }

    private lateinit var sp: SharedPreferences
    private lateinit var box: LinearLayout

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun gs(k: String): String = sp.getString(k, DEF[k] as String) ?: ""
    private fun gb(k: String): Boolean = sp.getBoolean(k, DEF[k] as Boolean)
    private fun gi(k: String): Int = sp.getInt(k, DEF[k] as Int)
    private fun gc(k: String): Int = try {
        Color.parseColor(gs(k).trim())
    } catch (e: Exception) {
        Color.WHITE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("lab", MODE_PRIVATE)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(40))
        val scroll = ScrollView(this)
        scroll.addView(box)
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val bars = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            ins
        }
        setContentView(scroll)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        build()
    }

    // ---------------------------------------------------------------- UI helpers

    private fun lbl(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setTextColor(0xFF555555.toInt())
        tv.setPadding(0, dp(10), 0, 0)
        return tv
    }

    private fun header(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 18f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setTextColor(0xFF5E35B1.toInt())
        tv.setPadding(0, dp(26), 0, dp(2))
        box.addView(tv)
    }

    private fun note(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 12.5f
        tv.setTextColor(0xFF777777.toInt())
        box.addView(tv)
    }

    private fun field(title: String, key: String, multiline: Boolean = false) {
        box.addView(lbl(title))
        val e = EditText(this)
        e.setText(gs(key))
        if (multiline) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            e.minLines = 8
            e.gravity = Gravity.TOP or Gravity.START
            e.typeface = Typeface.MONOSPACE
            e.textSize = 12f
        } else {
            e.setSingleLine(true)
            e.textSize = 15f
        }
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                sp.edit().putString(key, s?.toString() ?: "").apply()
            }
        })
        box.addView(e)
    }

    private fun sw(title: String, key: String) {
        val s = Switch(this)
        s.text = title
        s.textSize = 15f
        s.isChecked = gb(key)
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply() }
        box.addView(s)
    }

    private fun choice(title: String, key: String, opts: List<String>) {
        box.addView(lbl(title))
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        spin.setSelection(gi(key))
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                sp.edit().putInt(key, pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(spin)
    }

    private fun slider(title: String, key: String, max: Int) {
        val t = lbl("$title: ${gi(key)}")
        box.addView(t)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = gi(key)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                t.text = "$title: $p"
                sp.edit().putInt(key, p).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb)
    }

    private fun btn(text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        box.addView(b)
    }

    private val iconOptions = listOf("App icon", "Circle", "Star", "Heart", "Bolt", "Gallery image")

    // ---------------------------------------------------------------- screen

    private fun build() {
        val title = TextView(this)
        title.text = "Now Bar Lab"
        title.textSize = 26f
        title.setTypeface(null, Typeface.BOLD)
        title.setPadding(0, dp(12), 0, 0)
        box.addView(title)
        note("Package: $packageName\nEverything is saved as you type. Tap Post, then lock the phone and look at the Now bar. Change something and tap Post again to update.")

        btn("Post / update notification") { post() }
        btn("Remove notification") {
            getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
            toast("Removed")
        }
        btn("Open this app's notification settings") {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        header("Image from gallery")
        note("Used by icons set to \"Gallery image\", the big picture style and the custom view background.")
        btn("Pick image") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(Intent.createChooser(i, "Pick image"), PICK_REQ)
        }

        header("Texts")
        field("Notification title (contentTitle)", "contentTitle")
        field("Notification text (contentText)", "contentText")
        field("Sub text (subText), empty = none", "subText")
        field("primaryInfo", "primaryInfo")
        field("secondaryInfo", "secondaryInfo")
        field("nowbarPrimaryInfo (capsule title)", "nbPrimary")
        field("nowbarSecondaryInfo (capsule subtitle)", "nbSecondary")
        field("chipExpandedText (status bar chip)", "chipText")
        field("shortCriticalText", "critical")

        header("Colors")
        note("Hex like #FF3DB59A (alpha first).")
        field("Notification color (setColor)", "notifColor")
        sw("Colorized (setColorized)", "colorized")
        field("chipBgColor (status bar chip)", "chipColor")
        field("Drawn icon color (circle, star, heart, bolt)", "iconColor")

        header("Icons")
        choice("Small icon", "smallIconSrc", iconOptions)
        choice("chipIcon", "chipIconSrc", iconOptions)
        choice("nowbarIcon", "nbIconSrc", iconOptions)
        choice("firstIcon", "firstIconSrc", iconOptions)
        sw("Large icon", "largeIconOn")
        choice("Large icon source", "largeIconSrc", iconOptions)

        header("Samsung Now bar extras")
        sw("Write ongoingActivityNoti extras at all", "extrasOn")
        field("style (int)", "style")
        sw("android.showSmallIcon", "showSmallIcon")
        sw("android.requestPromotedOngoing", "promoted")
        sw("semFlags bit 0x8000 (reflection)", "semFlags")

        header("Notification basics")
        sw("Ongoing", "ongoing")
        sw("Only alert once", "onlyAlert")
        choice(
            "Category", "category",
            listOf("none", "alarm", "call", "progress", "service", "status", "transport", "event", "reminder")
        )
        choice("Channel importance (new channel per value)", "importance", listOf("Low", "Default", "High"))
        choice("Lock screen visibility", "visibility", listOf("Public", "Private", "Secret"))

        header("Progress and time")
        sw("Progress bar", "progressOn")
        slider("Progress", "progressVal", 100)
        sw("Indeterminate progress", "progressIndet")
        sw("Chronometer (counts up)", "chrono")
        sw("Show time (setShowWhen)", "showWhenOn")

        header("Look")
        choice(
            "Style", "styleKind",
            listOf("None", "Big text", "Big picture (gallery image)", "Custom view with image background")
        )
        field("Custom view text color", "customTextColor")
        sw("Two action buttons", "actions")

        header("Free-form extras")
        note("Add any extra key yourself to test unknown Samsung keys.")
        field("Extras", "custom", multiline = true)

        header("Reset")
        btn("Reset everything to defaults") {
            sp.edit().clear().apply()
            recreate()
        }
    }

    // ---------------------------------------------------------------- gallery image

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_REQ || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bm = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bm == null) {
                toast("Could not read the image")
                return
            }
            val big = maxOf(bm.width, bm.height)
            val out = if (big > 1024) {
                val s = 1024f / big
                Bitmap.createScaledBitmap(bm, (bm.width * s).toInt(), (bm.height * s).toInt(), true)
            } else bm
            FileOutputStream(File(filesDir, "pick.png")).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("Image saved")
        } catch (e: Exception) {
            toast("Failed: ${e.message}")
        }
    }

    private fun loadPick(): Bitmap? {
        val f = File(filesDir, "pick.png")
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun cover(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val sc = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * sc
        val dh = src.height * sc
        c.drawBitmap(src, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ---------------------------------------------------------------- icons

    private fun shapeBitmap(kind: Int, color: Int): Bitmap {
        val sz = 192
        val bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.style = Paint.Style.FILL
        when (kind) {
            2 -> {
                val path = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 90f else 38f
                    val a = -Math.PI / 2 + i * Math.PI / 5
                    val x = (96 + r * Math.cos(a)).toFloat()
                    val y = (96 + r * Math.sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                c.drawPath(path, p)
            }
            3 -> {
                val path = Path()
                path.moveTo(96f, 172f)
                path.cubicTo(-10f, 100f, 30f, 10f, 96f, 62f)
                path.cubicTo(162f, 10f, 202f, 100f, 96f, 172f)
                path.close()
                c.drawPath(path, p)
            }
            4 -> {
                val path = Path()
                path.moveTo(112f, 10f)
                path.lineTo(40f, 106f)
                path.lineTo(92f, 106f)
                path.lineTo(72f, 182f)
                path.lineTo(152f, 78f)
                path.lineTo(102f, 78f)
                path.close()
                c.drawPath(path, p)
            }
            else -> c.drawCircle(96f, 96f, 84f, p)
        }
        return bm
    }

    private fun iconFrom(src: Int): Icon {
        val color = gc("iconColor")
        return when (src) {
            0 -> Icon.createWithResource(this, R.drawable.ic_launcher)
            5 -> {
                val bm = loadPick()
                if (bm != null) Icon.createWithBitmap(cover(bm, 256, 256))
                else Icon.createWithBitmap(shapeBitmap(1, color))
            }
            else -> Icon.createWithBitmap(shapeBitmap(src, color))
        }
    }

    private fun icon(key: String): Icon = iconFrom(gi(key))

    // ---------------------------------------------------------------- post

    private fun post() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            toast("Allow notifications, then tap Post again")
            return
        }
        val nm = getSystemService(NotificationManager::class.java) ?: return

        val imp = when (gi("importance")) {
            0 -> NotificationManager.IMPORTANCE_LOW
            1 -> NotificationManager.IMPORTANCE_DEFAULT
            else -> NotificationManager.IMPORTANCE_HIGH
        }
        val chId = "nbl_$imp"
        if (nm.getNotificationChannel(chId) == null) {
            val ch = NotificationChannel(chId, "Now Bar Lab (importance $imp)", imp)
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }

        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val b = Notification.Builder(this, chId)
            .setSmallIcon(icon("smallIconSrc"))
            .setContentTitle(gs("contentTitle"))
            .setContentText(gs("contentText"))
            .setContentIntent(open)
            .setOngoing(gb("ongoing"))
            .setOnlyAlertOnce(gb("onlyAlert"))
            .setShowWhen(gb("showWhenOn"))
            .setColor(gc("notifColor"))
            .setColorized(gb("colorized"))
            .setVisibility(
                when (gi("visibility")) {
                    0 -> Notification.VISIBILITY_PUBLIC
                    1 -> Notification.VISIBILITY_PRIVATE
                    else -> Notification.VISIBILITY_SECRET
                }
            )

        val cats = listOf(
            null, Notification.CATEGORY_ALARM, Notification.CATEGORY_CALL, Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE, Notification.CATEGORY_STATUS, Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_EVENT, Notification.CATEGORY_REMINDER
        )
        val cat = cats.getOrNull(gi("category"))
        if (cat != null) b.setCategory(cat)

        if (gs("subText").isNotBlank()) b.setSubText(gs("subText"))
        if (gb("chrono")) {
            b.setUsesChronometer(true)
            b.setShowWhen(true)
            b.setWhen(System.currentTimeMillis())
        }
        if (gb("progressOn")) b.setProgress(100, gi("progressVal"), gb("progressIndet"))
        if (gb("largeIconOn")) b.setLargeIcon(icon("largeIconSrc"))
        if (gb("actions")) {
            b.addAction(Notification.Action.Builder(icon("smallIconSrc"), "Action 1", open).build())
            b.addAction(Notification.Action.Builder(icon("smallIconSrc"), "Action 2", open).build())
        }

        when (gi("styleKind")) {
            1 -> b.setStyle(Notification.BigTextStyle().bigText(gs("contentText") + "\n" + gs("subText")))
            2 -> {
                val bm = loadPick()
                if (bm != null) b.setStyle(Notification.BigPictureStyle().bigPicture(cover(bm, 900, 450)))
                else toast("Pick an image first for Big picture")
            }
            3 -> {
                val rv = RemoteViews(packageName, R.layout.notif_custom)
                rv.setTextViewText(R.id.nb_title, gs("contentTitle"))
                rv.setTextViewText(R.id.nb_text, gs("contentText"))
                rv.setTextColor(R.id.nb_title, gc("customTextColor"))
                rv.setTextColor(R.id.nb_text, gc("customTextColor"))
                val bm = loadPick()
                if (bm != null) rv.setImageViewBitmap(R.id.nb_bg, cover(bm, 720, 144))
                else rv.setInt(R.id.nb_bg, "setBackgroundColor", gc("notifColor"))
                b.setStyle(Notification.DecoratedCustomViewStyle())
                b.setCustomContentView(rv)
                b.setCustomBigContentView(rv)
            }
        }

        val notif = b.build()
        val ex = notif.extras

        if (gb("extrasOn")) {
            ex.putInt(P + "style", gs("style").trim().toIntOrNull() ?: 1)
            ex.putString(P + "primaryInfo", gs("primaryInfo"))
            ex.putString(P + "secondaryInfo", gs("secondaryInfo"))
            ex.putString(P + "nowbarPrimaryInfo", gs("nbPrimary"))
            ex.putString(P + "nowbarSecondaryInfo", gs("nbSecondary"))
            ex.putString(P + "chipExpandedText", gs("chipText"))
            ex.putInt(P + "chipBgColor", gc("chipColor"))
            ex.putParcelable(P + "chipIcon", icon("chipIconSrc"))
            ex.putParcelable(P + "nowbarIcon", icon("nbIconSrc"))
            ex.putParcelable(P + "firstIcon", icon("firstIconSrc"))
            if (gs("critical").isNotBlank()) ex.putString("android.shortCriticalText", gs("critical"))
        }
        if (gb("showSmallIcon")) ex.putBoolean("android.showSmallIcon", true)
        if (gb("promoted")) ex.putBoolean("android.requestPromotedOngoing", true)

        if (gb("semFlags")) {
            try {
                val f = Notification::class.java.getDeclaredField("semFlags")
                f.isAccessible = true
                f.setInt(notif, f.getInt(notif) or 0x8000)
            } catch (e: Throwable) {
            }
        }

        var bad = 0
        for (raw in gs("custom").lines()) {
            val t = raw.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            try {
                val eq = t.indexOf('=')
                val left = t.substring(0, eq).trim()
                val v = t.substring(eq + 1).trim()
                val colon = left.indexOf(':')
                val type = left.substring(0, colon)
                val k = left.substring(colon + 1)
                when (type) {
                    "s" -> ex.putString(k, v)
                    "i" -> ex.putInt(k, v.toInt())
                    "l" -> ex.putLong(k, v.toLong())
                    "f" -> ex.putFloat(k, v.toFloat())
                    "b" -> ex.putBoolean(k, v.toBoolean())
                    "c" -> ex.putInt(k, Color.parseColor(v))
                    "ic" -> ex.putParcelable(k, iconFrom(v.toInt()))
                    else -> bad++
                }
            } catch (e: Exception) {
                bad++
            }
        }

        nm.notify(NOTIF_ID, notif)
        toast(if (bad == 0) "Posted. Lock the phone and check the Now bar" else "Posted ($bad extra lines were invalid)")
    }
}
