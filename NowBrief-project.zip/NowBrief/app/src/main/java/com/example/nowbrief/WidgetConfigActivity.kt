package com.example.nowbrief

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView

/** "Widget settings": Blur 0-100 and Dark/Light, with a live preview. */
class WidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var kind = Kind.LARGE
    private var blur = 0
    private var dark = true
    private lateinit var previewView: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            kind = Refresher.kindOf(this, widgetId)
            blur = Prefs.blur(this, widgetId)
            dark = Prefs.darkTint(this, widgetId)
        }

        setContentView(R.layout.activity_widget_config)
        findViewById<View>(R.id.config_root).applySystemBarPadding()

        val holder = findViewById<FrameLayout>(R.id.preview_holder)
        val compact = kind == Kind.COMPACT
        previewView = LayoutInflater.from(this)
            .inflate(if (compact) R.layout.widget_compact else R.layout.widget_card, holder, false)
        val size = when (kind) {
            Kind.COMPACT -> 230 to 76
            Kind.LARGE -> 170 to 170
            Kind.WIDE -> 300 to 150
        }
        holder.addView(previewView, FrameLayout.LayoutParams(dp(size.first), dp(size.second), Gravity.CENTER))

        val seek = findViewById<SeekBar>(R.id.seek_blur)
        val value = findViewById<TextView>(R.id.tv_blur_value)
        seek.max = 100
        seek.progress = blur
        value.text = "$blur%"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                blur = progress
                value.text = "$progress%"
                applyPreview()
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        val rg = findViewById<RadioGroup>(R.id.rg_color)
        rg.check(if (dark) R.id.rb_dark else R.id.rb_light)
        rg.setOnCheckedChangeListener { _, checkedId ->
            dark = checkedId == R.id.rb_dark
            applyPreview()
        }

        findViewById<View>(R.id.btn_cancel).setOnClickListener { finish() }
        findViewById<View>(R.id.btn_save).setOnClickListener { save() }

        applyPreview()
    }

    private fun applyPreview() {
        val phase = Phase.current()
        val look = Looks.compute(phase, blur, dark)
        val compact = kind == Kind.COMPACT

        val bg = previewView.findViewById<ImageView>(R.id.bg)
        bg.setImageResource(if (compact) phase.pillBg else phase.cardBg)
        bg.alpha = look.gradAlpha

        val tint = previewView.findViewById<ImageView>(R.id.tint)
        tint.setImageResource(WidgetRenderer.tintRes(kind, look.tintDark))
        tint.alpha = look.tintAlpha

        previewView.findViewById<ImageView>(R.id.badge).setImageResource(phase.badge)

        val title = previewView.findViewById<TextView>(R.id.title)
        title.text = if (compact) phase.compactTitle else phase.widgetTitle
        title.setTextColor(look.titleColor)

        if (!compact) {
            val sub = previewView.findViewById<TextView>(R.id.subtitle)
            sub.text = phase.widgetSubtitle
            sub.setTextColor(look.subColor)
            val wide = kind == Kind.WIDE
            title.textSize = if (wide) 24f else 20f
            sub.textSize = if (wide) 15f else 13f
        }
    }

    private fun save() {
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            Prefs.setBlur(this, widgetId, blur)
            Prefs.setDarkTint(this, widgetId, dark)
            Refresher.updateWidget(this, widgetId, kind)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        finish()
    }
}
