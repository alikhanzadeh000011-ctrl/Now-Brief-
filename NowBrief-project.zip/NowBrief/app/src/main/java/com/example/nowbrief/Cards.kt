package com.example.nowbrief

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.provider.AlarmClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** The cards on the briefing page. */
object Cards {

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    fun label(ctx: Context, text: String, ink: Int): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 14.5f
        t.setTextColor(withAlpha(ink, 0xE6))
        t.setPadding(ctx.dp(4), 0, ctx.dp(4), 0)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = ctx.dp(20)
        lp.bottomMargin = ctx.dp(10)
        t.layoutParams = lp
        return t
    }

    // ------------------------------------------------------------------ weather

    fun styleWeather(ctx: Context, v: View, page: PageTheme) {
        val colors = when (page) {
            PageTheme.MORNING, PageTheme.MIDDAY -> intArrayOf(0xFF8CB4FF.toInt(), 0xFF4F7EEB.toInt())
            PageTheme.AFTERNOON -> intArrayOf(0xFFA99CD6.toInt(), 0xFF9783C9.toInt())
            PageTheme.NIGHT -> intArrayOf(0xFF7B73B8.toInt(), 0xFF5E5086.toInt())
        }
        val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
        g.cornerRadius = ctx.dp(28).toFloat()
        g.setStroke(ctx.dp(1), 0x40FFFFFF)
        v.background = g
        v.findViewById<View>(R.id.w_button).setOnClickListener {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.sec.android.daemonapp")
            if (i != null) {
                ctx.startActivity(i)
            } else {
                Toast.makeText(ctx, "No weather app found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun bindWeather(ctx: Context, v: View, d: WeatherData?, loading: Boolean) {
        val icon = v.findViewById<LottieAnimationView>(R.id.w_icon)
        val hours = v.findViewById<LinearLayout>(R.id.w_hours)
        hours.removeAllViews()
        val temp = v.findViewById<TextView>(R.id.w_temp)
        val city = v.findViewById<TextView>(R.id.w_city)
        val cond = v.findViewById<TextView>(R.id.w_cond)
        val hilo = v.findViewById<TextView>(R.id.w_hilo)
        val summary = v.findViewById<TextView>(R.id.w_summary)
        val sun = v.findViewById<TextView>(R.id.w_sun)

        if (d == null) {
            icon.visibility = View.INVISIBLE
            hours.visibility = View.GONE
            temp.text = "--°"
            city.text = ""
            cond.text = ""
            hilo.text = ""
            sun.text = ""
            summary.text = when {
                loading -> "Loading the weather…"
                !WeatherRepo.hasLocationPermission(ctx) -> "Allow location access to see the weather."
                else -> "The weather isn't available right now."
            }
            return
        }

        icon.visibility = View.VISIBLE
        icon.setAnimation(WeatherRepo.iconAsset(d.code, d.isDay))
        icon.repeatCount = LottieDrawable.INFINITE
        icon.playAnimation()

        hours.visibility = View.VISIBLE
        val inf = LayoutInflater.from(ctx)
        for (h in d.hours) {
            val item = inf.inflate(R.layout.item_hour, hours, false)
            item.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            item.findViewById<TextView>(R.id.h_time).text = h.label
            val ic = item.findViewById<LottieAnimationView>(R.id.h_icon)
            ic.setAnimation(WeatherRepo.iconAsset(h.code, h.isDay))
            ic.repeatCount = LottieDrawable.INFINITE
            ic.playAnimation()
            item.findViewById<TextView>(R.id.h_temp).text = h.temp.toString() + "°"
            hours.addView(item)
        }

        temp.text = d.temp.toString() + "°"
        city.text = d.city
        cond.text = WeatherRepo.condition(d.code)
        hilo.text = d.hi.toString() + "° / " + d.lo.toString() + "°"
        summary.text = WeatherRepo.condition(d.code) + " conditions in " + d.city + "."
        sun.text = d.sunLine
    }

    // ------------------------------------------------------------------ alarm

    fun styleAlarm(ctx: Context, v: View, page: PageTheme) {
        val light = page.light
        val g = GradientDrawable()
        g.cornerRadius = ctx.dp(28).toFloat()
        if (light) {
            g.setColor(0x8CFFFFFF.toInt())
        } else {
            g.setColor(0x26FFFFFF)
            g.setStroke(ctx.dp(1), 0x33FFFFFF)
        }
        v.background = g

        val ink = if (light) 0xFF161616.toInt() else 0xFFFFFFFF.toInt()
        v.findViewById<TextView>(R.id.a_title).setTextColor(ink)
        v.findViewById<TextView>(R.id.a_none_text).setTextColor(ink)
        v.findViewById<TextView>(R.id.a_time).setTextColor(ink)
        v.findViewById<TextView>(R.id.a_when).setTextColor(withAlpha(ink, 0xB3))

        val bar = GradientDrawable()
        bar.cornerRadius = ctx.dp(2).toFloat()
        bar.setColor(ink)
        v.findViewById<View>(R.id.a_bar).background = bar

        val dot = GradientDrawable()
        dot.shape = GradientDrawable.OVAL
        dot.setColor(0xFF4E7FF2.toInt())
        v.findViewById<View>(R.id.a_dot).background = dot
    }

    fun bindAlarm(ctx: Context, v: View) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val info = am?.nextAlarmClock
        val title = v.findViewById<TextView>(R.id.a_title)
        val none = v.findViewById<View>(R.id.a_none)
        val time = v.findViewById<TextView>(R.id.a_time)
        val whenView = v.findViewById<TextView>(R.id.a_when)

        if (info == null) {
            title.text = "Morning alarm"
            none.visibility = View.VISIBLE
            time.visibility = View.GONE
            whenView.visibility = View.GONE
        } else {
            val t = Calendar.getInstance()
            t.timeInMillis = info.triggerTime
            val hour = t.get(Calendar.HOUR_OF_DAY)
            title.text = if (hour < 12) "Morning alarm" else if (hour < 18) "Afternoon alarm" else "Evening alarm"
            val today = Calendar.getInstance()
            val tomorrow = Calendar.getInstance()
            tomorrow.add(Calendar.DAY_OF_YEAR, 1)
            val sameToday = t.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                t.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
            val sameTomorrow = t.get(Calendar.YEAR) == tomorrow.get(Calendar.YEAR) &&
                t.get(Calendar.DAY_OF_YEAR) == tomorrow.get(Calendar.DAY_OF_YEAR)
            none.visibility = View.GONE
            time.visibility = View.VISIBLE
            whenView.visibility = View.VISIBLE
            time.text = SimpleDateFormat("h:mm a", Locale.US).format(Date(info.triggerTime))
            whenView.text = if (sameToday) "Today" else if (sameTomorrow) "Tomorrow"
            else SimpleDateFormat("EEE, MMM d", Locale.US).format(Date(info.triggerTime))
        }

        v.setOnClickListener {
            try {
                val pi = info?.showIntent
                if (pi != null) {
                    pi.send()
                } else {
                    ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            } catch (e: Exception) {
            }
        }
    }
}
