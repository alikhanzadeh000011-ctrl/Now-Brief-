package com.example.nowbrief

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sleep hypnogram: one rounded bar per stage on four rows (awake, REM, light, deep), joined by thin lines. */
class SleepChartView(ctx: Context) : View(ctx) {
    private var stages: List<SleepStage> = emptyList()
    private var t0 = 0L
    private var t1 = 1L
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    companion object {
        private val COLORS = intArrayOf(0xFFFF7A45.toInt(), 0xFF3FD0FF.toInt(), 0xFF4C7DFF.toInt(), 0xFF2F54EB.toInt())
        // row index from the top: awake, REM, light, deep
        private val ROW = intArrayOf(0, 1, 2, 3)
    }

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = ctx.dp(2).toFloat() * 0.7f
        line.strokeCap = Paint.Cap.ROUND
    }

    fun setData(list: List<SleepStage>, start: Long, end: Long) {
        stages = list
        t0 = start
        t1 = if (end > start) end else start + 1
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (stages.isEmpty()) return
        val padX = context.dp(14).toFloat()
        val padY = context.dp(14).toFloat()
        val w = width - 2 * padX
        val h = height - 2 * padY
        val rowH = h / 4f
        val barH = rowH * 0.62f
        val span = (t1 - t0).toFloat()
        var prevRight = -1f
        var prevY = 0f
        var prevType = 0
        for (s in stages) {
            val type = s.type.coerceIn(0, 3)
            val row = ROW[type]
            val cy = padY + (row + 0.5f) * rowH
            val x1 = padX + (s.start - t0) / span * w
            var x2 = padX + (s.end - t0) / span * w
            if (x2 - x1 < context.dp(3)) x2 = x1 + context.dp(3)
            if (prevRight >= 0f) {
                line.color = (COLORS[type] and 0x00FFFFFF) or (0xB0 shl 24)
                val x = Math.min(x1, prevRight)
                canvas.drawLine(x, prevY, x, cy, line)
            }
            fill.color = COLORS[type]
            rect.set(x1, cy - barH / 2f, x2, cy + barH / 2f)
            val r = Math.min(barH / 2f, (x2 - x1) / 2f)
            canvas.drawRoundRect(rect, r, r, fill)
            prevRight = x2
            prevY = cy
            prevType = type
        }
        if (prevType < 0) return
    }
}

/** The smiling blue flower-shaped blob of the energy card. */
class EnergyBlobView(ctx: Context) : View(ctx) {
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mouth = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val mouthRect = RectF()
    private var flat = false

    init {
        face.color = 0xFF1B3A8A.toInt()
        mouth.color = 0xFF1B3A8A.toInt()
        mouth.style = Paint.Style.STROKE
        mouth.strokeCap = Paint.Cap.ROUND
    }

    /** A low score gets a flat mouth instead of a smile. */
    fun setFlat(f: Boolean) {
        flat = f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val s = Math.min(w, h)
        val big = s * 0.30f
        val lobe = s * 0.20f
        val orbit = s * 0.27f
        body.shader = RadialGradient(
            cx, cy + s * 0.05f, s * 0.55f,
            intArrayOf(0xFF2F8BFF.toInt(), 0xFF4DA3FF.toInt(), 0xFF62B1FF.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, big, body)
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0 + 22.5)
            canvas.drawCircle(
                cx + (orbit * Math.cos(a)).toFloat(),
                cy + (orbit * Math.sin(a)).toFloat(),
                lobe, body
            )
        }
        val eyeY = cy - s * 0.04f
        val eyeR = s * 0.032f
        canvas.drawCircle(cx - s * 0.11f, eyeY, eyeR, face)
        canvas.drawCircle(cx + s * 0.07f, eyeY, eyeR, face)
        mouth.strokeWidth = s * 0.03f
        if (flat) {
            canvas.drawLine(cx - s * 0.04f, cy + s * 0.08f, cx + s * 0.04f, cy + s * 0.08f, mouth)
        } else {
            path.reset()
            mouthRect.set(cx - s * 0.07f, cy + s * 0.02f, cx + s * 0.05f, cy + s * 0.11f)
            path.addArc(mouthRect, 20f, 140f)
            canvas.drawPath(path, mouth)
        }
    }
}

object WellnessCards {
    private val WRAP = MoreCards.WRAP
    private val MATCH = MoreCards.MATCH

    private fun fmtTime(ms: Long): String = SimpleDateFormat("h:mm a", Locale.US).format(Date(ms))

    fun fmtDur(min: Int): String {
        val h = min / 60
        val m = min % 60
        return if (h > 0 && m > 0) h.toString() + "h " + m + "m" else if (h > 0) h.toString() + "h" else m.toString() + "m"
    }

    private fun deltaText(d: Int?): String? {
        if (d == null) return null
        return if (d < 0) "\u25BE " + (-d) else if (d > 0) "\u25B4 " + d else "\u2013 0"
    }

    /** Big number with the small change next to it, like the Samsung cards. */
    private fun scoreRow(ctx: Context, ink: Int, score: Int, delta: Int?): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.BOTTOM
        row.addView(MoreCards.text(ctx, score.toString(), 46f, ink, true))
        val dt = deltaText(delta)
        if (dt != null) {
            val d = MoreCards.text(ctx, dt, 17f, MoreCards.alpha(ink, 0xCC), false)
            d.setPadding(0, 0, 0, ctx.dp(8))
            row.addView(d, MoreCards.lp(ctx, WRAP, WRAP, 0, 10))
        }
        return row
    }

    private fun iconChip(ctx: Context, light: Boolean, icon: Int): View {
        val ink = MoreCards.inkOf(light)
        val v = ImageView(ctx)
        v.setImageResource(icon)
        v.setColorFilter(ink)
        v.setPadding(ctx.dp(7), ctx.dp(7), ctx.dp(7), ctx.dp(7))
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (light) 0x14000000 else 0x33FFFFFF)
        v.background = g
        return v
    }

    private fun timeGroup(ctx: Context, light: Boolean, icon: Int, label: String): View {
        val ink = MoreCards.inkOf(light)
        val g = LinearLayout(ctx)
        g.orientation = LinearLayout.HORIZONTAL
        g.gravity = Gravity.CENTER_VERTICAL
        g.addView(iconChip(ctx, light, icon), LinearLayout.LayoutParams(ctx.dp(30), ctx.dp(30)))
        val t = MoreCards.text(ctx, label, 12.5f, ink, false)
        t.maxLines = 2
        g.addView(t, MoreCards.lp(ctx, WRAP, WRAP, 0, 5))
        return g
    }

    // ------------------------------------------------------------------ sleep

    fun sleep(ctx: Context, light: Boolean, d: SleepData): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Sleep", 13f, MoreCards.alpha(ink, 0xA6), false))
        val sc = scoreRow(ctx, ink, d.score, d.delta)
        sc.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 8, 0)
        card.addView(sc)
        card.addView(MoreCards.text(ctx, "Sleep score", 15f, ink, false))

        val times = LinearLayout(ctx)
        times.orientation = LinearLayout.HORIZONTAL
        times.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 14, 0)
        val g1 = timeGroup(ctx, light, R.drawable.ic_moon, fmtTime(d.bedtime))
        val g2 = timeGroup(ctx, light, R.drawable.ic_alarm, fmtTime(d.wake))
        val g3 = timeGroup(ctx, light, R.drawable.ic_bed, fmtDur(d.durationMin))
        times.addView(g1, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(g2, LinearLayout.LayoutParams(0, WRAP, 1f))
        times.addView(g3, LinearLayout.LayoutParams(0, WRAP, 0.85f))
        card.addView(times)

        val chartBox = LinearLayout(ctx)
        chartBox.orientation = LinearLayout.VERTICAL
        chartBox.background = MoreCards.softBox(ctx, light, 22)
        chartBox.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 14, 0)
        val chart = SleepChartView(ctx)
        chart.setData(d.stages, d.bedtime, d.wake)
        chartBox.addView(chart, LinearLayout.LayoutParams(MATCH, ctx.dp(104)))
        val axis = LinearLayout(ctx)
        axis.orientation = LinearLayout.HORIZONTAL
        axis.setPadding(ctx.dp(14), 0, ctx.dp(14), ctx.dp(10))
        axis.addView(MoreCards.text(ctx, fmtTime(d.bedtime), 12.5f, MoreCards.alpha(ink, 0xB3), false), LinearLayout.LayoutParams(0, WRAP, 1f))
        val end = MoreCards.text(ctx, fmtTime(d.wake), 12.5f, MoreCards.alpha(ink, 0xB3), false)
        end.gravity = Gravity.END
        axis.addView(end, LinearLayout.LayoutParams(0, WRAP, 1f))
        chartBox.addView(axis)
        card.addView(chartBox)
        return card
    }

    /** Shown while Health Connect has not been given the sleep permissions yet. */
    fun sleepPrompt(ctx: Context, light: Boolean, onAllow: () -> Unit): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Sleep", 13f, MoreCards.alpha(ink, 0xA6), false))
        val t = MoreCards.text(
            ctx,
            "Allow Health Connect to read your sleep, heart rate and heart rate variability. Then your sleep and energy scores show up here.",
            14.5f, MoreCards.alpha(ink, 0xE6), false
        )
        t.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 10, 0)
        card.addView(t)
        card.addView(MoreCards.solidButton(ctx, "Allow Health Connect", onAllow))
        return card
    }

    // ------------------------------------------------------------------ energy

    private fun energyTexts(e: EnergyData): Pair<String, String> {
        val hr = e.hrDevPct
        val hrv = e.hrvDevPct
        if (hr != null && hr >= 5) {
            return "Focus on Recovery" to
                "Your sleeping heart rate was about " + hr + "% above your usual average, which can affect your rest. " +
                "With an energy score of " + e.score + ", consider focusing on recovery today with plenty of breaks " +
                "and good sleep habits. That should lift your energy score tomorrow."
        }
        if (hrv != null && hrv <= -10) {
            return "Take it easy" to
                "Your heart rate variability dipped below your usual level overnight. " +
                "With an energy score of " + e.score + ", pace yourself today and keep some room to rest."
        }
        if (e.score >= 85) {
            return "Ready to go" to
                "You slept well and your body looks well recovered. With an energy score of " + e.score +
                ", it's a good day to take on something that matters."
        }
        if (e.score >= 70) {
            return "Steady day" to
                "Your rest was decent. With an energy score of " + e.score +
                ", a balanced day with a few short breaks should feel comfortable."
        }
        return "Focus on Recovery" to
            "Last night's rest looks short or restless. With an energy score of " + e.score +
            ", take it gently today and aim for an earlier night."
    }

    fun energy(ctx: Context, light: Boolean, e: EnergyData): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Health and wellness", 13f, MoreCards.alpha(ink, 0xA6), false))

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 8, 0)
        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        left.addView(scoreRow(ctx, ink, e.score, e.delta))
        left.addView(MoreCards.text(ctx, "Energy score", 15f, ink, false))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val blob = EnergyBlobView(ctx)
        blob.setFlat(e.score < 60)
        top.addView(blob, LinearLayout.LayoutParams(ctx.dp(96), ctx.dp(88)))
        card.addView(top)

        val texts = energyTexts(e)
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 14, 0)
        head.addView(MoreCards.text(ctx, texts.first, 22f, ink, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val info = ImageView(ctx)
        info.setImageResource(R.drawable.ic_info)
        info.setColorFilter(ink)
        info.setPadding(ctx.dp(9), ctx.dp(9), ctx.dp(9), ctx.dp(9))
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(Color.TRANSPARENT)
        ring.setStroke(ctx.dp(1), MoreCards.alpha(ink, 0x66))
        info.background = ring
        info.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("About the energy score")
                .setMessage(
                    "This is an estimate made on your phone, not Samsung's official score. " +
                        "It combines last night's sleep score (" + e.sleepScore + ") with your sleeping heart rate " +
                        "and heart rate variability compared with your last week, when Health Connect has them."
                )
                .setPositiveButton("OK", null)
                .show()
        }
        head.addView(info, MoreCards.lp(ctx, ctx.dp(36), ctx.dp(36), 0, 10))
        card.addView(head)

        val body = MoreCards.text(ctx, texts.second, 14.5f, MoreCards.alpha(ink, 0xE6), false)
        body.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 10, 0)
        card.addView(body)
        return card
    }
}
