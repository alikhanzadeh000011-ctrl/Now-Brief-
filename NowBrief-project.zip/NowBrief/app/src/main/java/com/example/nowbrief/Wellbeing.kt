package com.example.nowbrief

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import java.util.Calendar
import java.util.concurrent.Executors

class AppUse(val pkg: String, val name: String, val ms: Long)

class WellbeingData(val totalMs: Long, val unlocks: Int, val top: List<AppUse>)

/** Today's screen time, unlocks and most used apps, from UsageStats (needs "Usage access"). */
object WellbeingRepo {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    fun hasAccess(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(AppOpsManager::class.java)
            val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    fun accessIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).setData(Uri.parse("package:" + ctx.packageName))

    fun load(ctx: Context, cb: (WellbeingData?) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            var data: WellbeingData? = null
            try {
                data = compute(app)
            } catch (e: Throwable) {
                data = null
            }
            val d = data
            ui.post { cb(d) }
        }
    }

    private fun homePackages(ctx: Context): Set<String> {
        val out = HashSet<String>()
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in ctx.packageManager.queryIntentActivities(i, 0)) out.add(r.activityInfo.packageName)
        } catch (e: Exception) {
        }
        return out
    }

    private fun compute(ctx: Context): WellbeingData {
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()

        val events = usm.queryEvents(start, end)
        val ev = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val totals = HashMap<String, Long>()
        var unlocks = 0

        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            when (ev.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> open[pkg] = ev.timeStamp
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val st = open.remove(pkg)
                    if (st != null && ev.timeStamp > st) totals[pkg] = (totals[pkg] ?: 0L) + (ev.timeStamp - st)
                }
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> {
                    for ((p, st) in open) {
                        if (ev.timeStamp > st) totals[p] = (totals[p] ?: 0L) + (ev.timeStamp - st)
                    }
                    open.clear()
                }
                UsageEvents.Event.KEYGUARD_HIDDEN -> unlocks++
            }
        }
        for ((p, st) in open) {
            if (end > st) totals[p] = (totals[p] ?: 0L) + (end - st)
        }

        val skip = HashSet<String>(homePackages(ctx))
        skip.add("com.android.systemui")
        skip.add("android")
        skip.add(ctx.packageName)

        val pm = ctx.packageManager
        val list = ArrayList<AppUse>()
        var total = 0L
        for ((p, ms) in totals) {
            if (skip.contains(p) || ms < 15_000L) continue
            val label = try {
                pm.getApplicationInfo(p, 0).loadLabel(pm).toString()
            } catch (e: PackageManager.NameNotFoundException) {
                continue
            }
            total += ms
            list.add(AppUse(p, label, ms))
        }
        list.sortByDescending { it.ms }
        return WellbeingData(total, unlocks, list.take(3))
    }
}

object WellbeingCards {
    private val WRAP = MoreCards.WRAP
    private val MATCH = MoreCards.MATCH

    private fun fmt(ms: Long): String = WellnessCards.fmtDur(Math.max(0L, ms / 60000L).toInt())

    fun prompt(ctx: Context, light: Boolean, onAllow: () -> Unit): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Digital Wellbeing", 13f, MoreCards.alpha(ink, 0xA6), false))
        val t = MoreCards.text(
            ctx,
            "Allow usage access to see your screen time and most used apps here.",
            14.5f, MoreCards.alpha(ink, 0xE6), false
        )
        t.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 10, 0)
        card.addView(t)
        card.addView(MoreCards.solidButton(ctx, "Allow usage access", onAllow))
        return card
    }

    fun card(ctx: Context, light: Boolean, d: WellbeingData): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Digital Wellbeing", 13f, MoreCards.alpha(ink, 0xA6), false))

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 8, 0)
        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        left.addView(MoreCards.text(ctx, fmt(d.totalMs), 38f, ink, true))
        left.addView(MoreCards.text(ctx, "Screen time today", 15f, ink, false))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val chip = LinearLayout(ctx)
        chip.orientation = LinearLayout.HORIZONTAL
        chip.gravity = Gravity.CENTER_VERTICAL
        chip.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        chip.background = MoreCards.softBox(ctx, light, 20)
        val ph = ImageView(ctx)
        ph.setImageResource(R.drawable.ic_phone)
        ph.setColorFilter(ink)
        chip.addView(ph, LinearLayout.LayoutParams(ctx.dp(18), ctx.dp(18)))
        chip.addView(MoreCards.text(ctx, d.unlocks.toString() + " unlocks", 13.5f, ink, true), MoreCards.lp(ctx, WRAP, WRAP, 0, 6))
        top.addView(chip)
        card.addView(top)

        val maxMs = if (d.top.isEmpty()) 1L else d.top[0].ms
        val pm = ctx.packageManager
        for (a in d.top) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 14, 0)

            val icon = ImageView(ctx)
            try {
                icon.setImageDrawable(pm.getApplicationIcon(a.pkg))
            } catch (e: Exception) {
            }
            row.addView(icon, LinearLayout.LayoutParams(ctx.dp(34), ctx.dp(34)))

            val mid = LinearLayout(ctx)
            mid.orientation = LinearLayout.VERTICAL
            val name = MoreCards.text(ctx, a.name, 14.5f, ink, false)
            name.maxLines = 1
            mid.addView(name)

            val frac = (a.ms.toFloat() / maxMs).coerceIn(0.04f, 1f)
            val bar = LinearLayout(ctx)
            bar.orientation = LinearLayout.HORIZONTAL
            val track = GradientDrawable()
            track.cornerRadius = ctx.dp(3).toFloat()
            track.setColor(MoreCards.alpha(ink, 0x1F))
            bar.background = track
            val fill = View(ctx)
            val fg = GradientDrawable()
            fg.cornerRadius = ctx.dp(3).toFloat()
            fg.setColor(0xFF4E7FF2.toInt())
            fill.background = fg
            bar.addView(fill, LinearLayout.LayoutParams(0, ctx.dp(5), frac))
            bar.addView(View(ctx), LinearLayout.LayoutParams(0, ctx.dp(5), 1f - frac))
            mid.addView(bar, MoreCards.lp(ctx, MATCH, ctx.dp(5), 6, 0))
            row.addView(mid, MoreCards.lp(ctx, 0, WRAP, 0, 12).also { it.weight = 1f })

            row.addView(MoreCards.text(ctx, fmt(a.ms), 13.5f, MoreCards.alpha(ink, 0xCC), false), MoreCards.lp(ctx, WRAP, WRAP, 0, 12))
            card.addView(row)
        }
        return card
    }
}
