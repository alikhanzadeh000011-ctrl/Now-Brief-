package com.example.nowbrief

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * A round glass button. It copies the small area of the page behind it, blurs it,
 * and lays a white tint on top. The tint at level 0 is #01FFFFFF, so you see pure blur.
 */
class GlassButton @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {

    /** The view tree drawn behind the button (page background and cards). */
    var source: View? = null

    private val pad = ctx.dp(14)
    private val backdrop = ImageView(ctx)
    private val tint = View(ctx)
    private val ring = View(ctx)
    private val icon = ImageView(ctx)
    private var bmp: Bitmap? = null
    private var darkInk = false

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        clipToOutline = true
        isClickable = true

        backdrop.scaleType = ImageView.ScaleType.FIT_XY
        try {
            val r = ctx.dp(8).toFloat()
            backdrop.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
        } catch (e: Throwable) {
            // without blur the button just shows the tint and ring
        }
        addView(backdrop, LayoutParams(1, 1))
        addView(tint, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(ring, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        icon.setPadding(ctx.dp(11), ctx.dp(11), ctx.dp(11), ctx.dp(11))
        addView(icon, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        setTintLevel(0)
        setRingColor(0x73FFFFFF)
        foreground = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, ShapeDrawable(OvalShape()))
    }

    fun setIcon(res: Int) {
        icon.setImageResource(res)
    }

    /** level 0..100: 0 is #01FFFFFF (pure blur), 100 is a frosted white. */
    fun setTintLevel(level: Int) {
        val a = 1 + level.coerceIn(0, 100) * 127 / 100
        tint.setBackgroundColor((a shl 24) or 0x00FFFFFF)
    }

    fun setRingColor(color: Int) {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0)
        g.setStroke(Math.max(1, (resources.displayMetrics.density * 1.2f).toInt()), color)
        ring.background = g
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val lp = LayoutParams(w + 2 * pad, h + 2 * pad)
        lp.leftMargin = -pad
        lp.topMargin = -pad
        backdrop.layoutParams = lp
        post { refresh() }
    }

    /** Copies the area behind the button into a small bitmap; the ImageView blurs it. */
    fun refresh() {
        val src = source ?: return
        if (width == 0 || height == 0) return
        val k = 3
        val bw = Math.max(1, (width + 2 * pad) / k)
        val bh = Math.max(1, (height + 2 * pad) / k)
        var b = bmp
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp = b
            backdrop.setImageBitmap(b)
        }
        b.eraseColor(0)
        try {
            val me = IntArray(2)
            val at = IntArray(2)
            getLocationInWindow(me)
            src.getLocationInWindow(at)
            val c = Canvas(b)
            c.scale(1f / k, 1f / k)
            c.translate((at[0] - me[0] + pad).toFloat(), (at[1] - me[1] + pad).toFloat())
            src.draw(c)
        } catch (e: Exception) {
        }
        backdrop.invalidate()
        updateInk(b)
    }

    /** Light content behind the button turns the ring and icon dark; dark content keeps them white. */
    private fun updateInk(b: Bitmap) {
        var sum = 0f
        var n = 0
        val x0 = b.width / 4
        val x1 = b.width * 3 / 4
        val y0 = b.height / 4
        val y1 = b.height * 3 / 4
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val p = b.getPixel(x, y)
                sum += (0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)) / 255f
                n++
                x += 2
            }
            y += 2
        }
        if (n == 0) return
        val lum = sum / n
        val want = if (lum > 0.62f) true else if (lum < 0.5f) false else darkInk
        if (want != darkInk) {
            darkInk = want
            if (darkInk) {
                setRingColor(0x99161616.toInt())
                icon.setColorFilter(0xFF161616.toInt())
            } else {
                setRingColor(0x73FFFFFF)
                icon.clearColorFilter()
            }
        }
    }
}
