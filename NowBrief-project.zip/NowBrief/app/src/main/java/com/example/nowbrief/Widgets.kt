package com.example.nowbrief

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews

enum class Kind { COMPACT, LARGE, WIDE }

object WidgetRenderer {

    fun tintRes(kind: Kind, dark: Boolean): Int =
        if (kind == Kind.COMPACT) {
            if (dark) R.drawable.tint_pill_dark else R.drawable.tint_pill_light
        } else {
            if (dark) R.drawable.tint_card_dark else R.drawable.tint_card_light
        }

    fun build(ctx: Context, id: Int, kind: Kind): RemoteViews {
        val phase = Phase.current()
        val look = Looks.compute(phase, Prefs.blur(ctx, id), Prefs.darkTint(ctx, id))
        val compact = kind == Kind.COMPACT

        val rv = RemoteViews(ctx.packageName, if (compact) R.layout.widget_compact else R.layout.widget_card)

        rv.setImageViewResource(R.id.bg, if (compact) phase.pillBg else phase.cardBg)
        rv.setFloat(R.id.bg, "setAlpha", look.gradAlpha)

        rv.setImageViewResource(R.id.tint, tintRes(kind, look.tintDark))
        rv.setFloat(R.id.tint, "setAlpha", look.tintAlpha)

        rv.setImageViewResource(R.id.badge, phase.badge)

        rv.setTextViewText(R.id.title, if (compact) phase.compactTitle else phase.widgetTitle)
        rv.setTextColor(R.id.title, look.titleColor)

        if (!compact) {
            rv.setTextViewText(R.id.subtitle, phase.widgetSubtitle)
            rv.setTextColor(R.id.subtitle, look.subColor)
            val wide = kind == Kind.WIDE
            rv.setTextViewTextSize(R.id.title, TypedValue.COMPLEX_UNIT_SP, if (wide) 24f else 20f)
            rv.setTextViewTextSize(R.id.subtitle, TypedValue.COMPLEX_UNIT_SP, if (wide) 15f else 13f)
        }

        val open = PendingIntent.getActivity(
            ctx, 100,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, open)
        return rv
    }
}

abstract class BaseWidgetProvider(private val kind: Kind) : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, WidgetRenderer.build(context, id, kind))
        }
        PhaseScheduler.scheduleNext(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        appWidgetManager.updateAppWidget(appWidgetId, WidgetRenderer.build(context, appWidgetId, kind))
    }

    override fun onEnabled(context: Context) {
        PhaseScheduler.scheduleNext(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Prefs.clearWidget(context, id)
    }
}

class CompactWidgetProvider : BaseWidgetProvider(Kind.COMPACT)
class LargeWidgetProvider : BaseWidgetProvider(Kind.LARGE)
class WideWidgetProvider : BaseWidgetProvider(Kind.WIDE)
