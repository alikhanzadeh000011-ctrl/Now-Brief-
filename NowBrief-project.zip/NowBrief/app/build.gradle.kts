plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nowbarlab.app"
    compileSdk = 35

    defaultConfig {
        // Same id as Now Brief (it is on One UI's Live notifications list).
        applicationId = "com.kakao.taxi"
        minSdk = 31
        targetSdk = 35
        versionCode = 100
        versionName = "lab-1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
}
