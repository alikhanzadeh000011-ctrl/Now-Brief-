package com.example.nowbrief

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.ScrollView

/** A ScrollView whose content fades out smoothly under the status bar. */
class FadeScrollView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : ScrollView(ctx, attrs) {

    private val paint = Paint()
    private var fadePx = 0f

    init {
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    fun setFade(px: Float) {
        if (px == fadePx) return
        fadePx = px
        paint.shader = LinearGradient(
            0f, 0f, 0f, px,
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0x00000000),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (fadePx <= 0f) {
            super.dispatchDraw(canvas)
            return
        }
        // dispatchDraw runs in scrolled (content) coordinates, so the layer and the fade must follow scrollY
        val top = scrollY.toFloat()
        val save = canvas.saveLayer(0f, top, width.toFloat(), top + height.toFloat(), null)
        super.dispatchDraw(canvas)
        canvas.save()
        canvas.translate(0f, top)
        canvas.drawRect(0f, 0f, width.toFloat(), fadePx, paint)
        canvas.restore()
        canvas.restoreToCount(save)
    }
}
