package com.example.nowbrief

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** Persian (Jalali / Shamsi) date and the Iranian official occasions. */
object Jalali {
    val MONTHS = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    /** Index = java.util.Calendar.DAY_OF_WEEK - 1 (Sunday first). */
    val WEEKDAYS = arrayOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    class Occasion(val name: String, val approx: Boolean)

    fun digits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(if (ch in '0'..'9') ('۰' + (ch - '0')) else ch)
        return sb.toString()
    }

    /** Gregorian to Jalali: [year, month, day]. */
    fun toJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + (if (days < 186) days % 31 else (days - 186) % 30)
        return intArrayOf(jy, jm, jd)
    }

    fun toJalali(d: LocalDate): IntArray = toJalali(d.year, d.monthValue, d.dayOfMonth)

    // fixed solar holidays: month * 100 + day
    private val SOLAR = mapOf(
        101 to "نوروز", 102 to "نوروز", 103 to "نوروز", 104 to "نوروز",
        112 to "روز جمهوری اسلامی", 113 to "سیزده‌به‌در",
        314 to "رحلت امام خمینی", 315 to "قیام ۱۵ خرداد",
        1122 to "پیروزی انقلاب اسلامی", 1229 to "ملی شدن صنعت نفت"
    )

    // religious occasions by Hijri month * 100 + day (moon sighting in Iran can differ by a day)
    private val LUNAR = mapOf(
        109 to "تاسوعای حسینی", 110 to "عاشورای حسینی", 220 to "اربعین حسینی",
        228 to "رحلت پیامبر و شهادت امام حسن", 317 to "میلاد پیامبر", 603 to "شهادت حضرت فاطمه",
        713 to "ولادت امام علی", 727 to "مبعث پیامبر", 815 to "نیمه شعبان",
        921 to "شهادت امام علی", 1001 to "عید فطر", 1002 to "تعطیلی عید فطر",
        1025 to "شهادت امام صادق", 1210 to "عید قربان", 1218 to "عید غدیر"
    )

    fun occasions(date: LocalDate): List<Occasion> {
        val out = ArrayList<Occasion>()
        val j = toJalali(date)
        val solar = SOLAR[j[1] * 100 + j[2]]
        if (solar != null) out.add(Occasion(solar, false))
        try {
            val h = HijrahDate.from(date)
            val key = h.get(ChronoField.MONTH_OF_YEAR) * 100 + h.get(ChronoField.DAY_OF_MONTH)
            val lunar = LUNAR[key]
            if (lunar != null) out.add(Occasion(lunar, true))
        } catch (e: Exception) {
        }
        return out
    }

    /** The next occasion after [from] within [maxDays] days: days away and the occasion. */
    fun next(from: LocalDate, maxDays: Int): Pair<Int, Occasion>? {
        for (i in 1..maxDays) {
            val list = occasions(from.plusDays(i.toLong()))
            if (list.isNotEmpty()) return Pair(i, list[0])
        }
        return null
    }
}
