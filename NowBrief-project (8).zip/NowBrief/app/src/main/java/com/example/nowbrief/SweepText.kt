package com.example.nowbrief

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.TextView

/**
 * The short sentences above the cards. When one scrolls into view a colored band
 * (teal, green, yellow...) sweeps once across the text and then fades back to normal.
 */
class SweepTextView(ctx: Context) : TextView(ctx) {
    /** 0, 1 or 2: which color set to use (set by the page, in order of the labels). */
    var palette = 0
    var played = false
        private set
    private var light = false
    private var anim: ValueAnimator? = null

    fun setInk(ink: Int) {
        light = Color.luminance(ink) < 0.5f
    }

    private fun colors(): IntArray {
        val dark = arrayOf(
            intArrayOf(0xFF5BE3D0.toInt(), 0xFF63E6A5.toInt(), 0xFF8BE87A.toInt()),
            intArrayOf(0xFF7EE787.toInt(), 0xFFB5E86A.toInt(), 0xFFE8E26A.toInt()),
            intArrayOf(0xFFFFE27A.toInt(), 0xFFFFC46B.toInt(), 0xFFFF9FA8.toInt())
        )
        val bright = arrayOf(
            intArrayOf(0xFF0A8F86.toInt(), 0xFF14A06A.toInt(), 0xFF4F9E1E.toInt()),
            intArrayOf(0xFF1E9E4A.toInt(), 0xFF6E9A10.toInt(), 0xFFA38C00.toInt()),
            intArrayOf(0xFFB88A00.toInt(), 0xFFD27A00.toInt(), 0xFFD2475B.toInt())
        )
        val set = if (light) bright else dark
        return set[((palette % 3) + 3) % 3]
    }

    fun play() {
        if (played) return
        played = true
        val cols = colors()
        val base = currentTextColor
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1900
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener {
            val p = it.animatedValue as Float
            val w = Math.max(1, width - paddingLeft - paddingRight).toFloat()
            val band = w * 0.6f
            val center = (-0.3f + 1.6f * p) * w
            paint.shader = LinearGradient(
                center - band / 2f, 0f, center + band / 2f, 0f,
                intArrayOf(base, cols[0], cols[1], cols[2], base),
                floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f),
                Shader.TileMode.CLAMP
            )
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                paint.shader = null
                invalidate()
            }
        })
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        paint.shader = null
        super.onDetachedFromWindow()
    }
}
