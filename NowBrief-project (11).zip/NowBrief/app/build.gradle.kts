plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.nowbrief"
    compileSdk = 35

    defaultConfig {
        // com.kakao.taxi is on One UI's Live notifications list, so keep this id.
        applicationId = "com.kakao.taxi"
        minSdk = 31
        targetSdk = 35
        versionCode = 22
        versionName = "2.5-final"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Lottie plays the original app's animated weather icons
    implementation("com.airbnb.android:lottie:6.4.0")
    // Lottie only ships AppCompat at runtime; the Kotlin compiler needs it on the compile classpath too
    implementation("androidx.appcompat:appcompat:1.7.0")
    // Health Connect (steps, active calories, workouts from Samsung Health)
    implementation("androidx.health.connect:connect-client:1.1.0-alpha10")
    implementation("androidx.activity:activity:1.9.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
