package com.example.nowbrief

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon

/**
 * Posts ONE ongoing notification that One UI shows in the Now bar.
 * Built the same way as the old working build: the Samsung extras are written
 * AFTER build(), with android.showSmallIcon = true and the semFlags bit 0x8000.
 * No foreground service on purpose; an alarm refreshes it at each phase change.
 */
object NowBarNotifier {
    private const val CHANNEL_ID = "now_brief_now_bar"
    private const val NOTIF_ID = 7001
    private const val SEM_FLAGS_VALUE = 0x8000

    private fun chipColor(phase: Phase): Int = when (phase) {
        Phase.MORNING -> 0xFF3FA9F5.toInt()
        Phase.MIDDAY -> 0xFF4FB3A6.toInt()
        Phase.AFTERNOON -> 0xFFB8A23E.toInt()
        Phase.EVENING -> 0xFF9B6FD6.toInt()
        Phase.LATE_NIGHT -> 0xFF4256B5.toInt()
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
    }

    fun post(ctx: Context) {
        if (!Prefs.nowBar(ctx)) {
            cancel(ctx)
            return
        }
        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return

        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Now Brief", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Keeps Now Brief on the Now bar"
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }

        val phase = Phase.current()
        // The same colored badge the widgets use, for the small icon and all three Now bar icons.
        val icon = Icon.createWithResource(ctx, phase.badge)

        val open = PendingIntent.getActivity(
            ctx, 7,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_FROM_NOW_BAR, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(phase.compactTitle)
            .setContentText("Get today's highlight")
            .setContentIntent(open)
            .setDeleteIntent(PhaseScheduler.tickIntent(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .build()

        // Samsung Now bar / Live notification keys (copied from the working build)
        val ex = notif.extras
        ex.putInt("android.ongoingActivityNoti.style", 1)
        ex.putString("android.ongoingActivityNoti.primaryInfo", phase.compactTitle)
        ex.putString("android.ongoingActivityNoti.secondaryInfo", "Get today's highlight")
        ex.putString("android.ongoingActivityNoti.nowbarPrimaryInfo", "Now Brief")
        ex.putString("android.ongoingActivityNoti.nowbarSecondaryInfo", "Get today's highlight")
        ex.putString("android.ongoingActivityNoti.chipExpandedText", phase.compactTitle)
        ex.putInt("android.ongoingActivityNoti.chipBgColor", chipColor(phase))
        ex.putParcelable("android.ongoingActivityNoti.chipIcon", icon)
        ex.putParcelable("android.ongoingActivityNoti.nowbarIcon", icon)
        ex.putParcelable("android.ongoingActivityNoti.firstIcon", icon)
        ex.putBoolean("android.showSmallIcon", true)
        ex.putBoolean("android.requestPromotedOngoing", true)
        ex.putString("android.shortCriticalText", "Brief")

        // Hidden Samsung flag bit that the working build also set (reflection; ignored if it fails)
        try {
            val f = Notification::class.java.getDeclaredField("semFlags")
            f.isAccessible = true
            f.setInt(notif, f.getInt(notif) or SEM_FLAGS_VALUE)
        } catch (e: Throwable) {
        }

        nm.notify(NOTIF_ID, notif)
    }
}
