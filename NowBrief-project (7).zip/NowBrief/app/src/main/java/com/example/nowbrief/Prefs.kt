package com.example.nowbrief

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("now_brief", Context.MODE_PRIVATE)

    // ---- per widget
    fun blur(c: Context, id: Int): Int = sp(c).getInt("blur_$id", 0)
    fun setBlur(c: Context, id: Int, v: Int) = sp(c).edit().putInt("blur_$id", v).apply()
    fun darkTint(c: Context, id: Int): Boolean = sp(c).getBoolean("dark_$id", true)
    fun setDarkTint(c: Context, id: Int, v: Boolean) = sp(c).edit().putBoolean("dark_$id", v).apply()
    fun clearWidget(c: Context, id: Int) = sp(c).edit().remove("blur_$id").remove("dark_$id").apply()

    // ---- app settings
    fun audioBrief(c: Context): Boolean = sp(c).getBoolean("audio_brief", true)
    fun setAudioBrief(c: Context, v: Boolean) = sp(c).edit().putBoolean("audio_brief", v).apply()
    fun expandWithoutUnlock(c: Context): Boolean = sp(c).getBoolean("expand_without_unlock", true)
    fun setExpandWithoutUnlock(c: Context, v: Boolean) = sp(c).edit().putBoolean("expand_without_unlock", v).apply()
    /** The Now bar is always on (there is no switch for it any more). */
    @Suppress("UNUSED_PARAMETER")
    fun nowBar(c: Context): Boolean = true

    // ---- "Content to include" categories
    // like the original, "Moments" starts switched off
    fun category(c: Context, key: String): Boolean = sp(c).getBoolean("cat_$key", key != "moments")
    fun setCategory(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean("cat_$key", v).apply()

    // ---- glass buttons on the page: always pure blur (#01FFFFFF tint)
    // fixed at 0 now (the slider was removed from the settings page)
    @Suppress("UNUSED_PARAMETER")
    fun glass(c: Context): Int = 0

    // ---- editable "plans shaping your day" (Edit schedule) and event card (Edit event)
    /** "calendar" or "saved" */
    fun schedMode(c: Context): String = sp(c).getString("sched_mode", "calendar") ?: "calendar"
    fun setSchedMode(c: Context, v: String) = sp(c).edit().putString("sched_mode", v).apply()
    /** minutes since midnight, -1 = not set */
    fun schedTime(c: Context, i: Int): Int = sp(c).getInt("sched_t$i", -1)
    fun schedPlan(c: Context, i: Int): String = sp(c).getString("sched_p$i", "") ?: ""
    fun setSched(c: Context, i: Int, minutes: Int, plan: String) =
        sp(c).edit().putInt("sched_t$i", minutes).putString("sched_p$i", plan).apply()

    fun eventArt(c: Context): String = sp(c).getString("event_art", "balloons") ?: "balloons"
    fun setEventArt(c: Context, v: String) = sp(c).edit().putString("event_art", v).apply()
    /** custom title, only for the event that starts at [begin] (empty = use the calendar title) */
    fun eventName(c: Context, begin: Long): String =
        if (sp(c).getLong("event_begin", -1L) == begin) (sp(c).getString("event_name", "") ?: "") else ""
    fun setEventName(c: Context, begin: Long, name: String) =
        sp(c).edit().putLong("event_begin", begin).putString("event_name", name).apply()
}
