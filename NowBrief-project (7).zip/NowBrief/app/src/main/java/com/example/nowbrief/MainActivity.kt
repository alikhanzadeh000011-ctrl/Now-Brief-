package com.example.nowbrief

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsetsController
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** The briefing page: phase background, sparkles, title, cards, small glass buttons. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_FROM_NOW_BAR = "from_now_bar"
    }

    private var stars: AnimatedImageDrawable? = null
    private var weatherView: View? = null
    private var alarmView: View? = null
    private var healthHolder: LinearLayout? = null
    private var sleepHolder: LinearLayout? = null
    private var energyHolder: LinearLayout? = null
    private var wellbeingHolder: LinearLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private var glassPending = false
    private var glassRunning = false
    private val glassIds = intArrayOf(R.id.btn_audio, R.id.btn_info, R.id.btn_settings)
    private val glassTicker = object : Runnable {
        override fun run() {
            if (!glassRunning) return
            refreshGlass()
            handler.postDelayed(this, 600)
        }
    }

    private fun refreshGlass() {
        for (id in glassIds) findViewById<GlassButton>(id).refresh()
    }
    private var page: PageTheme = PageTheme.MORNING
    private var ink: Int = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        if (intent?.getBooleanExtra(EXTRA_FROM_NOW_BAR, false) == true && Prefs.expandWithoutUnlock(this)) {
            setShowWhenLocked(true)
        }
        setContentView(R.layout.activity_main)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        page = PageTheme.at(hour)
        val titles = PageTheme.title(hour)
        ink = if (page.light) 0xFF161616.toInt() else Color.WHITE

        findViewById<ImageView>(R.id.page_bg).setImageResource(page.bg)
        val scroll = findViewById<FadeScrollView>(R.id.scroll)
        scroll.applySystemBarPadding()
        scroll.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            (v as FadeScrollView).setFade(v.paddingTop + dp(36).toFloat())
        }
        findViewById<View>(R.id.overlay_root).applySystemBarPadding()
        scroll.setOnScrollChangeListener { _, _, _, _, _ ->
            if (!glassPending) {
                glassPending = true
                handler.postDelayed({
                    glassPending = false
                    refreshGlass()
                }, 40)
            }
        }

        val title = findViewById<TextView>(R.id.main_title)
        title.text = titles.first
        title.setTextColor(ink)
        val sub = findViewById<TextView>(R.id.main_sub)
        sub.text = titles.second
        sub.setTextColor((ink and 0x00FFFFFF) or (0xE6 shl 24))

        val icons = intArrayOf(R.drawable.ic_audio, R.drawable.ic_info, R.drawable.ic_settings)
        for ((i, id) in glassIds.withIndex()) {
            val gb = findViewById<GlassButton>(id)
            gb.source = findViewById(R.id.backdrop_root)
            gb.setIcon(icons[i])
        }

        val bars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (page.light) bars else 0, bars)

        loadStars()

        findViewById<View>(R.id.btn_audio).setOnClickListener {
            Toast.makeText(this, "Audio brief comes in a later part", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btn_info).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Now Brief")
                .setMessage("This briefing is built on your phone from the weather, your alarms, your calendar and more cards in the next packages.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val need = ArrayList<String>()
        for (p in arrayOf(
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_CALENDAR
        )) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 11)
    }

    private fun buildCards() {
        val cards = findViewById<LinearLayout>(R.id.cards)
        cards.removeAllViews()
        val light = page.light
        val cal = Prefs.category(this, "events") && CalendarRepo.hasPermission(this)

        cards.addView(Cards.label(this, "Here's your weather update.", ink))
        val w = layoutInflater.inflate(R.layout.card_weather, cards, false)
        Cards.styleWeather(this, w, page)
        Cards.bindWeather(this, w, null, true)
        cards.addView(w)
        weatherView = w

        if (cal) {
            val special = CalendarRepo.upcomingSpecial(this)
            if (special != null) {
                val custom = Prefs.eventName(this, special.begin)
                val title = if (custom.isEmpty()) special.title else custom
                val art = Arts.of(Prefs.eventArt(this))
                cards.addView(Cards.label(this, "Here's an event worth keeping in mind.", ink))
                cards.addView(
                    MoreCards.event(
                        this, light, title, special, art,
                        { sendGreeting(art) },
                        { shareEvent(title, special) },
                        { Editors.editEvent(this, special, title) { rebuild() } }
                    )
                )
            }
        }

        alarmView = null
        if (Prefs.category(this, "events")) {
            cards.addView(Cards.label(this, "Here's your next alarm.", ink))
            val a = layoutInflater.inflate(R.layout.card_alarm, cards, false)
            Cards.styleAlarm(this, a, page)
            cards.addView(a)
            alarmView = a
        }

        sleepHolder = null
        energyHolder = null
        if (Prefs.category(this, "health")) {
            val sh = LinearLayout(this)
            sh.orientation = LinearLayout.VERTICAL
            cards.addView(sh)
            sleepHolder = sh
            val eh = LinearLayout(this)
            eh.orientation = LinearLayout.VERTICAL
            cards.addView(eh)
            energyHolder = eh
        }

        healthHolder = null
        if (Prefs.category(this, "health")) {
            cards.addView(Cards.label(this, "Here's how you're tracking today.", ink))
            val h = LinearLayout(this)
            h.orientation = LinearLayout.VERTICAL
            cards.addView(h)
            healthHolder = h
        }

        if (Prefs.category(this, "events")) {
            val plans: List<CalEvent> = if (Prefs.schedMode(this) == "saved") {
                CalendarRepo.savedPlans(this)
            } else if (cal) {
                CalendarRepo.todayPlans(this)
            } else {
                emptyList()
            }
            cards.addView(Cards.label(this, "Here are the plans shaping your day.", ink))
            cards.addView(MoreCards.plans(this, light, plans) { Editors.editSchedule(this) { rebuild() } })
        }

        wellbeingHolder = null
        if (Prefs.category(this, "wellbeing")) {
            val wh = LinearLayout(this)
            wh.orientation = LinearLayout.VERTICAL
            cards.addView(wh)
            wellbeingHolder = wh
        }

        if (Prefs.category(this, "travel")) {
            cards.addView(Cards.label(this, "Here's something ready when you're driving.", ink))
            cards.addView(MoreCards.driving(this, light) { tryDriving() })
        }

        if (page == PageTheme.NIGHT) {
            cards.addView(Cards.label(this, "Stay up to date with Now brief.", ink))
            cards.addView(MoreCards.stayUp(this, light))
        }
    }

    private fun loadHealth() {
        val h = healthHolder ?: return
        HealthRepo.load(this) { state, data ->
            if (!isDestroyed) {
                h.removeAllViews()
                h.addView(MoreCards.health(this, page.light, state, data) { requestHealth() })
            }
        }
    }

    private fun fill(holder: LinearLayout, label: String, card: View) {
        holder.removeAllViews()
        holder.addView(Cards.label(this, label, ink))
        holder.addView(card)
    }

    private fun loadWellness() {
        val sh = sleepHolder
        val eh = energyHolder
        if (sh == null || eh == null) return
        WellnessRepo.load(this) { state, data ->
            if (!isDestroyed) {
                sh.removeAllViews()
                eh.removeAllViews()
                if (state == HealthRepo.STATE_NEED_PERMISSION) {
                    fill(sh, "Here's a summary of how you slept.", WellnessCards.sleepPrompt(this, page.light) { requestHealth() })
                } else if (state == HealthRepo.STATE_OK && data != null) {
                    val sl = data.sleep
                    val en = data.energy
                    if (sl != null) {
                        fill(sh, "Here's a summary of how you slept.", WellnessCards.sleep(this, page.light, sl))
                    } else if (data.note != null) {
                        fill(sh, "Here's a summary of how you slept.", WellnessCards.note(this, page.light, data.note))
                    }
                    if (en != null) fill(eh, "Here's your energy score for today.", WellnessCards.energy(this, page.light, en))
                }
            }
        }
    }

    private fun loadWellbeing() {
        val wh = wellbeingHolder ?: return
        val label = "Here's how much you've used your phone."
        if (!WellbeingRepo.hasAccess(this)) {
            fill(wh, label, WellbeingCards.prompt(this, page.light) {
                try {
                    startActivity(WellbeingRepo.accessIntent(this))
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    } catch (e2: Exception) {
                    }
                }
            })
            return
        }
        WellbeingRepo.load(this) { d ->
            if (!isDestroyed) {
                wh.removeAllViews()
                if (d != null) fill(wh, label, WellbeingCards.card(this, page.light, d))
            }
        }
    }

    private fun requestHealth() {
        try {
            startActivityForResult(HealthRepo.requestIntent(this), 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Health Connect isn't available", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            loadHealth()
            loadWellness()
        }
    }

    private fun openCalendar() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis())))
        } catch (e: Exception) {
            Toast.makeText(this, "No calendar app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendGreeting(art: Art) {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, "Happy birthday! " + art.emoji + art.emoji + art.emoji)
        startActivity(Intent.createChooser(send, null))
    }

    private fun shareEvent(title: String, e: CalEvent) {
        val day = java.text.SimpleDateFormat("EEEE, MMM d", java.util.Locale.US).format(java.util.Date(e.begin))
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, title + " - " + day)
        startActivity(Intent.createChooser(send, null))
    }

    /** Rebuilds the cards after an editor saved something. */
    private fun rebuild() {
        buildCards()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(false)
        loadHealth()
        loadWellness()
        loadWellbeing()
    }

    private fun tryDriving() {
        try {
            val i = packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            startActivity(i)
        } catch (e: Exception) {
        }
        try {
            val am = getSystemService(AudioManager::class.java)
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
        } catch (e: Exception) {
        }
    }

    private fun loadWeather(force: Boolean) {
        WeatherRepo.refresh(this, force) { d ->
            val w = weatherView
            if (!isDestroyed && w != null) Cards.bindWeather(this, w, d, false)
        }
    }

    private fun loadStars() {
        try {
            val src = ImageDecoder.createSource(resources, R.raw.brief_stars)
            val d = ImageDecoder.decodeDrawable(src)
            findViewById<ImageView>(R.id.sparkles).setImageDrawable(d)
            if (d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                stars = d
            }
        } catch (e: Exception) {
            // keeps the static sparkles vector from the layout
        }
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(this)
        stars?.start()
        for (id in glassIds) findViewById<GlassButton>(id).setTintLevel(Prefs.glass(this))
        findViewById<View>(R.id.btn_audio).visibility = if (Prefs.audioBrief(this)) View.VISIBLE else View.GONE
        glassRunning = true
        handler.post(glassTicker)
        buildCards()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(false)
        loadHealth()
        loadWellness()
        loadWellbeing()
    }

    override fun onPause() {
        stars?.stop()
        glassRunning = false
        handler.removeCallbacks(glassTicker)
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Refresher.refreshAll(this)
        buildCards()
        val a = alarmView
        if (a != null) Cards.bindAlarm(this, a)
        loadWeather(true)
    }
}
