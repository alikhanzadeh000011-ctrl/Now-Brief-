package com.example.nowbrief

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Three nested hearts: steps (green), active time (blue), calories (pink). Progress runs clockwise from the top notch. */
class HeartRingsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private val colors = intArrayOf(0xFF5BD07B.toInt(), 0xFF4C9BF5.toInt(), 0xFFF06EB0.toInt())
    private val scales = floatArrayOf(1f, 0.68f, 0.38f)
    private val shown = floatArrayOf(0f, 0f, 0f)
    private val base = Path()
    private val paths = arrayOf(Path(), Path(), Path())
    private val seg = Path()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private var anim: ValueAnimator? = null

    init {
        track.style = Paint.Style.STROKE
        track.strokeCap = Paint.Cap.ROUND
        bar.style = Paint.Style.STROKE
        bar.strokeCap = Paint.Cap.ROUND
        val n = 240
        for (i in 0..n) {
            val t = Math.PI * 2.0 * i / n
            val x = 16.0 * Math.pow(Math.sin(t), 3.0)
            val y = -(13.0 * Math.cos(t) - 5.0 * Math.cos(2.0 * t) - 2.0 * Math.cos(3.0 * t) - Math.cos(4.0 * t))
            if (i == 0) base.moveTo(x.toFloat(), y.toFloat()) else base.lineTo(x.toFloat(), y.toFloat())
        }
        base.close()
    }

    private fun strokeW(): Float = resources.displayMetrics.density * 11f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val sw = strokeW()
        track.strokeWidth = sw
        bar.strokeWidth = sw
        val b = RectF()
        base.computeBounds(b, true)
        val s = Math.min((w - sw) / b.width(), (h - sw) / b.height())
        for (k in 0..2) {
            val m = Matrix()
            m.postTranslate(-b.centerX(), -b.centerY())
            m.postScale(s * scales[k], s * scales[k])
            m.postTranslate(w / 2f, h / 2f)
            base.transform(m, paths[k])
        }
    }

    fun setProgress(a: Float, b: Float, c: Float) {
        val to = floatArrayOf(a.coerceIn(0f, 1f), b.coerceIn(0f, 1f), c.coerceIn(0f, 1f))
        val from = shown.copyOf()
        anim?.cancel()
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 900
        va.addUpdateListener { v ->
            val f = v.animatedFraction
            for (k in 0..2) shown[k] = from[k] + (to[k] - from[k]) * f
            invalidate()
        }
        anim = va
        va.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        for (k in 0..2) {
            track.color = (colors[k] and 0x00FFFFFF) or (0x40 shl 24)
            canvas.drawPath(paths[k], track)
            if (shown[k] > 0.004f) {
                val pm = PathMeasure(paths[k], false)
                seg.reset()
                pm.getSegment(0f, pm.length * shown[k], seg, true)
                bar.color = colors[k]
                canvas.drawPath(seg, bar)
            }
        }
    }
}
