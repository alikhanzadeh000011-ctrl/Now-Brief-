package com.example.nowbrief

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

/** Shown by Health Connect when it asks why the app wants the data. */
class HealthRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        val t = TextView(this)
        t.text = "Now Brief reads your steps, workouts and active calories from Health Connect only to show your daily progress on this phone. Nothing is uploaded or shared."
        t.textSize = 18f
        t.setPadding(dp(24), dp(24), dp(24), dp(24))
        t.applySystemBarPadding()
        setContentView(t)
    }
}
