package com.example.nowbrief

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.runBlocking
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.Executors

class HealthData(val steps: Long, val activeMin: Int, val kcal: Int, val syncedAt: Long)

/**
 * Today's steps, active time and active calories from Health Connect (Samsung Health syncs into it).
 * Active time is an estimate: workout minutes, or minutes walked at 60+ steps per minute.
 */
object HealthRepo {
    const val STATE_UNAVAILABLE = 0
    const val STATE_NEED_PERMISSION = 1
    const val STATE_OK = 2

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private val READ_STEPS = HealthPermission.getReadPermission(StepsRecord::class)
    private val READ_CAL = HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
    private val READ_EXERCISE = HealthPermission.getReadPermission(ExerciseSessionRecord::class)

    val PERMS: Set<String> = setOf(READ_STEPS, READ_CAL, READ_EXERCISE)

    fun requestIntent(ctx: Context): Intent =
        PermissionController.createRequestPermissionResultContract().createIntent(ctx, PERMS)

    fun load(ctx: Context, cb: (Int, HealthData?) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            var state = STATE_UNAVAILABLE
            var data: HealthData? = null
            try {
                if (HealthConnectClient.getSdkStatus(app) == HealthConnectClient.SDK_AVAILABLE) {
                    val client = HealthConnectClient.getOrCreate(app)
                    val granted = runBlocking { client.permissionController.getGrantedPermissions() }
                    if (granted.contains(READ_STEPS)) {
                        data = readToday(client, granted)
                        state = STATE_OK
                    } else {
                        state = STATE_NEED_PERMISSION
                    }
                }
            } catch (e: Throwable) {
                state = STATE_UNAVAILABLE
                data = null
            }
            val s = state
            val d = data
            ui.post { cb(s, d) }
        }
    }

    private fun readToday(client: HealthConnectClient, granted: Set<String>): HealthData {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
        val now = Instant.now()
        val range = TimeRangeFilter.between(start, now)

        var steps = 0L
        var kcal = 0.0
        var exerciseMin = 0L
        var walkSecs = 0L

        runBlocking {
            val a = client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), range))
            steps = a[StepsRecord.COUNT_TOTAL] ?: 0L

            val recs = client.readRecords(ReadRecordsRequest(StepsRecord::class, range)).records
            for (r in recs) {
                val secs = Duration.between(r.startTime, r.endTime).seconds
                if (secs > 0 && r.count * 60.0 / secs >= 60.0) walkSecs += secs
            }

            if (granted.contains(READ_CAL)) {
                val c = client.aggregate(AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), range))
                kcal = c[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
            }
            if (granted.contains(READ_EXERCISE)) {
                val e = client.aggregate(AggregateRequest(setOf(ExerciseSessionRecord.EXERCISE_DURATION_TOTAL), range))
                exerciseMin = e[ExerciseSessionRecord.EXERCISE_DURATION_TOTAL]?.toMinutes() ?: 0L
            }
        }
        val minutes = Math.max(exerciseMin, walkSecs / 60L).toInt()
        return HealthData(steps, minutes, Math.round(kcal).toInt(), System.currentTimeMillis())
    }
}
