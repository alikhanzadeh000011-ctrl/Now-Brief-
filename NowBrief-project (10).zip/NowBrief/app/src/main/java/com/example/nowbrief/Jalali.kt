package com.example.nowbrief

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** Persian (Jalali / Shamsi) date and the Iranian official occasions. */
object Jalali {
    val MONTHS = arrayOf(
        "Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar",
        "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand"
    )

    class Occasion(val name: String, val approx: Boolean)

    /** Gregorian to Jalali: [year, month, day]. */
    fun toJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + (if (days < 186) days % 31 else (days - 186) % 30)
        return intArrayOf(jy, jm, jd)
    }

    fun toJalali(d: LocalDate): IntArray = toJalali(d.year, d.monthValue, d.dayOfMonth)

    // fixed solar holidays: month * 100 + day
    private val SOLAR = mapOf(
        101 to "Nowruz", 102 to "Nowruz", 103 to "Nowruz", 104 to "Nowruz",
        112 to "Islamic Republic Day", 113 to "Sizdah Bedar",
        314 to "Death of Imam Khomeini", 315 to "15 Khordad Uprising",
        1122 to "Islamic Revolution Victory Day", 1229 to "Oil Nationalization Day"
    )

    // religious occasions by Hijri month * 100 + day (moon sighting in Iran can differ by a day)
    private val LUNAR = mapOf(
        109 to "Tasua", 110 to "Ashura", 220 to "Arbaeen",
        228 to "Demise of the Prophet and Martyrdom of Imam Hassan", 317 to "Prophet's Birthday",
        603 to "Martyrdom of Fatima", 713 to "Birth of Imam Ali", 727 to "Mab'ath",
        815 to "Mid-Sha'ban", 921 to "Martyrdom of Imam Ali", 1001 to "Eid al-Fitr",
        1002 to "Eid al-Fitr holiday", 1025 to "Martyrdom of Imam Sadiq",
        1210 to "Eid al-Adha", 1218 to "Eid al-Ghadir"
    )

    fun occasions(date: LocalDate): List<Occasion> {
        val out = ArrayList<Occasion>()
        val j = toJalali(date)
        val solar = SOLAR[j[1] * 100 + j[2]]
        if (solar != null) out.add(Occasion(solar, false))
        try {
            val h = HijrahDate.from(date)
            val key = h.get(ChronoField.MONTH_OF_YEAR) * 100 + h.get(ChronoField.DAY_OF_MONTH)
            val lunar = LUNAR[key]
            if (lunar != null) out.add(Occasion(lunar, true))
        } catch (e: Exception) {
        }
        return out
    }

    /** The next occasion after [from] within [maxDays] days: days away and the occasion. */
    fun next(from: LocalDate, maxDays: Int): Pair<Int, Occasion>? {
        for (i in 1..maxDays) {
            val list = occasions(from.plusDays(i.toLong()))
            if (list.isNotEmpty()) return Pair(i, list[0])
        }
        return null
    }
}
