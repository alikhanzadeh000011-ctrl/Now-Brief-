package com.example.nowbrief

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.util.Calendar
import java.util.Locale

class CalEvent(val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int)

/** Reads today's events from the phone calendar (READ_CALENDAR). */
object CalendarRepo {

    private val SPECIAL = listOf("birthday", "bday", "anniversary", "\u062a\u0648\u0644\u062f", "\u0633\u0627\u0644\u06af\u0631\u062f")

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun query(ctx: Context, from: Long, to: Long): List<CalEvent> {
        val out = ArrayList<CalEvent>()
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, from)
            ContentUris.appendId(b, to)
            val proj = arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY,
                CalendarContract.Instances.EVENT_COLOR,
                CalendarContract.Instances.CALENDAR_COLOR
            )
            val c = ctx.contentResolver.query(b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC")
            if (c != null) {
                c.use {
                    while (it.moveToNext()) {
                        val title = it.getString(0)?.trim() ?: ""
                        if (title.isEmpty()) continue
                        val own = it.getInt(4)
                        val color = if (own != 0) own else it.getInt(5)
                        out.add(CalEvent(title, it.getLong(1), it.getLong(2), it.getInt(3) == 1, color))
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    /** Events from now until midnight, all-day ones first, at most four. */
    fun todayPlans(ctx: Context): List<CalEvent> {
        val now = System.currentTimeMillis()
        val end = Calendar.getInstance()
        end.add(Calendar.DAY_OF_YEAR, 1)
        end.set(Calendar.HOUR_OF_DAY, 0)
        end.set(Calendar.MINUTE, 0)
        end.set(Calendar.SECOND, 0)
        end.set(Calendar.MILLISECOND, 0)
        val all = query(ctx, now, end.timeInMillis - 1)
        return all.sortedWith(compareBy<CalEvent>({ !it.allDay }, { it.begin })).take(4)
    }

    /** A birthday or anniversary coming up in the next 36 hours, if there is one. */
    fun upcomingSpecial(ctx: Context): CalEvent? {
        val now = System.currentTimeMillis()
        val all = query(ctx, now, now + 36L * 3600L * 1000L)
        return all.firstOrNull { e ->
            val t = e.title.lowercase(Locale.ROOT)
            SPECIAL.any { k -> t.contains(k) }
        }
    }

    private val PALETTE = intArrayOf(
        0xFF4CD964.toInt(), 0xFF5AA9FF.toInt(), 0xFFFFA64D.toInt(), 0xFF8E7CFF.toInt(), 0xFFFF6B8B.toInt()
    )

    /** The hand-written schedule from "Edit schedule" (Saved schedule mode). */
    fun savedPlans(ctx: Context): List<CalEvent> {
        val day = Calendar.getInstance()
        day.set(Calendar.HOUR_OF_DAY, 0)
        day.set(Calendar.MINUTE, 0)
        day.set(Calendar.SECOND, 0)
        day.set(Calendar.MILLISECOND, 0)
        val base = day.timeInMillis
        val out = ArrayList<CalEvent>()
        for (i in 0 until 5) {
            val plan = Prefs.schedPlan(ctx, i)
            if (plan.isEmpty()) continue
            val t = Prefs.schedTime(ctx, i)
            val begin = if (t >= 0) base + t * 60000L else base
            out.add(CalEvent(plan, begin, begin, t < 0, PALETTE[out.size % PALETTE.size]))
        }
        return out.sortedWith(compareBy<CalEvent>({ !it.allDay }, { it.begin }))
    }

    fun isToday(millis: Long): Boolean {
        val a = Calendar.getInstance()
        val b = Calendar.getInstance()
        b.timeInMillis = millis
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    }

    /** A guessed emoji for the event title. */
    fun emoji(title: String): String {
        val t = title.lowercase(Locale.ROOT)
        fun has(vararg keys: String): Boolean = keys.any { k -> t.contains(k) }
        return when {
            has("lunch", "\u0646\u0627\u0647\u0627\u0631") -> "\uD83C\uDF54"
            has("dinner", "\u0634\u0627\u0645") -> "\uD83C\uDF7D\uFE0F"
            has("breakfast") -> "\uD83E\uDD5E"
            has("coffee") -> "\u2615"
            has("birthday", "bday", "\u062a\u0648\u0644\u062f") -> "\uD83C\uDF82"
            has("yoga", "meditat") -> "\uD83E\uDDD8"
            has("workout", "gym", "run", "exercise", "\u0648\u0631\u0632\u0634") -> "\uD83D\uDCAA"
            has("book", "read", "class", "study", "exam", "\u06a9\u0644\u0627\u0633") -> "\uD83D\uDCD6"
            has("doctor", "dentist", "clinic", "\u062f\u06a9\u062a\u0631") -> "\uD83E\uDE7A"
            has("flight", "trip", "travel", "\u0633\u0641\u0631") -> "\u2708\uFE0F"
            has("meeting", "call", "zoom", "\u062c\u0644\u0633\u0647") -> "\uD83D\uDCBC"
            else -> "\uD83D\uDCC5"
        }
    }
}
