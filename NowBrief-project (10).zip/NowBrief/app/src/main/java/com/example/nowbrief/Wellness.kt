package com.example.nowbrief

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.runBlocking
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.util.concurrent.Executors

/** One stretch of a night: type 0 awake, 1 REM, 2 light, 3 deep. */
class SleepStage(val start: Long, val end: Long, val type: Int)

class SleepData(
    val bedtime: Long,
    val wake: Long,
    val durationMin: Int,
    val score: Int,
    val delta: Int?,
    val stages: List<SleepStage>
)

class EnergyData(
    val score: Int,
    val delta: Int?,
    val sleepScore: Int,
    val hrDevPct: Int?,
    val hrvDevPct: Int?
)

class WellnessData(val sleep: SleepData?, val energy: EnergyData?, val note: String? = null)

/**
 * Sleep and energy score, estimated on the phone from Health Connect (Samsung Health writes into it).
 * Samsung's own scores are not readable by other apps, so these are estimates.
 */
object WellnessRepo {
    val READ_SLEEP = HealthPermission.getReadPermission(SleepSessionRecord::class)
    val READ_HR = HealthPermission.getReadPermission(HeartRateRecord::class)
    val READ_HRV = HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class)

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    fun load(ctx: Context, cb: (Int, WellnessData?) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            var state = HealthRepo.STATE_UNAVAILABLE
            var data: WellnessData? = null
            try {
                if (HealthConnectClient.getSdkStatus(app) == HealthConnectClient.SDK_AVAILABLE) {
                    val client = HealthConnectClient.getOrCreate(app)
                    val granted = runBlocking { client.permissionController.getGrantedPermissions() }
                    if (granted.contains(READ_SLEEP)) {
                        data = compute(app, client, granted)
                        state = HealthRepo.STATE_OK
                    } else {
                        state = HealthRepo.STATE_NEED_PERMISSION
                    }
                }
            } catch (e: Throwable) {
                state = HealthRepo.STATE_OK
                data = WellnessData(null, null, "Couldn't read sleep: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            }
            val s = state
            val d = data
            ui.post { cb(s, d) }
        }
    }

    // ------------------------------------------------------------------ maths

    private fun typeOf(stage: Int): Int = when (stage) {
        1, 3, 7 -> 0      // awake, out of bed, awake in bed
        6 -> 1            // REM
        5 -> 3            // deep
        else -> 2         // light, sleeping, unknown
    }

    private fun stagesOf(s: SleepSessionRecord): List<SleepStage> {
        val out = ArrayList<SleepStage>()
        for (st in s.stages) {
            out.add(SleepStage(st.startTime.toEpochMilli(), st.endTime.toEpochMilli(), typeOf(st.stage)))
        }
        out.sortBy { it.start }
        return out
    }

    /** 0..99 estimate: time asleep (40), deep and REM share (40), few wake-ups (20). */
    fun scoreOf(durationMin: Int, stages: List<SleepStage>): Int {
        var awakeMs = 0L
        var remMs = 0L
        var deepMs = 0L
        var asleepMs = 0L
        for (s in stages) {
            val len = s.end - s.start
            if (len <= 0) continue
            when (s.type) {
                0 -> awakeMs += len
                1 -> { remMs += len; asleepMs += len }
                3 -> { deepMs += len; asleepMs += len }
                else -> asleepMs += len
            }
        }
        val hasStages = remMs + deepMs > 0L
        val asleepMin = if (stages.isEmpty() || asleepMs <= 0L) durationMin.toDouble() else asleepMs / 60000.0
        val durPts = 40.0 * Math.min(asleepMin / 480.0, 1.0)
        var stagePts = 28.0
        var contPts = 14.0
        if (hasStages && asleepMs > 0L) {
            val deepFrac = deepMs.toDouble() / asleepMs
            val remFrac = remMs.toDouble() / asleepMs
            stagePts = 20.0 * Math.min(deepFrac / 0.15, 1.0) + 20.0 * Math.min(remFrac / 0.20, 1.0)
            val awakeFrac = awakeMs.toDouble() / Math.max(1.0, durationMin * 60000.0)
            contPts = 20.0 * (1.0 - Math.min(awakeFrac / 0.12, 1.0))
        }
        return Math.round(durPts + stagePts + contPts).toInt().coerceIn(0, 99)
    }

    private fun avgHr(client: HealthConnectClient, s: SleepSessionRecord): Double? = try {
        runBlocking {
            val recs = client.readRecords(
                ReadRecordsRequest(HeartRateRecord::class, TimeRangeFilter.between(s.startTime, s.endTime))
            ).records
            var sum = 0L
            var n = 0
            for (r in recs) for (smp in r.samples) {
                if (smp.time >= s.startTime && smp.time <= s.endTime) {
                    sum += smp.beatsPerMinute
                    n++
                }
            }
            if (n >= 5) sum.toDouble() / n else null
        }
    } catch (e: Throwable) {
        null
    }

    private fun avgHrv(client: HealthConnectClient, s: SleepSessionRecord): Double? = try {
        runBlocking {
            val recs = client.readRecords(
                ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, TimeRangeFilter.between(s.startTime, s.endTime))
            ).records
            var sum = 0.0
            var n = 0
            for (r in recs) {
                sum += r.heartRateVariabilityMillis
                n++
            }
            if (n >= 1) sum / n else null
        }
    } catch (e: Throwable) {
        null
    }

    private fun compute(ctx: Context, client: HealthConnectClient, granted: Set<String>): WellnessData {
        val now = Instant.now()
        val range = TimeRangeFilter.between(now.minus(Duration.ofDays(9)), now)
        val all = runBlocking { client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, range)).records }
        val sessions = all
            .filter { Duration.between(it.startTime, it.endTime).toMinutes() >= 90 }
            .sortedBy { it.endTime }
        if (sessions.isEmpty()) {
            val msg = if (all.isEmpty()) {
                "Health Connect has no sleep records from the last 9 days. Samsung Health has to record your sleep " +
                    "(watch, phone sleep tracking or manual entry) and share it with Health Connect."
            } else {
                "Health Connect only has very short sleep records (under 90 minutes) from the last 9 days."
            }
            return WellnessData(null, null, msg)
        }

        val last = sessions[sessions.size - 1]
        val ago = Duration.between(last.endTime, now).toHours()
        if (ago > 48) {
            return WellnessData(null, null, "Your latest sleep in Health Connect ended " + ago + " hours ago, so there is nothing new to show.")
        }

        val stages = stagesOf(last)
        val durMin = Duration.between(last.startTime, last.endTime).toMinutes().toInt()
        val score = scoreOf(durMin, stages)

        var delta: Int? = null
        if (sessions.size >= 2) {
            val prev = sessions[sessions.size - 2]
            val pMin = Duration.between(prev.startTime, prev.endTime).toMinutes().toInt()
            delta = score - scoreOf(pMin, stagesOf(prev))
        }
        val shownStages = if (stages.isEmpty()) {
            listOf(SleepStage(last.startTime.toEpochMilli(), last.endTime.toEpochMilli(), 2))
        } else {
            stages
        }
        val sleep = SleepData(last.startTime.toEpochMilli(), last.endTime.toEpochMilli(), durMin, score, delta, shownStages)

        // sleeping heart rate and HRV against the earlier nights
        var hrDev: Double? = null
        var hrvDev: Double? = null
        val older = sessions.subList(0, sessions.size - 1).takeLast(7)
        if (older.size >= 2) {
            if (granted.contains(READ_HR)) {
                val cur = avgHr(client, last)
                val base = ArrayList<Double>()
                for (o in older) avgHr(client, o)?.let { base.add(it) }
                if (cur != null && base.size >= 2) {
                    val b = base.sum() / base.size
                    if (b > 0) hrDev = (cur - b) / b
                }
            }
            if (granted.contains(READ_HRV)) {
                val cur = avgHrv(client, last)
                val base = ArrayList<Double>()
                for (o in older) avgHrv(client, o)?.let { base.add(it) }
                if (cur != null && base.size >= 2) {
                    val b = base.sum() / base.size
                    if (b > 0) hrvDev = (cur - b) / b
                }
            }
        }

        var wSum = 0.6
        var vSum = 0.6 * score
        hrDev?.let { d ->
            val v = if (d <= 0.0) 100.0 else Math.max(20.0, 100.0 - (d / 0.10) * 60.0)
            wSum += 0.2
            vSum += 0.2 * v
        }
        hrvDev?.let { d ->
            val v = if (d >= 0.0) 100.0 else Math.max(20.0, 100.0 - (-d / 0.30) * 60.0)
            wSum += 0.2
            vSum += 0.2 * v
        }
        val energy = Math.round(vSum / wSum).toInt().coerceIn(0, 99)

        // compare with the score from the day before (kept in a tiny pref file)
        val sp = ctx.getSharedPreferences("wellness", Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        var eDelta: Int? = null
        val lastDate = sp.getString("energy_date", null)
        if (lastDate != today) {
            if (lastDate != null) sp.edit().putInt("energy_prev", sp.getInt("energy_last", energy)).putBoolean("has_prev", true).apply()
            sp.edit().putString("energy_date", today).apply()
        }
        sp.edit().putInt("energy_last", energy).apply()
        if (sp.getBoolean("has_prev", false)) eDelta = energy - sp.getInt("energy_prev", energy)

        val e = EnergyData(
            energy, eDelta, score,
            hrDev?.let { Math.round(it * 100).toInt() },
            hrvDev?.let { Math.round(it * 100).toInt() }
        )
        return WellnessData(sleep, e)
    }
}
