package com.example.nowbrief

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.widget.LinearLayout
import java.util.Calendar
import java.util.concurrent.Executors

class MomentsData(val photos: List<Bitmap>, val total: Int)

/** Today's camera photos (screenshots are skipped), shown as a small collage. */
object MomentsRepo {
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED

    fun load(ctx: Context, cb: (MomentsData?) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            var data: MomentsData? = null
            try {
                data = query(app)
            } catch (e: Throwable) {
                data = null
            }
            val d = data
            ui.post { cb(d) }
        }
    }

    private fun query(ctx: Context): MomentsData? {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startMs = cal.timeInMillis
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH
        )
        val sel = "(" + MediaStore.Images.Media.DATE_TAKEN + " >= ? OR " + MediaStore.Images.Media.DATE_ADDED + " >= ?)"
        val args = arrayOf(startMs.toString(), (startMs / 1000L).toString())
        val ids = ArrayList<Long>()
        val c = ctx.contentResolver.query(uri, proj, sel, args, MediaStore.Images.Media.DATE_ADDED + " DESC") ?: return null
        c.use {
            val iId = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val iName = it.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val iPath = it.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            while (it.moveToNext() && ids.size < 60) {
                val name = (it.getString(iName) ?: "").lowercase(Locale_US)
                val path = (it.getString(iPath) ?: "").lowercase(Locale_US)
                if (name.contains("screenshot") || path.contains("screenshot") || path.contains("screen_record")) continue
                ids.add(it.getLong(iId))
            }
        }
        if (ids.isEmpty()) return null
        // three photos spread over the day
        val pick = ArrayList<Long>()
        pick.add(ids[0])
        if (ids.size >= 3) {
            pick.add(ids[ids.size / 2])
            pick.add(ids[ids.size - 1])
        } else if (ids.size == 2) {
            pick.add(ids[1])
        }
        val out = ArrayList<Bitmap>()
        for (id in pick) {
            try {
                val u = ContentUris.withAppendedId(uri, id)
                out.add(ctx.contentResolver.loadThumbnail(u, Size(600, 600), null))
            } catch (e: Exception) {
            }
        }
        if (out.isEmpty()) return null
        return MomentsData(out, ids.size)
    }

    private val Locale_US: java.util.Locale = java.util.Locale.US
}

/** Up to three rounded photos, the small ones tilted a little (like the original evening brief). */
class CollageView(ctx: Context) : View(ctx) {
    private var photos: List<Bitmap> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val m = Matrix()

    fun setPhotos(list: List<Bitmap>) {
        photos = list
        invalidate()
    }

    private fun photo(c: Canvas, b: Bitmap, x: Float, y: Float, w: Float, h: Float, rot: Float) {
        c.save()
        c.rotate(rot, x + w / 2f, y + h / 2f)
        val sc = Math.max(w / b.width, h / b.height)
        m.reset()
        m.setScale(sc, sc)
        m.postTranslate(x + (w - b.width * sc) / 2f, y + (h - b.height * sc) / 2f)
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(m)
        paint.shader = sh
        rect.set(x, y, x + w, y + h)
        val r = context.dp(20).toFloat()
        c.drawRoundRect(rect, r, r, paint)
        c.restore()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val n = photos.size
        if (n == 0) return
        if (n == 1) {
            photo(canvas, photos[0], 0f, 0f, w, h, 0f)
            return
        }
        photo(canvas, photos[0], 0f, 0.10f * h, 0.66f * w, 0.80f * h, 0f)
        photo(canvas, photos[1], 0.58f * w, 0f, 0.42f * w, 0.50f * h, 4f)
        if (n >= 3) photo(canvas, photos[2], 0.52f * w, 0.54f * h, 0.48f * w, 0.44f * h, -5f)
    }
}

object MomentsCards {
    private val WRAP = MoreCards.WRAP
    private val MATCH = MoreCards.MATCH

    fun card(ctx: Context, light: Boolean, d: MomentsData): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Moments", 13f, MoreCards.alpha(ink, 0xA6), false))
        val collage = CollageView(ctx)
        collage.setPhotos(d.photos)
        card.addView(collage, MoreCards.lp(ctx, MATCH, ctx.dp(250), 10, 0))
        val n = d.total
        val cap = MoreCards.text(ctx, if (n == 1) "1 photo today" else n.toString() + " photos today", 14f, MoreCards.alpha(ink, 0xCC), false)
        cap.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 10, 0)
        card.addView(cap)
        return card
    }

    fun prompt(ctx: Context, light: Boolean, onAllow: () -> Unit): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Moments", 13f, MoreCards.alpha(ink, 0xA6), false))
        val t = MoreCards.text(ctx, "Allow photo access to see your photos from today here.", 14.5f, MoreCards.alpha(ink, 0xE6), false)
        t.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 10, 0)
        card.addView(t)
        card.addView(MoreCards.solidButton(ctx, "Allow photo access", onAllow))
        return card
    }
}
