package com.example.nowbrief

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Everything the audio brief may talk about. A null part is simply left out. */
class BriefInput(
    val greeting: String,
    val weather: WeatherData?,
    val eventLine: String?,
    val plans: List<CalEvent>?,
    val sleep: SleepData?,
    val energy: EnergyData?,
    val health: HealthData?,
    val wellbeing: WellbeingData?,
    val includeAlarm: Boolean,
    val includeBattery: Boolean
)

object AudioBrief {

    private fun dur(min: Int): String {
        val h = min / 60
        val m = min % 60
        val hs = if (h == 1) "1 hour" else h.toString() + " hours"
        val ms = if (m == 1) "1 minute" else m.toString() + " minutes"
        return if (h > 0 && m > 0) hs + " " + ms else if (h > 0) hs else ms
    }

    /** One line per topic; the speaker reads each line as its own sentence group. */
    fun compose(ctx: Context, b: BriefInput): List<String> {
        val out = ArrayList<String>()
        val time = SimpleDateFormat("h:mm a", Locale.US)

        if (b.greeting.isNotBlank()) out.add(b.greeting)

        val w = b.weather
        if (w != null) {
            var s = "It's " + w.temp + " degrees and " + WeatherRepo.condition(w.code).lowercase(Locale.US)
            if (w.city.isNotBlank()) s += " in " + w.city
            s += ". Today's high is " + w.hi + " and the low is " + w.lo + "."
            out.add(s)
        }

        if (b.eventLine != null) out.add(b.eventLine)

        if (b.includeAlarm) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val info = am?.nextAlarmClock
            if (info == null) {
                out.add("You have no alarm set.")
            } else {
                val whenText = time.format(Date(info.triggerTime))
                val cal = Calendar.getInstance()
                cal.timeInMillis = info.triggerTime
                val today = Calendar.getInstance()
                val sameDay = cal.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR) &&
                    cal.get(Calendar.YEAR) == today.get(Calendar.YEAR)
                val day = if (sameDay) "" else SimpleDateFormat(" EEEE", Locale.US).format(Date(info.triggerTime))
                out.add("Your next alarm is at " + whenText + day + ".")
            }
        }

        val plans = b.plans
        if (plans != null) {
            if (plans.isEmpty()) {
                out.add("You have no plans listed for today.")
            } else {
                val sb = StringBuilder()
                sb.append(if (plans.size == 1) "You have 1 plan today. " else "You have " + plans.size + " plans today. ")
                for (p in plans.take(5)) {
                    if (p.allDay) sb.append(p.title).append(". ")
                    else sb.append("At ").append(time.format(Date(p.begin))).append(", ").append(p.title).append(". ")
                }
                out.add(sb.toString().trim())
            }
        }

        val sl = b.sleep
        if (sl != null) {
            out.add("You slept " + dur(sl.durationMin) + ", and your sleep score is " + sl.score + ".")
        }
        val en = b.energy
        if (en != null) {
            out.add("Your estimated energy score for today is " + en.score + ".")
        }

        val h = b.health
        if (h != null) {
            val goal = Math.max(1, Prefs.goalSteps(ctx))
            val pct = Math.min(999L, h.steps * 100L / goal)
            out.add(
                "So far today you have taken " + h.steps + " steps, which is " + pct + " percent of your goal. " +
                    "You have been active for " + dur(h.activeMin) + " and burned " + h.kcal + " active calories."
            )
        }

        val wb = b.wellbeing
        if (wb != null) {
            var s = "Your screen time today is " + dur((wb.totalMs / 60000L).toInt()) + ", with " + wb.unlocks + " unlocks."
            if (wb.top.isNotEmpty()) s += " Your most used app is " + wb.top[0].name + "."
            out.add(s)
        }

        if (b.includeBattery) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (level >= 0 && scale > 0) {
                    val pct = Math.round(level * 100f / scale)
                    val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                    out.add("Your battery is at " + pct + " percent" + (if (plugged) " and charging." else "."))
                }
            }
        }

        out.add("That's your brief.")
        return out
    }
}

/** Reads the brief aloud with the phone's text-to-speech voice. */
class BriefSpeaker(
    private val ctx: Context,
    private val onState: (Boolean) -> Unit,
    private val onUnavailable: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: List<String>? = null
    private val ui = Handler(Looper.getMainLooper())

    var speaking = false
        private set

    private fun mark(on: Boolean) {
        speaking = on
        ui.post { onState(on) }
    }

    fun speak(lines: List<String>) {
        pending = lines
        val t = tts
        if (t == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                ui.post {
                    if (status == TextToSpeech.SUCCESS) {
                        ready = true
                        setup()
                        flush()
                    } else {
                        tts = null
                        pending = null
                        onUnavailable()
                    }
                }
            }
        } else if (ready) {
            flush()
        }
    }

    private fun setup() {
        val t = tts ?: return
        val r = t.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId == "brief_last") mark(false)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mark(false)
            }
        })
    }

    private fun flush() {
        val t = tts ?: return
        val lines = pending ?: return
        pending = null
        if (lines.isEmpty()) return
        mark(true)
        for ((i, line) in lines.withIndex()) {
            val id = if (i == lines.size - 1) "brief_last" else "brief_$i"
            t.speak(line, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    fun stop() {
        pending = null
        val t = tts
        if (t != null && speaking) t.stop()
        if (speaking) mark(false)
    }

    fun shutdown() {
        pending = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        speaking = false
    }
}
