package com.example.nowbrief

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.animation.LinearInterpolator
import android.widget.TextView

/**
 * The title, subtitle and the sentences above the cards. The text is invisible until it
 * is revealed from left to right; the freshly revealed letters are yellow, then they turn
 * peach, light green, green and teal as they age, and finally white (the normal color).
 */
class SweepTextView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : TextView(ctx, attrs) {

    /** kept for old callers, not used any more */
    var palette = 0
    var played = false
        private set
    private var light = false
    private var anim: ValueAnimator? = null
    private val starter = Runnable { startSweep() }

    init {
        hide()
    }

    fun setInk(ink: Int) {
        light = Color.luminance(ink) < 0.5f
    }

    private fun hide() {
        paint.shader = LinearGradient(
            0f, 0f, 1f, 0f, Color.TRANSPARENT, Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        invalidate()
    }

    /** Back to "hidden, not played yet" (used when the page is shown again). */
    fun rearm() {
        removeCallbacks(starter)
        anim?.cancel()
        played = false
        hide()
    }

    fun play(delayMs: Long = 0L) {
        if (played) return
        played = true
        if (delayMs <= 0L) startSweep() else postDelayed(starter, delayMs)
    }

    // age (seconds since the letter was revealed) -> color
    private val ages = floatArrayOf(0f, 0.35f, 0.8f, 1.25f, 1.7f, 2.2f, 2.6f)

    private fun ramp(base: Int): IntArray {
        return if (light) {
            intArrayOf(
                0xFFD9A300.toInt(), 0xFFE08A1E.toInt(), 0xFF9AA81A.toInt(),
                0xFF22A35C.toInt(), 0xFF0E9B94.toInt(), blend(0xFF0E9B94.toInt(), base, 0.5f), base
            )
        } else {
            intArrayOf(
                0xFFFFE87A.toInt(), 0xFFFFBF8A.toInt(), 0xFFD6E68A.toInt(),
                0xFF7FE8A2.toInt(), 0xFF5ED9C9.toInt(), blend(0xFF5ED9C9.toInt(), base, 0.55f), base
            )
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        val al = (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt()
        return Color.argb(al, r, g, bl)
    }

    private fun colorAt(age: Float, cols: IntArray): Int {
        if (age < 0f) return Color.TRANSPARENT
        var c = cols[cols.size - 1]
        if (age < ages[ages.size - 1]) {
            var i = 0
            while (i < ages.size - 2 && age > ages[i + 1]) i++
            val t = (age - ages[i]) / (ages[i + 1] - ages[i])
            c = blend(cols[i], cols[i + 1], t.coerceIn(0f, 1f))
        }
        val fade = Math.min(1f, age / 0.07f)
        return Color.argb((Color.alpha(c) * fade).toInt(), Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun startSweep() {
        val lay = layout
        if (lay == null || width == 0) {
            // not laid out yet: try again in a moment
            postDelayed(starter, 60)
            return
        }
        var textW = 1f
        for (i in 0 until lay.lineCount) textW = Math.max(textW, lay.getLineWidth(i))
        val speed = 280f * resources.displayMetrics.density   // px per second
        val reveal = textW / speed
        val total = reveal + ages[ages.size - 1]
        val cols = ramp(currentTextColor)
        val n = 28
        val pos = FloatArray(n)
        val colors = IntArray(n)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, total)
        a.duration = (total * 1000f).toLong()
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val t = it.animatedValue as Float
            for (k in 0 until n) {
                val u = k / (n - 1f)
                pos[k] = u
                colors[k] = colorAt(t - u * reveal, cols)
            }
            paint.shader = LinearGradient(0f, 0f, textW, 0f, colors, pos, Shader.TileMode.CLAMP)
            invalidate()
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                paint.shader = null
                invalidate()
            }
        })
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(starter)
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}
