package com.example.nowbrief

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** Page shell in the original look: phase background, sparkles, title, small glass buttons. Cards come next. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_FROM_NOW_BAR = "from_now_bar"
    }

    private var sparkAnim: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        if (intent?.getBooleanExtra(EXTRA_FROM_NOW_BAR, false) == true && Prefs.expandWithoutUnlock(this)) {
            setShowWhenLocked(true)
        }
        setContentView(R.layout.activity_main)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val page = PageTheme.at(hour)
        val titles = PageTheme.title(hour)

        findViewById<ImageView>(R.id.page_bg).setImageResource(page.bg)
        findViewById<View>(R.id.content_root).applySystemBarPadding()

        val ink = if (page.light) 0xFF161616.toInt() else Color.WHITE
        val title = findViewById<TextView>(R.id.main_title)
        title.text = titles.first
        title.setTextColor(ink)
        val sub = findViewById<TextView>(R.id.main_sub)
        sub.text = titles.second
        sub.setTextColor((ink and 0x00FFFFFF) or (0xE6 shl 24))
        findViewById<TextView>(R.id.main_note).setTextColor((ink and 0x00FFFFFF) or (0x99 shl 24))

        val glass = if (page.light) R.drawable.glass_circle_light else R.drawable.glass_circle_dark
        for (id in intArrayOf(R.id.btn_audio, R.id.btn_info, R.id.btn_settings)) {
            findViewById<ImageButton>(id).setBackgroundResource(glass)
        }

        val bars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (page.light) bars else 0, bars)

        findViewById<View>(R.id.btn_audio).setOnClickListener {
            Toast.makeText(this, "Audio brief comes in a later part", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btn_info).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Now Brief")
                .setMessage("This briefing is built on your phone. Weather, calendar and health cards arrive in the next packages.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(this)
        val sparkles = findViewById<View>(R.id.sparkles)
        sparkAnim = ObjectAnimator.ofPropertyValuesHolder(
            sparkles,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.12f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.12f)
        ).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    override fun onPause() {
        sparkAnim?.cancel()
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Refresher.refreshAll(this)
    }
}
