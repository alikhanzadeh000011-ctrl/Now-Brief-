package com.example.nowbrief

import android.app.Activity
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowInsetsController
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class Category(val key: String, val name: String, val icon: Int)

object Categories {
    val ALL = listOf(
        Category("health", "Health and wellness", R.drawable.cat_health),
        Category("travel", "Travel", R.drawable.cat_travel),
        Category("events", "Events and tasks", R.drawable.cat_events),
        Category("routine", "Routine", R.drawable.cat_routine),
        Category("wellbeing", "Digital Wellbeing", R.drawable.cat_wellbeing),
        Category("communication", "Communication", R.drawable.cat_communication),
        Category("moments", "Moments", R.drawable.cat_moments),
        Category("gallery", "Gallery stories", R.drawable.cat_gallery),
        Category("parking", "Parking spot reminders", R.drawable.cat_parking),
        Category("news", "News", R.drawable.cat_news),
        Category("smarthome", "Smart home", R.drawable.cat_smarthome),
        Category("music", "Music and podcasts", R.drawable.cat_music)
    )
}

/** "Content to include": which card categories the briefing may show. */
class ContentActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        setContentView(R.layout.activity_content)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        findViewById<View>(R.id.content_root).applySystemBarPadding()
        window.insetsController?.setSystemBarsAppearance(
            if (night) 0 else WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )
        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }

        val list = findViewById<LinearLayout>(R.id.list)
        val inflater = LayoutInflater.from(this)
        for ((i, c) in Categories.ALL.withIndex()) {
            val row = inflater.inflate(R.layout.row_category, list, false)
            row.findViewById<ImageView>(R.id.icon).setImageResource(c.icon)
            row.findViewById<TextView>(R.id.name).text = c.name
            val sw = row.findViewById<Switch>(R.id.sw)
            sw.isChecked = Prefs.category(this, c.key)
            sw.setOnCheckedChangeListener { _, checked -> Prefs.setCategory(this, c.key, checked) }
            row.setOnClickListener { sw.toggle() }
            list.addView(row)
            if (i < Categories.ALL.size - 1) {
                val div = View(this)
                div.setBackgroundColor(resources.getColor(R.color.divider, theme))
                list.addView(div, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
            }
        }
    }
}
