package com.example.nowbrief

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Reads the card titles aloud with the phone's text-to-speech voice. */
class BriefSpeaker(
    private val ctx: Context,
    private val onState: (Boolean) -> Unit,
    private val onUnavailable: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: List<String>? = null
    private val ui = Handler(Looper.getMainLooper())

    var speaking = false
        private set

    private fun mark(on: Boolean) {
        speaking = on
        ui.post { onState(on) }
    }

    fun speak(lines: List<String>) {
        pending = lines
        val t = tts
        if (t == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                ui.post {
                    if (status == TextToSpeech.SUCCESS) {
                        ready = true
                        setup()
                        flush()
                    } else {
                        tts = null
                        pending = null
                        onUnavailable()
                    }
                }
            }
        } else if (ready) {
            flush()
        }
    }

    private fun setup() {
        val t = tts ?: return
        val r = t.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId == "brief_last") mark(false)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mark(false)
            }
        })
    }

    private fun flush() {
        val t = tts ?: return
        val lines = pending ?: return
        pending = null
        if (lines.isEmpty()) return
        mark(true)
        for ((i, line) in lines.withIndex()) {
            val id = if (i == lines.size - 1) "brief_last" else "brief_$i"
            t.speak(line, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    fun stop() {
        pending = null
        val t = tts
        if (t != null && speaking) t.stop()
        if (speaking) mark(false)
    }

    fun shutdown() {
        pending = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        speaking = false
    }
}
