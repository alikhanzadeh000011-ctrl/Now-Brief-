package com.example.nowbrief

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.BatteryManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Round battery gauge with a bolt while charging. */
class BatteryRingView(ctx: Context) : View(ctx) {
    private var pct = 0
    private var charging = false
    private var ink = Color.WHITE
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val bolt = Path()

    init {
        track.style = Paint.Style.STROKE
        bar.style = Paint.Style.STROKE
        bar.strokeCap = Paint.Cap.ROUND
        fill.style = Paint.Style.FILL
    }

    fun set(percent: Int, isCharging: Boolean, inkColor: Int) {
        pct = percent.coerceIn(0, 100)
        charging = isCharging
        ink = inkColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = Math.min(width, height).toFloat()
        val sw = s * 0.12f
        track.strokeWidth = sw
        bar.strokeWidth = sw
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f - sw / 2f - 1f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        track.color = (ink and 0x00FFFFFF) or (0x2A shl 24)
        canvas.drawArc(rect, 0f, 360f, false, track)
        val col = when {
            charging -> 0xFF35D6A0.toInt()
            pct >= 50 -> 0xFF34D058.toInt()
            pct >= 20 -> 0xFFFFB020.toInt()
            else -> 0xFFFF5A4D.toInt()
        }
        bar.color = col
        if (pct > 0) canvas.drawArc(rect, -90f, 360f * pct / 100f, false, bar)
        if (charging) {
            val u = s * 0.2f
            bolt.reset()
            bolt.moveTo(cx + 0.1f * u, cy - 1.0f * u)
            bolt.lineTo(cx - 0.6f * u, cy + 0.15f * u)
            bolt.lineTo(cx - 0.05f * u, cy + 0.15f * u)
            bolt.lineTo(cx - 0.15f * u, cy + 1.0f * u)
            bolt.lineTo(cx + 0.6f * u, cy - 0.2f * u)
            bolt.lineTo(cx + 0.05f * u, cy - 0.2f * u)
            bolt.close()
            fill.color = col
            canvas.drawPath(bolt, fill)
        }
    }
}

/** The date card and the battery card. */
object RoutineCards {
    private val WRAP = MoreCards.WRAP
    private val MATCH = MoreCards.MATCH

    // ------------------------------------------------------------------ date

    fun date(ctx: Context, light: Boolean): View {
        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        val now = Calendar.getInstance()
        val weekday = SimpleDateFormat("EEEE", Locale.US).format(now.time)
        val monthYear = SimpleDateFormat("MMMM yyyy", Locale.US).format(now.time)

        card.addView(MoreCards.text(ctx, "Calendar", 13f, MoreCards.alpha(ink, 0xA6), false))

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 6, 0)
        row.addView(MoreCards.text(ctx, now.get(Calendar.DAY_OF_MONTH).toString(), 58f, ink, true))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(MoreCards.text(ctx, monthYear, 22f, ink, true))
        col.addView(MoreCards.text(ctx, weekday, 17f, MoreCards.alpha(ink, 0xE6), false))
        row.addView(col, MoreCards.lp(ctx, WRAP, WRAP, 0, 16))
        card.addView(row)
        return card
    }

    // ------------------------------------------------------------------ battery

    fun battery(ctx: Context, light: Boolean): View? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return null
        val pct = Math.round(level * 100f / scale)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val full = status == BatteryManager.BATTERY_STATUS_FULL || (plugged && pct >= 100)
        val charging = plugged && !full
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f

        var remainMs = -1L
        if (charging) {
            try {
                remainMs = ctx.getSystemService(BatteryManager::class.java).computeChargeTimeRemaining()
            } catch (e: Exception) {
                remainMs = -1L
            }
        }

        val ink = MoreCards.inkOf(light)
        val card = MoreCards.card(ctx, light)
        card.addView(MoreCards.text(ctx, "Battery", 13f, MoreCards.alpha(ink, 0xA6), false))

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 6, 0)
        val left = LinearLayout(ctx)
        left.orientation = LinearLayout.VERTICAL
        left.addView(MoreCards.text(ctx, pct.toString() + "%", 46f, ink, true))
        val state = if (full) "Fully charged" else if (charging) "Charging" else "Not charging"
        left.addView(MoreCards.text(ctx, state, 15f, ink, false))
        top.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val ring = BatteryRingView(ctx)
        ring.set(pct, charging, ink)
        top.addView(ring, LinearLayout.LayoutParams(ctx.dp(84), ctx.dp(84)))
        card.addView(top)

        val tip = if (charging && remainMs > 0L) {
            "Full in about " + WellnessCards.fmtDur(Math.max(1L, remainMs / 60000L).toInt()) + "."
        } else if (charging) {
            "Plugged in and charging."
        } else if (full) {
            "You can unplug it now."
        } else if (pct <= 15) {
            "Battery is very low. Plug in soon."
        } else if (pct <= 30) {
            "Battery is getting low. Keep a charger close."
        } else {
            "Looks good for now."
        }
        val tipView = MoreCards.text(ctx, tip, 14.5f, MoreCards.alpha(ink, 0xE6), false)
        tipView.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 12, 0)
        card.addView(tipView)
        if (temp >= 40f) {
            val hot = MoreCards.text(ctx, "Battery is warm (" + Math.round(temp) + "\u00B0C).", 13.5f, MoreCards.alpha(ink, 0xB3), false)
            hot.layoutParams = MoreCards.lp(ctx, MATCH, WRAP, 4, 0)
            card.addView(hot)
        }
        return card
    }
}
