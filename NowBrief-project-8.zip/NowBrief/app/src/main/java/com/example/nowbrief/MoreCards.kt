package com.example.nowbrief

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Calendar, driving and "stay up to date" cards. Buttons are plain solid shapes (no blur), so they stay crisp. */
object MoreCards {
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    private fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)
    private fun inkOf(light: Boolean): Int = if (light) 0xFF161616.toInt() else 0xFFFFFFFF.toInt()

    private fun lp(ctx: Context, w: Int, h: Int, top: Int, start: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = ctx.dp(top)
        p.marginStart = ctx.dp(start)
        return p
    }

    private fun card(ctx: Context, light: Boolean): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(20))
        val g = GradientDrawable()
        g.cornerRadius = ctx.dp(28).toFloat()
        if (light) {
            g.setColor(0x8CFFFFFF.toInt())
        } else {
            g.setColor(0x1AFFFFFF)
            g.setStroke(ctx.dp(1), 0x2EFFFFFF)
        }
        c.background = g
        return c
    }

    private fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        return t
    }

    private fun softBox(ctx: Context, light: Boolean, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = ctx.dp(radiusDp).toFloat()
        g.setColor(if (light) 0x14000000 else 0x26FFFFFF)
        return g
    }

    /** White solid pill, crisp text. */
    private fun solidButton(ctx: Context, label: String, onClick: () -> Unit): TextView {
        val b = text(ctx, label, 16f, 0xFF1B1B1B.toInt(), true)
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = ctx.dp(24).toFloat()
        g.setColor(0xF2FFFFFF.toInt())
        b.background = g
        b.layoutParams = lp(ctx, MATCH, ctx.dp(48), 16, 0)
        b.setOnClickListener { onClick() }
        return b
    }

    /** Glass chip, for small actions. */
    private fun chip(ctx: Context, light: Boolean, label: String, onClick: () -> Unit): TextView {
        val b = text(ctx, label, 16f, inkOf(light), true)
        b.gravity = Gravity.CENTER
        b.setPadding(ctx.dp(22), ctx.dp(11), ctx.dp(22), ctx.dp(11))
        val g = GradientDrawable()
        g.cornerRadius = ctx.dp(24).toFloat()
        if (light) {
            g.setColor(0x14000000)
            g.setStroke(ctx.dp(1), 0x26000000)
        } else {
            g.setColor(0x33FFFFFF)
            g.setStroke(ctx.dp(1), 0x55FFFFFF)
        }
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun pencil(ctx: Context, light: Boolean, onClick: () -> Unit): View {
        val v = ImageView(ctx)
        v.setImageResource(R.drawable.ic_pencil)
        v.setColorFilter(inkOf(light))
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (light) 0x14000000 else 0x1FFFFFFF)
        v.background = g
        v.setPadding(ctx.dp(11), ctx.dp(11), ctx.dp(11), ctx.dp(11))
        v.layoutParams = lp(ctx, ctx.dp(44), ctx.dp(44), 10, 0)
        v.setOnClickListener { onClick() }
        return v
    }

    // ------------------------------------------------------------------ plans for today

    fun plans(ctx: Context, light: Boolean, events: List<CalEvent>, onEdit: () -> Unit): View {
        val ink = inkOf(light)
        val card = card(ctx, light)
        card.addView(text(ctx, "Events and tasks", 15f, alpha(ink, 0xA6), false))
        val fmt = SimpleDateFormat("h:mm a", Locale.US)
        for ((i, e) in events.withIndex()) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, ctx.dp(12), 0, ctx.dp(12))

            val bar = View(ctx)
            val bg = GradientDrawable()
            bg.cornerRadius = ctx.dp(2).toFloat()
            bg.setColor(if (e.color != 0) e.color else 0xFF4E7FF2.toInt())
            bar.background = bg
            row.addView(bar, LinearLayout.LayoutParams(ctx.dp(4), ctx.dp(40)))

            val time = text(ctx, if (e.allDay) "All day" else fmt.format(Date(e.begin)), 17f, ink, true)
            row.addView(time, lp(ctx, ctx.dp(92), WRAP, 0, 14))

            val title = text(ctx, e.title, 17f, ink, false)
            title.maxLines = 2
            row.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

            row.addView(text(ctx, CalendarRepo.emoji(e.title), 26f, ink, false), lp(ctx, WRAP, WRAP, 0, 8))
            card.addView(row)

            if (i < events.size - 1) {
                val div = View(ctx)
                div.setBackgroundColor(alpha(ink, 0x1F))
                card.addView(div, LinearLayout.LayoutParams(MATCH, ctx.dp(1)))
            }
        }
        card.addView(pencil(ctx, light, onEdit))
        return card
    }

    // ------------------------------------------------------------------ an event worth keeping in mind

    fun event(ctx: Context, light: Boolean, e: CalEvent, onShare: () -> Unit, onEdit: () -> Unit): View {
        val ink = inkOf(light)
        val card = card(ctx, light)
        card.addView(text(ctx, "Events and tasks", 15f, alpha(ink, 0xA6), false))

        val title = text(ctx, e.title, 32f, ink, true)
        title.layoutParams = lp(ctx, MATCH, WRAP, 8, 0)
        card.addView(title)

        val subText = if (CalendarRepo.isToday(e.begin)) {
            "Still enough time to send something thoughtful tonight."
        } else {
            "Coming up soon. A good moment to plan something thoughtful."
        }
        val sub = text(ctx, subText, 18f, alpha(ink, 0xE6), false)
        sub.layoutParams = lp(ctx, MATCH, WRAP, 8, 0)
        card.addView(sub)

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = lp(ctx, MATCH, WRAP, 16, 0)
        val img = ImageView(ctx)
        img.setImageResource(R.drawable.ic_balloons)
        img.setPadding(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
        img.background = softBox(ctx, light, 24)
        row.addView(img, LinearLayout.LayoutParams(ctx.dp(84), ctx.dp(84)))
        row.addView(chip(ctx, light, "Share", onShare), lp(ctx, WRAP, WRAP, 0, 14))
        card.addView(row)

        card.addView(pencil(ctx, light, onEdit))
        return card
    }

    // ------------------------------------------------------------------ driving

    fun driving(ctx: Context, light: Boolean, onTry: () -> Unit): View {
        val ink = inkOf(light)
        val card = card(ctx, light)
        card.addView(text(ctx, "For your commute", 15f, alpha(ink, 0xA6), false))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.layoutParams = lp(ctx, MATCH, WRAP, 10, 0)
        val dot = ImageView(ctx)
        dot.setImageResource(R.drawable.ic_car)
        dot.setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        val dg = GradientDrawable()
        dg.shape = GradientDrawable.OVAL
        dg.setColor(0x66F5B841)
        dot.background = dg
        head.addView(dot, LinearLayout.LayoutParams(ctx.dp(38), ctx.dp(38)))
        head.addView(text(ctx, "When you're driving", 24f, ink, true), lp(ctx, WRAP, WRAP, 0, 12))
        card.addView(head)

        val body = text(ctx, "Maps and media are usually the first things you'll reach for. Keep both one tap away.", 17f, alpha(ink, 0xE6), false)
        body.layoutParams = lp(ctx, MATCH, WRAP, 12, 0)
        card.addView(body)
        for (b in listOf("\u2022  Open Maps", "\u2022  Resume playlist")) {
            val t = text(ctx, b, 17f, alpha(ink, 0xE6), false)
            t.layoutParams = lp(ctx, MATCH, WRAP, 8, 0)
            card.addView(t)
        }
        card.addView(solidButton(ctx, "Try it", onTry))
        return card
    }

    // ------------------------------------------------------------------ stay up to date

    fun stayUp(ctx: Context, light: Boolean): View {
        val ink = inkOf(light)
        val card = card(ctx, light)
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(ctx)
        img.setImageResource(R.drawable.ic_check_purple)
        img.setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(20))
        img.background = softBox(ctx, light, 22)
        row.addView(img, LinearLayout.LayoutParams(ctx.dp(84), ctx.dp(84)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(ctx, "Stay up to date with Now brief", 22f, ink, true))
        val sub = text(ctx, "Your full brief will be ready again first thing in the morning.", 17f, alpha(ink, 0xE6), false)
        sub.layoutParams = lp(ctx, MATCH, WRAP, 6, 0)
        col.addView(sub)
        row.addView(col, lp(ctx, 0, WRAP, 0, 16).also { it.weight = 1f })
        card.addView(row)
        return card
    }
}
