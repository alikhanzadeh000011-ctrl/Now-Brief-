package com.example.nowbrief

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

object Refresher {
    private val providers = listOf(
        CompactWidgetProvider::class.java to Kind.COMPACT,
        LargeWidgetProvider::class.java to Kind.LARGE,
        WideWidgetProvider::class.java to Kind.WIDE
    )

    fun kindOf(ctx: Context, id: Int): Kind {
        val name = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className
        return when (name) {
            CompactWidgetProvider::class.java.name -> Kind.COMPACT
            WideWidgetProvider::class.java.name -> Kind.WIDE
            else -> Kind.LARGE
        }
    }

    fun updateWidget(ctx: Context, id: Int, kind: Kind) {
        AppWidgetManager.getInstance(ctx).updateAppWidget(id, WidgetRenderer.build(ctx, id, kind))
    }

    /** Redraws every widget, re-posts the Now bar notification and schedules the next phase change. */
    fun refreshAll(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        for ((cls, kind) in providers) {
            for (id in mgr.getAppWidgetIds(ComponentName(app, cls))) {
                mgr.updateAppWidget(id, WidgetRenderer.build(app, id, kind))
            }
        }
        NowBarNotifier.post(app)
        PhaseScheduler.scheduleNext(app)
    }
}

object PhaseScheduler {
    const val ACTION_TICK = "com.example.nowbrief.action.PHASE_TICK"

    fun tickIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, PhaseReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun scheduleNext(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        val at = Phase.nextBoundaryMillis(System.currentTimeMillis()) + 5_000L
        // Inexact alarm: needs no special permission, may fire a little late in Doze.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, tickIntent(app))
    }
}

class PhaseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Refresher.refreshAll(context)
    }
}
