package com.example.nowbrief

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Bundle

/**
 * Posts ONE ongoing notification that One UI shows in the Now bar.
 * No foreground service on purpose: a plain ongoing notification survives
 * the app process being killed, and is refreshed by an alarm at each phase change.
 */
object NowBarNotifier {
    private const val CHANNEL_ID = "now_brief_now_bar"
    private const val NOTIF_ID = 7001

    private fun chipColor(phase: Phase): Int = when (phase) {
        Phase.MORNING -> 0xFF3FA9F5.toInt()
        Phase.MIDDAY -> 0xFF4FB3A6.toInt()
        Phase.AFTERNOON -> 0xFFB8A23E.toInt()
        Phase.EVENING -> 0xFF9B6FD6.toInt()
        Phase.LATE_NIGHT -> 0xFF4256B5.toInt()
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
    }

    fun post(ctx: Context) {
        if (!Prefs.nowBar(ctx)) {
            cancel(ctx)
            return
        }
        if (ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return

        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Now Brief", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Keeps Now Brief on the Now bar"
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }

        val phase = Phase.current()
        val icon = Icon.createWithResource(ctx, phase.badge)

        val open = PendingIntent.getActivity(
            ctx, 7,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_FROM_NOW_BAR, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val extras = Bundle()
        // Samsung Now bar / Live notification keys (same ones the working patched build used)
        extras.putInt("android.ongoingActivityNoti.style", 1)
        extras.putString("android.ongoingActivityNoti.primaryInfo", "Now Brief")
        extras.putString("android.ongoingActivityNoti.secondaryInfo", "Get today's highlight")
        extras.putString("android.ongoingActivityNoti.chipExpandedText", phase.compactTitle)
        extras.putInt("android.ongoingActivityNoti.chipBgColor", chipColor(phase))
        extras.putParcelable("android.ongoingActivityNoti.chipIcon", icon)
        extras.putParcelable("android.ongoingActivityNoti.firstIcon", icon)
        extras.putParcelable("android.ongoingActivityNoti.nowbarIcon", icon)
        extras.putString("android.ongoingActivityNoti.nowbarPrimaryInfo", "Now Brief")
        extras.putString("android.ongoingActivityNoti.nowbarSecondaryInfo", "Get today's highlight")
        // Android 16 "Live updates" request (harmless on older versions)
        extras.putBoolean("android.requestPromotedOngoing", true)

        val notif = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_brief)
            .setLargeIcon(icon)
            .setContentTitle(phase.compactTitle)
            .setContentText("Get today's highlight")
            .setContentIntent(open)
            .setDeleteIntent(PhaseScheduler.tickIntent(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addExtras(extras)
            .build()

        nm.notify(NOTIF_ID, notif)
    }
}
