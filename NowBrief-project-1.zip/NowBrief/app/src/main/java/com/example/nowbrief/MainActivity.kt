package com.example.nowbrief

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.widget.TextView
import android.widget.Toast

/** Part 1 placeholder page: right background, title and the three glass buttons. The full briefing arrives in Part 2. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_FROM_NOW_BAR = "from_now_bar"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra(EXTRA_FROM_NOW_BAR, false) == true && Prefs.expandWithoutUnlock(this)) {
            setShowWhenLocked(true)
        }
        setContentView(R.layout.activity_main)

        val phase = Phase.current()
        val root = findViewById<View>(R.id.main_root)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(phase.pageTop, phase.pageBottom)
        )
        root.applySystemBarPadding()
        window.insetsController?.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS)

        findViewById<TextView>(R.id.main_title).text = phase.pageTitle
        findViewById<TextView>(R.id.main_sub).text = phase.pageSubtitle

        findViewById<View>(R.id.btn_audio).setOnClickListener {
            Toast.makeText(this, "Audio brief comes in a later part", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btn_info).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Now Brief")
                .setMessage("This briefing is built on your phone. Weather, calendar and health cards arrive in Part 2.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(this)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Refresher.refreshAll(this)
    }
}
