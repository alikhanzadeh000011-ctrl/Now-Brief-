package com.example.nowbrief

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("now_brief", Context.MODE_PRIVATE)

    // ---- per widget
    fun blur(c: Context, id: Int): Int = sp(c).getInt("blur_$id", 0)
    fun setBlur(c: Context, id: Int, v: Int) = sp(c).edit().putInt("blur_$id", v).apply()
    fun darkTint(c: Context, id: Int): Boolean = sp(c).getBoolean("dark_$id", true)
    fun setDarkTint(c: Context, id: Int, v: Boolean) = sp(c).edit().putBoolean("dark_$id", v).apply()
    fun clearWidget(c: Context, id: Int) = sp(c).edit().remove("blur_$id").remove("dark_$id").apply()

    // ---- app settings
    fun audioBrief(c: Context): Boolean = sp(c).getBoolean("audio_brief", true)
    fun setAudioBrief(c: Context, v: Boolean) = sp(c).edit().putBoolean("audio_brief", v).apply()
    fun expandWithoutUnlock(c: Context): Boolean = sp(c).getBoolean("expand_without_unlock", true)
    fun setExpandWithoutUnlock(c: Context, v: Boolean) = sp(c).edit().putBoolean("expand_without_unlock", v).apply()
    fun nowBar(c: Context): Boolean = sp(c).getBoolean("now_bar", true)
    fun setNowBar(c: Context, v: Boolean) = sp(c).edit().putBoolean("now_bar", v).apply()

    // ---- "Content to include" categories
    fun category(c: Context, key: String): Boolean = sp(c).getBoolean("cat_$key", true)
    fun setCategory(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean("cat_$key", v).apply()

    // ---- glass buttons on the page: 0 = pure blur (#01FFFFFF tint), 100 = frosted white
    fun glass(c: Context): Int = sp(c).getInt("glass", 0)
    fun setGlass(c: Context, v: Int) = sp(c).edit().putInt("glass", v).apply()
}
