package com.example.nowbrief

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View

/**
 * Three nested hearts traced from the Samsung Health reference artwork:
 * steps (green, outer), active time (blue) and calories (pink, inner).
 * Progress runs clockwise from the top notch; the rest of each ring stays as a faint track.
 */
class HeartRingsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    companion object {
        // Reference artwork size and centre; radii are measured from the centre, every 2 degrees, clockwise from the top.
        private const val REF_W = 276f
        private const val REF_H = 244f
        private const val CX = 137.5f
        private const val CY = 121.5f
        private const val STROKE = 21f

        private val R_GREEN = floatArrayOf(102.1f, 102.8f, 104.4f, 106.1f, 107.6f, 109.1f, 110.8f, 112.4f, 114.1f, 115.8f, 117.4f, 118.8f, 120.2f, 121.5f, 122.8f, 124.1f, 125.1f, 126.0f, 126.9f, 128.0f, 129.0f, 129.6f, 130.2f, 130.8f, 131.4f, 131.8f, 132.2f, 132.7f, 132.9f, 132.8f, 132.8f, 132.8f, 132.4f, 132.0f, 131.9f, 131.7f, 131.2f, 130.7f, 130.1f, 129.4f, 128.6f, 127.7f, 126.6f, 125.4f, 124.2f, 123.2f, 122.0f, 120.5f, 119.2f, 118.1f, 116.8f, 115.4f, 114.1f, 112.6f, 111.2f, 110.0f, 109.0f, 107.9f, 106.9f, 106.0f, 105.1f, 104.2f, 103.6f, 103.1f, 102.5f, 102.1f, 102.0f, 102.0f, 101.9f, 101.9f, 101.9f, 102.0f, 102.2f, 102.5f, 102.8f, 103.3f, 103.9f, 104.6f, 105.2f, 105.8f, 106.5f, 107.3f, 108.0f, 108.4f, 108.8f, 109.1f, 109.6f, 109.9f, 110.1f, 110.4f, 110.6f, 110.4f, 110.1f, 109.9f, 109.6f, 109.1f, 108.8f, 108.3f, 107.8f, 107.2f, 106.5f, 105.8f, 105.2f, 104.6f, 104.0f, 103.4f, 102.9f, 102.5f, 102.2f, 102.0f, 101.9f, 101.9f, 101.9f, 102.0f, 102.0f, 102.1f, 102.5f, 102.9f, 103.4f, 104.1f, 105.1f, 105.9f, 106.8f, 107.8f, 108.8f, 109.9f, 111.2f, 112.6f, 114.1f, 115.3f, 116.6f, 118.0f, 119.2f, 120.5f, 121.9f, 123.0f, 124.1f, 125.2f, 126.2f, 127.3f, 128.4f, 129.4f, 129.9f, 130.3f, 131.1f, 131.6f, 131.8f, 131.9f, 132.2f, 132.5f, 132.6f, 132.5f, 132.4f, 132.2f, 131.9f, 131.7f, 131.2f, 130.6f, 130.1f, 129.6f, 128.9f, 128.1f, 127.1f, 126.1f, 125.0f, 123.8f, 122.8f, 121.8f, 120.3f, 118.7f, 117.2f, 115.8f, 114.2f, 112.8f, 111.4f, 109.6f, 107.9f, 106.2f, 104.4f, 102.8f)
        private val R_BLUE = floatArrayOf(70.5f, 71.1f, 72.4f, 73.9f, 75.6f, 77.4f, 79.4f, 81.4f, 83.2f, 85.0f, 86.8f, 88.7f, 90.4f, 91.8f, 93.4f, 94.9f, 96.2f, 97.6f, 98.9f, 99.9f, 101.1f, 101.9f, 102.5f, 103.4f, 104.1f, 104.5f, 104.9f, 105.4f, 105.6f, 105.5f, 105.4f, 105.4f, 105.1f, 104.8f, 104.5f, 104.1f, 103.6f, 103.0f, 102.2f, 101.2f, 100.2f, 99.1f, 97.9f, 96.8f, 95.6f, 94.2f, 92.9f, 91.6f, 90.0f, 88.4f, 87.2f, 85.9f, 84.6f, 83.4f, 82.4f, 81.4f, 80.2f, 79.0f, 78.2f, 77.6f, 77.1f, 76.6f, 76.0f, 75.4f, 75.0f, 74.9f, 74.8f, 74.7f, 74.6f, 74.5f, 74.6f, 74.8f, 75.0f, 75.2f, 75.5f, 75.9f, 76.5f, 77.1f, 77.6f, 78.4f, 78.9f, 79.5f, 80.2f, 80.9f, 81.4f, 81.8f, 82.2f, 82.5f, 82.7f, 82.7f, 82.6f, 82.7f, 82.7f, 82.5f, 82.2f, 81.8f, 81.4f, 80.9f, 80.2f, 79.4f, 78.8f, 78.1f, 77.4f, 76.8f, 76.4f, 76.0f, 75.6f, 75.2f, 75.0f, 74.8f, 74.6f, 74.5f, 74.5f, 74.5f, 74.5f, 74.6f, 74.9f, 75.4f, 75.8f, 76.2f, 76.8f, 77.5f, 78.2f, 79.0f, 80.2f, 81.3f, 82.2f, 83.2f, 84.4f, 85.7f, 87.1f, 88.4f, 89.8f, 91.2f, 92.6f, 94.0f, 95.5f, 96.8f, 97.9f, 99.0f, 100.0f, 100.9f, 101.6f, 102.4f, 103.2f, 104.0f, 104.5f, 104.8f, 105.1f, 105.3f, 105.4f, 105.5f, 105.5f, 105.1f, 104.8f, 104.4f, 104.1f, 103.4f, 102.5f, 101.6f, 100.8f, 99.9f, 98.9f, 97.7f, 96.5f, 95.2f, 93.9f, 92.3f, 90.5f, 88.9f, 87.3f, 85.6f, 83.8f, 81.9f, 79.8f, 77.6f, 75.7f, 73.9f, 72.4f, 71.1f)
        private val R_PINK = floatArrayOf(37.9f, 38.2f, 38.9f, 39.7f, 40.6f, 41.6f, 42.9f, 44.3f, 46.0f, 47.9f, 49.8f, 51.5f, 53.4f, 55.6f, 57.7f, 59.7f, 62.0f, 64.3f, 66.6f, 68.9f, 71.0f, 72.6f, 73.9f, 75.1f, 76.2f, 76.8f, 77.0f, 77.4f, 77.8f, 78.1f, 78.2f, 78.2f, 78.1f, 77.6f, 76.7f, 75.9f, 75.2f, 74.1f, 72.8f, 71.6f, 70.3f, 68.8f, 67.4f, 66.0f, 64.5f, 63.1f, 61.8f, 60.2f, 58.8f, 57.6f, 56.5f, 55.4f, 54.3f, 53.5f, 52.6f, 51.8f, 51.1f, 50.4f, 49.8f, 49.4f, 49.0f, 48.6f, 48.2f, 47.9f, 47.7f, 47.6f, 47.5f, 47.4f, 47.1f, 47.1f, 47.1f, 47.2f, 47.4f, 47.8f, 47.9f, 47.9f, 48.3f, 48.9f, 49.2f, 49.7f, 50.4f, 51.0f, 51.6f, 52.4f, 53.0f, 53.6f, 54.2f, 54.6f, 55.1f, 55.6f, 55.6f, 55.6f, 55.1f, 54.4f, 53.9f, 53.4f, 52.8f, 52.2f, 51.6f, 51.0f, 50.4f, 49.7f, 49.2f, 48.9f, 48.4f, 48.0f, 47.6f, 47.4f, 47.4f, 47.2f, 47.1f, 47.1f, 47.0f, 47.1f, 47.4f, 47.6f, 47.7f, 47.9f, 48.2f, 48.4f, 48.7f, 49.2f, 49.8f, 50.4f, 51.1f, 51.8f, 52.5f, 53.2f, 54.1f, 55.0f, 56.1f, 57.4f, 58.7f, 60.0f, 61.4f, 62.6f, 64.2f, 66.0f, 67.4f, 68.7f, 70.1f, 71.4f, 72.7f, 73.9f, 75.1f, 75.9f, 76.6f, 77.2f, 77.7f, 78.0f, 78.1f, 78.0f, 77.8f, 77.5f, 77.2f, 76.8f, 76.0f, 75.1f, 74.0f, 72.7f, 71.2f, 69.5f, 67.4f, 64.9f, 62.2f, 59.9f, 57.9f, 56.1f, 54.1f, 51.9f, 50.0f, 48.3f, 46.5f, 44.6f, 42.9f, 41.6f, 40.6f, 39.7f, 38.9f, 38.2f)

        // Colour along each ring, every 30 degrees from the top (deep to light), like the artwork
        private val C_GREEN = intArrayOf(0xFF00E254.toInt(), 0xFF00E357.toInt(), 0xFF00E55B.toInt(), 0xFF00E75F.toInt(), 0xFF00E862.toInt(), 0xFF00EA65.toInt(), 0xFF00EB69.toInt(), 0xFF00ED6C.toInt(), 0xFF00EE70.toInt(), 0xFF00F073.toInt(), 0xFF00F177.toInt(), 0xFF00F278.toInt())
        private val C_BLUE = intArrayOf(0xFF3E6DFE.toInt(), 0xFF4575FE.toInt(), 0xFF4C7DFE.toInt(), 0xFF5385FE.toInt(), 0xFF598CFD.toInt(), 0xFF6194FD.toInt(), 0xFF679CFD.toInt(), 0xFF6EA4FD.toInt(), 0xFF76ACFD.toInt(), 0xFF7CB4FD.toInt(), 0xFF83BCFD.toInt(), 0xFF87BFFD.toInt())
        private val C_PINK = intArrayOf(0xFFFF1A78.toInt(), 0xFFFF1F7B.toInt(), 0xFFFF237F.toInt(), 0xFFFF2983.toInt(), 0xFFFF2D86.toInt(), 0xFFFF338A.toInt(), 0xFFFF378E.toInt(), 0xFFFF3D92.toInt(), 0xFFFF4295.toInt(), 0xFFFF4699.toInt(), 0xFFFF4B9C.toInt(), 0xFFFF4E9E.toInt())
    }

    private val radii = arrayOf(R_GREEN, R_BLUE, R_PINK)
    private val sweeps = arrayOf(C_GREEN, C_BLUE, C_PINK)
    private val trackColors = intArrayOf(0xFF00E060.toInt(), 0xFF4C80FF.toInt(), 0xFFFF2D86.toInt())
    private val paths = arrayOf(Path(), Path(), Path())
    private val shown = floatArrayOf(0f, 0f, 0f)
    private val seg = Path()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shaders = arrayOfNulls<SweepGradient>(3)
    private var anim: ValueAnimator? = null

    init {
        track.style = Paint.Style.STROKE
        track.strokeCap = Paint.Cap.ROUND
        track.strokeJoin = Paint.Join.ROUND
        bar.style = Paint.Style.STROKE
        bar.strokeCap = Paint.Cap.ROUND
        bar.strokeJoin = Paint.Join.ROUND
    }

    private fun buildPath(r: FloatArray, s: Float, ox: Float, oy: Float, out: Path) {
        val n = r.size
        val px = FloatArray(n)
        val py = FloatArray(n)
        for (i in 0 until n) {
            val th = Math.toRadians(-90.0 + i * 360.0 / n)
            px[i] = ox + (CX + r[i] * Math.cos(th).toFloat()) * s
            py[i] = oy + (CY + r[i] * Math.sin(th).toFloat()) * s
        }
        out.reset()
        out.moveTo((px[0] + px[n - 1]) / 2f, (py[0] + py[n - 1]) / 2f)
        for (i in 0 until n) {
            val j = (i + 1) % n
            out.quadTo(px[i], py[i], (px[i] + px[j]) / 2f, (py[i] + py[j]) / 2f)
        }
        out.close()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val s = Math.min(w / REF_W, h / REF_H)
        val ox = (w - REF_W * s) / 2f
        val oy = (h - REF_H * s) / 2f
        track.strokeWidth = STROKE * s
        bar.strokeWidth = STROKE * s
        val cx = ox + CX * s
        val cy = oy + CY * s
        val pos = FloatArray(13) { it / 12f }
        for (k in 0..2) {
            buildPath(radii[k], s, ox, oy, paths[k])
            val colors = IntArray(13) { sweeps[k][Math.min(it, 11)] }
            val g = SweepGradient(cx, cy, colors, pos)
            val m = Matrix()
            m.setRotate(-90f, cx, cy)
            g.setLocalMatrix(m)
            shaders[k] = g
        }
    }

    fun setProgress(a: Float, b: Float, c: Float) {
        val to = floatArrayOf(a.coerceIn(0f, 1f), b.coerceIn(0f, 1f), c.coerceIn(0f, 1f))
        val from = shown.copyOf()
        anim?.cancel()
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 900
        va.addUpdateListener { v ->
            val f = v.animatedFraction
            for (k in 0..2) shown[k] = from[k] + (to[k] - from[k]) * f
            invalidate()
        }
        anim = va
        va.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        for (k in 0..2) {
            track.color = (trackColors[k] and 0x00FFFFFF) or (0x4D shl 24)
            canvas.drawPath(paths[k], track)
            if (shown[k] > 0.004f) {
                val pm = PathMeasure(paths[k], false)
                seg.reset()
                pm.getSegment(0f, pm.length * shown[k], seg, true)
                bar.shader = shaders[k]
                canvas.drawPath(seg, bar)
            }
        }
    }
}
