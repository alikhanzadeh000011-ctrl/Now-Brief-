package com.example.nowbrief

import android.app.Activity
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** One celebration art of the event card. */
class Art(val key: String, val label: String, val sendLabel: String, val icon: Int, val emoji: String)

object Arts {
    val ALL: List<Art> = listOf(
        Art("cake", "Cake + candles", "Send cake", R.drawable.ic_art_cake, "\uD83C\uDF82"),
        Art("balloons", "Balloons", "Send balloons", R.drawable.ic_balloons, "\uD83C\uDF88"),
        Art("gift", "Gift box", "Send gift", R.drawable.ic_art_gift, "\uD83C\uDF81"),
        Art("confetti", "Confetti", "Send confetti", R.drawable.ic_art_confetti, "\uD83C\uDF89"),
        Art("sparkle", "Sparkle cake", "Send sparkles", R.drawable.ic_art_sparkle, "\u2728")
    )

    fun of(key: String): Art = ALL.firstOrNull { it.key == key } ?: ALL[1]
}

/** A scroll view that never grows taller than [maxH] (the bottom sheet body). */
class SheetScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val avail = MeasureSpec.getSize(heightMeasureSpec)
        val cap = if (avail > 0) Math.min(avail, maxH) else maxH
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST))
    }
}

/** The white bottom sheets of the pencil buttons ("Edit schedule", "Edit event"). */
object Editors {
    private val INK = 0xFF14161B.toInt()
    private val GRAY = 0xFF6B7280.toInt()
    private val HINT = 0xFF9AA1AE.toInt()
    private val BLUE = 0xFF3D6BF0.toInt()
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private class Sheet(val dialog: Dialog, val content: LinearLayout)

    private fun rounded(fill: Int, radius: Float, stroke: Int, strokePx: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = radius
        g.setColor(fill)
        if (strokePx > 0) g.setStroke(strokePx, stroke)
        return g
    }

    private fun field(ctx: Context, focused: Boolean): GradientDrawable =
        if (focused) rounded(Color.WHITE, ctx.dp(22).toFloat(), 0xFF8AA6F8.toInt(), ctx.dp(2))
        else rounded(Color.WHITE, ctx.dp(22).toFloat(), 0xFFD9DEE9.toInt(), ctx.dp(1))

    private fun tv(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        return t
    }

    private fun lp(ctx: Context, w: Int, h: Int, top: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = ctx.dp(top)
        return p
    }

    private fun fmtMin(m: Int): String {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, m / 60)
        c.set(Calendar.MINUTE, m % 60)
        return SimpleDateFormat("h:mm a", Locale.US).format(c.time)
    }

    private fun newSheet(act: Activity): Sheet {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val maxH = (act.resources.displayMetrics.heightPixels * 0.88f).toInt()
        val sv = SheetScroll(act, maxH)
        sv.isVerticalScrollBarEnabled = false
        val r = act.dp(32).toFloat()
        val bg = GradientDrawable()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setColor(0xFFF8F9FD.toInt())
        sv.background = bg

        val content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(act.dp(26), act.dp(12), act.dp(26), act.dp(26))

        val handle = View(act)
        handle.background = rounded(0xFFC9CED8.toInt(), act.dp(3).toFloat(), 0, 0)
        val hp = LinearLayout.LayoutParams(act.dp(44), act.dp(5))
        hp.gravity = Gravity.CENTER_HORIZONTAL
        hp.bottomMargin = act.dp(14)
        content.addView(handle, hp)

        sv.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        d.setContentView(sv, ViewGroup.LayoutParams(MATCH, WRAP))
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
            w.setWindowAnimations(android.R.style.Animation_InputMethod)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.setDimAmount(0.55f)
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        return Sheet(d, content)
    }

    private fun header(act: Activity, sheet: Sheet, title: String) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(act)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(act, "Now Brief", 15f, GRAY, false))
        left.addView(tv(act, title, 30f, INK, true))
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val x = ImageView(act)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(INK)
        x.setPadding(act.dp(13), act.dp(13), act.dp(13), act.dp(13))
        val og = GradientDrawable()
        og.shape = GradientDrawable.OVAL
        og.setColor(0xFFECEFF6.toInt())
        x.background = og
        x.setOnClickListener { sheet.dialog.dismiss() }
        row.addView(x, LinearLayout.LayoutParams(act.dp(46), act.dp(46)))
        sheet.content.addView(row)
    }

    private fun footer(act: Activity, sheet: Sheet, onSave: () -> Unit) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = lp(act, MATCH, WRAP, 24)

        val cancel = tv(act, "Cancel", 18f, INK, true)
        cancel.gravity = Gravity.CENTER
        cancel.background = rounded(0xFFE9EDF6.toInt(), act.dp(27).toFloat(), 0, 0)
        cancel.setOnClickListener { sheet.dialog.dismiss() }
        row.addView(cancel, LinearLayout.LayoutParams(0, act.dp(54), 1f))

        val save = tv(act, "Save", 18f, Color.WHITE, true)
        save.gravity = Gravity.CENTER
        save.background = rounded(BLUE, act.dp(27).toFloat(), 0, 0)
        save.setOnClickListener { onSave() }
        val sp = LinearLayout.LayoutParams(0, act.dp(54), 1f)
        sp.marginStart = act.dp(12)
        row.addView(save, sp)
        sheet.content.addView(row)
    }

    // ------------------------------------------------------------------ Edit schedule

    fun editSchedule(act: Activity, onSaved: () -> Unit) {
        val sheet = newSheet(act)
        header(act, sheet, "Edit schedule")
        val c = sheet.content
        c.addView(tv(act, "Shape your day with a cleaner timeline.", 17f, GRAY, false), lp(act, MATCH, WRAP, 6))
        c.addView(tv(act, "Data source", 16f, GRAY, false), lp(act, MATCH, WRAP, 18))

        var mode = Prefs.schedMode(act)
        val times = IntArray(5) { Prefs.schedTime(act, it) }
        val plans = ArrayList<EditText>()
        val timeViews = ArrayList<TextView>()

        val chips = LinearLayout(act)
        chips.orientation = LinearLayout.HORIZONTAL
        val chipSaved = tv(act, "Saved schedule", 17f, INK, false)
        val chipCal = tv(act, "Calendar", 17f, INK, false)
        for (ch in listOf(chipSaved, chipCal)) {
            ch.gravity = Gravity.CENTER
            ch.setPadding(act.dp(24), act.dp(13), act.dp(24), act.dp(13))
        }
        chips.addView(chipSaved)
        val cp = LinearLayout.LayoutParams(WRAP, WRAP)
        cp.marginStart = act.dp(12)
        chips.addView(chipCal, cp)
        c.addView(chips, lp(act, MATCH, WRAP, 10))

        val rows = LinearLayout(act)
        rows.orientation = LinearLayout.VERTICAL
        for (i in 0 until 5) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL

            val colT = LinearLayout(act)
            colT.orientation = LinearLayout.VERTICAL
            colT.addView(tv(act, "Time " + (i + 1), 14f, GRAY, false))
            val tf = tv(act, "", 18f, INK, true)
            tf.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            tf.setPadding(act.dp(18), act.dp(17), act.dp(18), act.dp(17))
            tf.background = field(act, false)
            val show = {
                if (times[i] < 0) {
                    tf.text = "Set time"
                    tf.setTextColor(HINT)
                } else {
                    tf.text = fmtMin(times[i])
                    tf.setTextColor(INK)
                }
            }
            show()
            tf.setOnClickListener {
                val start = if (times[i] >= 0) times[i] else 12 * 60
                TimePickerDialog(act, { _, h, m ->
                    times[i] = h * 60 + m
                    show()
                }, start / 60, start % 60, false).show()
            }
            tf.setOnLongClickListener {
                times[i] = -1
                show()
                true
            }
            colT.addView(tf, lp(act, MATCH, WRAP, 6))
            timeViews.add(tf)

            val colP = LinearLayout(act)
            colP.orientation = LinearLayout.VERTICAL
            colP.addView(tv(act, "Plan " + (i + 1), 14f, GRAY, false))
            val et = EditText(act)
            et.setText(Prefs.schedPlan(act, i))
            et.hint = "Plan"
            et.setSingleLine(true)
            et.textSize = 18f
            et.setTextColor(INK)
            et.setHintTextColor(HINT)
            et.setPadding(act.dp(18), act.dp(15), act.dp(18), act.dp(15))
            et.background = field(act, false)
            et.imeOptions = EditorInfo.IME_ACTION_DONE
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            et.setOnFocusChangeListener { _, has -> et.background = field(act, has) }
            colP.addView(et, lp(act, MATCH, WRAP, 6))
            plans.add(et)

            row.addView(colT, LinearLayout.LayoutParams(0, WRAP, 0.85f))
            val pp = LinearLayout.LayoutParams(0, WRAP, 1.25f)
            pp.marginStart = act.dp(12)
            row.addView(colP, pp)
            rows.addView(row, lp(act, MATCH, WRAP, 16))
        }
        c.addView(rows)

        c.addView(tv(act, "Tip: long-press a time to clear it. Plans with no name are skipped.", 13f, GRAY, false), lp(act, MATCH, WRAP, 14))

        val applyMode = {
            val saved = mode == "saved"
            chipSaved.background = if (saved) rounded(0xFFEAF0FF.toInt(), act.dp(24).toFloat(), 0xFF6C8CF5.toInt(), act.dp(2))
            else rounded(0xFFEEF0F5.toInt(), act.dp(24).toFloat(), 0, 0)
            chipCal.background = if (!saved) rounded(0xFFEAF0FF.toInt(), act.dp(24).toFloat(), 0xFF6C8CF5.toInt(), act.dp(2))
            else rounded(0xFFEEF0F5.toInt(), act.dp(24).toFloat(), 0, 0)
            rows.alpha = if (saved) 1f else 0.4f
            for (t in timeViews) t.isEnabled = saved
            for (e in plans) e.isEnabled = saved
        }
        chipSaved.setOnClickListener {
            mode = "saved"
            applyMode()
        }
        chipCal.setOnClickListener {
            mode = "calendar"
            applyMode()
        }
        applyMode()

        footer(act, sheet) {
            Prefs.setSchedMode(act, mode)
            for (i in 0 until 5) Prefs.setSched(act, i, times[i], plans[i].text.toString().trim())
            sheet.dialog.dismiss()
            onSaved()
        }
        sheet.dialog.show()
    }

    // ------------------------------------------------------------------ Edit event

    fun editEvent(act: Activity, e: CalEvent, current: String, onSaved: () -> Unit) {
        val sheet = newSheet(act)
        header(act, sheet, "Edit event")
        val c = sheet.content
        c.addView(
            tv(act, "Update the event title shown in your current briefing and pick the celebration art you want.", 17f, GRAY, false),
            lp(act, MATCH, WRAP, 6)
        )
        c.addView(tv(act, "Event name", 16f, GRAY, false), lp(act, MATCH, WRAP, 18))

        val et = EditText(act)
        et.setText(current)
        et.setSingleLine(true)
        et.textSize = 22f
        et.setTextColor(INK)
        et.setPadding(act.dp(22), act.dp(16), act.dp(22), act.dp(16))
        et.background = field(act, false)
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.setOnFocusChangeListener { _, has -> et.background = field(act, has) }
        c.addView(et, lp(act, MATCH, WRAP, 8))

        var sel = Prefs.eventArt(act)
        val boxes = HashMap<String, LinearLayout>()
        val list = Arts.ALL
        var i = 0
        while (i < list.size) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 2) {
                val lpw = LinearLayout.LayoutParams(0, WRAP, 1f)
                if (k == 1) lpw.marginStart = act.dp(12)
                if (i + k < list.size) {
                    val a = list[i + k]
                    val o = LinearLayout(act)
                    o.orientation = LinearLayout.VERTICAL
                    o.gravity = Gravity.CENTER_HORIZONTAL
                    o.setPadding(act.dp(10), act.dp(14), act.dp(10), act.dp(14))
                    val img = ImageView(act)
                    img.setImageResource(a.icon)
                    o.addView(img, LinearLayout.LayoutParams(act.dp(84), act.dp(84)))
                    o.addView(tv(act, a.label, 17f, INK, false), lp(act, WRAP, WRAP, 8))
                    boxes[a.key] = o
                    row.addView(o, lpw)
                } else {
                    row.addView(View(act), lpw)
                }
            }
            c.addView(row, lp(act, MATCH, WRAP, 14))
            i += 2
        }
        val styleBoxes = {
            for ((key, box) in boxes) {
                box.background = if (key == sel) rounded(Color.WHITE, act.dp(24).toFloat(), 0xFF7C9BF7.toInt(), act.dp(3))
                else rounded(Color.WHITE, act.dp(24).toFloat(), 0xFFDDE2EC.toInt(), act.dp(1))
            }
        }
        for ((key, box) in boxes) {
            box.setOnClickListener {
                sel = key
                styleBoxes()
            }
        }
        styleBoxes()

        footer(act, sheet) {
            val name = et.text.toString().trim()
            Prefs.setEventName(act, e.begin, if (name == e.title) "" else name)
            Prefs.setEventArt(act, sel)
            sheet.dialog.dismiss()
            onSaved()
        }
        sheet.dialog.show()
    }
}
